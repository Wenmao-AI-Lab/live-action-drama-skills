#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
台词CSV生成器
从剧本文本提取台词并生成配音工具兼容格式
"""

import csv
import json
import re
from typing import List, Dict

class DialogueGenerator:
    """台词生成器"""
    
    def __init__(self):
        self.dialogues = []
        self.dialogue_counter = 0
        
    def extract_dialogues(self, script_text: str) -> List[Dict]:
        """
        从剧本文本提取台词
        
        Args:
            script_text: 剧本文本
            
        Returns:
            台词列表
        """
        dialogues = []
        lines = script_text.strip().split('\n')
        
        current_shot_id = "S001"
        shot_counter = 0
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # 识别角色对话
            dialogue_match = re.match(r'([^：:]+)[：:](.+)', line)
            if dialogue_match:
                character = dialogue_match.group(1).strip()
                content = dialogue_match.group(2).strip()
                
                # 移除括号内容（情绪标记）
                emotion = "平静"
                emotion_match = re.search(r'[（(](.+?)[）)]', content)
                if emotion_match:
                    emotion = emotion_match.group(1)
                    content = re.sub(r'[（(].+?[）)]', '', content).strip()
                
                shot_counter += 1
                self.dialogue_counter += 1
                
                dialogues.append({
                    "dialogue_id": f"D{self.dialogue_counter:03d}",
                    "shot_id": f"S{shot_counter:03d}",
                    "character": character,
                    "line": content,
                    "emotion": emotion,
                    "speed": self._guess_speed(emotion),
                    "pitch": self._guess_pitch(character),
                    "duration_sec": len(content) * 0.15,  # 约150ms/字
                    "voice_id": ""
                })
        
        return dialogues
    
    def _guess_speed(self, emotion: str) -> float:
        """根据情绪猜测语速"""
        speed_map = {
            "激动": 1.1,
            "愤怒": 1.2,
            "开心": 1.05,
            "悲伤": 0.85,
            "平静": 1.0,
            "紧张": 1.15,
            "沉稳": 0.9
        }
        return speed_map.get(emotion, 1.0)
    
    def _guess_pitch(self, character: str) -> str:
        """根据角色猜测音调"""
        # 可扩展角色-音调映射
        pitch_map = {
            "少年": "正常",
            "老者": "低沉",
            "师父": "低沉",
            "少女": "高亢",
            "孩童": "高亢"
        }
        return pitch_map.get(character, "正常")
    
    def generate_csv(self, dialogues: List[Dict], output_path: str = "台词表.csv"):
        """
        生成台词CSV文件
        
        Args:
            dialogues: 台词列表
            output_path: 输出文件路径
        """
        fieldnames = [
            "dialogue_id", "shot_id", "character", "line",
            "emotion", "speed", "pitch", "duration_sec", "voice_id"
        ]
        
        with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(dialogues)
        
        print(f"✅ 台词表已生成: {output_path}")
        print(f"   共 {len(dialogues)} 句台词")
        return output_path
    
    def generate_doubao_format(self, dialogues: List[Dict], output_path: str = "豆包TTS台词.txt"):
        """
        生成豆包TTS批量格式
        
        格式：[角色]xxx[/角色][情绪]xxx[/情绪]台词内容
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            for d in dialogues:
                line = f"[角色]{d['character']}[/角色][情绪]{d['emotion']}[/情绪]{d['line']}\n"
                f.write(line)
        
        print(f"✅ 豆包TTS格式已生成: {output_path}")
        return output_path
    
    def generate_xunfei_format(self, dialogues: List[Dict], output_path: str = "讯飞配音台词.txt"):
        """
        生成讯飞配音批量格式
        
        格式：角色|情绪|台词内容
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            for d in dialogues:
                line = f"{d['character']}|{d['emotion']}|{d['line']}\n"
                f.write(line)
        
        print(f"✅ 讯飞配音格式已生成: {output_path}")
        return output_path
    
    def generate_batch_json(self, dialogues: List[Dict], output_path: str = "台词批量生成.json"):
        """生成JSON格式用于API调用"""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({"dialogues": dialogues}, f, ensure_ascii=False, indent=2)
        print(f"✅ 台词JSON已生成: {output_path}")


def main():
    """示例用法"""
    generator = DialogueGenerator()
    
    # 示例剧本
    script = """
少年：（坚定）我要成为最强的修仙者！

师父：（沉稳）修仙之路，心如止水。

少年：（激动）师父，我明白了！

少女：（开心）太好了，我们一起努力吧！

老者：（悲伤）这条路，不好走啊...
"""
    
    # 提取台词
    dialogues = generator.extract_dialogues(script)
    
    # 生成各种格式
    generator.generate_csv(dialogues)
    generator.generate_doubao_format(dialogues)
    generator.generate_xunfei_format(dialogues)
    
    # 打印预览
    print("\n📝 台词表预览:")
    print("-" * 80)
    for d in dialogues:
        print(f"{d['dialogue_id']} | {d['character']} | {d['emotion']} | {d['line'][:20]}...")


if __name__ == "__main__":
    main()
