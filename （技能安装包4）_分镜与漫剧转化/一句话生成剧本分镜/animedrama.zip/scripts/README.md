# 批量生成自动化脚本使用指南

本文档提供批量生成自动化脚本的使用说明，帮助用户一键生成分镜表、台词表、镜头提示词。

---

## 📦 脚本列表

| 脚本 | 功能 | 输入 | 输出 |
|------|------|------|------|
| `run_all.py` | 一键生成全部 | 剧本文本 | 分镜表、台词表、提示词 |
| `storyboard_generator.py` | 分镜表生成 | 剧本文本 | 分镜表CSV/JSON |
| `dialogue_generator.py` | 台词表生成 | 剧本文本 | 台词表CSV、配音工具格式 |
| `prompt_generator.py` | 提示词生成 | 分镜表CSV | 提示词JSON、可灵AI格式 |

---

## 🚀 快速开始

### 方式一：一键生成（推荐）

```bash
# 基础用法
python scripts/run_all.py 剧本.txt

# 指定风格和输出目录
python scripts/run_all.py 剧本.txt --style 国风 --output ./output
```

**参数说明**：
- `剧本.txt`：剧本文本文件路径
- `--style`：视觉风格（国风/日漫/3D皮克斯/赛博朋克/超现实写真/美漫/水墨国风/像素风）
- `--output`：输出目录，默认 `./output`

**生成文件**：
```
output/
├── 分镜表.csv          # 分镜表CSV格式
├── 分镜表.json         # 分镜表JSON格式
├── 台词表.csv          # 台词表CSV格式
├── 豆包TTS台词.txt     # 豆包TTS批量格式
├── 讯飞配音台词.txt    # 讯飞配音批量格式
├── 镜头提示词.json     # 镜头提示词JSON格式
└── 可灵AI提示词.txt    # 可灵AI批量格式
```

---

### 方式二：单独使用各模块

#### 1. 分镜表生成器

```python
from storyboard_generator import StoryboardGenerator

# 创建生成器
gen = StoryboardGenerator()

# 解析剧本
script = """
【场景：竹林修炼地】
【时间：清晨】

晨雾缭绕的竹林中，少年静静站立。
少年：（坚定）我要成为最强的修仙者！
"""

scenes = gen.parse_script(script)
shots = gen.auto_split_shots(scenes)

# 生成CSV
gen.generate_csv(shots, "分镜表.csv")
```

**输出字段**：
- shot_id：镜头编号
- scene_id：场景编号
- duration_sec：时长（秒）
- shot_type：景别
- camera_move：运镜方式
- description：画面描述
- characters：出场角色
- emotion：情绪基调
- dialogue_id：关联台词ID
- sfx：音效说明
- music_mood：配乐情绪
- notes：备注

---

#### 2. 台词表生成器

```python
from dialogue_generator import DialogueGenerator

gen = DialogueGenerator()

script = """
少年：（坚定）我要成为最强的修仙者！
师父：（沉稳）修仙之路，心如止水。
"""

dialogues = gen.extract_dialogues(script)

# 生成CSV
gen.generate_csv(dialogues, "台词表.csv")

# 生成豆包TTS格式
gen.generate_doubao_format(dialogues, "豆包TTS台词.txt")

# 生成讯飞配音格式
gen.generate_xunfei_format(dialogues, "讯飞配音台词.txt")
```

**输出格式**：

**CSV格式**：
```csv
dialogue_id,shot_id,character,line,emotion,speed,pitch,duration_sec,voice_id
D001,S001,少年,我要成为最强的修仙者,坚定,1.1,正常,3.2,
D002,S002,师父,修仙之路，心如止水,平静,0.9,低沉,2.8,
```

**豆包TTS格式**：
```
[角色]少年[/角色][情绪]坚定[/情绪]我要成为最强的修仙者
[角色]师父[/角色][情绪]平静[/情绪]修仙之路，心如止水
```

**讯飞配音格式**：
```
少年|坚定|我要成为最强的修仙者
师父|平静|修仙之路，心如止水
```

---

#### 3. 镜头提示词生成器

```python
from prompt_generator import PromptGenerator

# 创建生成器（指定风格）
gen = PromptGenerator(style="国风")

# 从分镜表CSV加载
shots = gen.load_from_csv("分镜表.csv")

# 生成JSON
gen.generate_json(shots, "镜头提示词.json")

# 生成可灵AI格式
gen.generate_kling_format(shots, "可灵AI提示词.txt")
```

**输出格式**：

**JSON格式**：
```json
{
  "project_name": "短剧项目",
  "style": "国风",
  "shots": [
    {
      "shot_id": "S001",
      "style": "国风",
      "prompt_zh": "国风水墨风格，竹林中少年仰望天空，远景，固定镜头，优雅大气，水墨意境，中国传统美学",
      "negative_prompt": "modern, western, realistic, 3d render",
      "aspect_ratio": "16:9",
      "motion_strength": 0.3
    }
  ]
}
```

**可灵AI格式**：
```
【镜头1】国风水墨风格，竹林中少年仰望天空，远景，固定镜头，优雅大气，水墨意境
【镜头2】国风水墨风格，少年正面中景，推镜头，表情坚定，优雅大气
```

---

## 📋 剧本格式规范

### 场景标记

```
【场景：竹林修炼地】
【时间：清晨】
```

### 角色对话

```
角色名：（情绪）台词内容
```

**示例**：
```
少年：（坚定）我要成为最强的修仙者！
师父：（沉稳）修仙之路，心如止水。
少女：（开心）太好了！
```

### 动作描述

```
晨雾缭绕的竹林中，少年静静站立。
突然，一道金光从天而降。
```

### 完整剧本示例

```
【场景：竹林修炼地】
【时间：清晨】

晨雾缭绕的竹林中，少年静静站立。

少年：（坚定）我要成为最强的修仙者！

突然，一道金光从天而降。

师父：（沉稳）修仙之路，心如止水。

少年抬头，眼中闪过一丝惊喜。

少年：（激动）师父，我明白了！

【场景：山顶修炼场】
【时间：白天】

少年和师父并肩站立，眺望远方。

师父：（平静）记住，心静如水。

少年：（认真）弟子铭记在心。
```

---

## 🎨 支持的视觉风格

| 风格 | 特点 | 适用场景 |
|------|------|----------|
| 国风 | 中国古典美学，水墨元素 | 古装、仙侠 |
| 日漫 | 经典2D动画，色彩明快 | 校园、恋爱 |
| 3D皮克斯 | 卡通渲染，表情丰富 | 家庭、冒险 |
| 赛博朋克 | 霓虹光影，科技感强 | 科幻、未来 |
| 超现实写真 | 电影级质感，细节丰富 | 悬疑、剧情 |
| 美漫 | 粗犷线条，高对比度 | 动作、冒险 |
| 水墨国风 | 传统水墨，留白意境 | 古风、禅意 |
| 像素风 | 复古像素，怀旧感 | 独立游戏 |

---

## 💡 使用技巧

### 1. 批量工作流

```bash
# 步骤1：一键生成所有文件
python scripts/run_all.py 剧本.txt --style 国风

# 步骤2：复制台词到配音工具
# 打开 output/豆包TTS台词.txt，粘贴到豆包TTS批量生成

# 步骤3：复制提示词到视频工具
# 打开 output/可灵AI提示词.txt，粘贴到可灵AI批量生成
```

### 2. 自定义修改

生成后可直接编辑CSV文件：
- 用Excel打开 `分镜表.csv`，调整时长、景别、情绪
- 用Excel打开 `台词表.csv`，调整语速、音调
- 修改后重新运行提示词生成器

```bash
# 修改CSV后重新生成提示词
python -c "
from prompt_generator import PromptGenerator
gen = PromptGenerator(style='国风')
shots = gen.load_from_csv('output/分镜表.csv')
gen.generate_json(shots, 'output/镜头提示词.json')
gen.generate_kling_format(shots, 'output/可灵AI提示词.txt')
"
```

### 3. 多风格版本

```bash
# 生成多个风格版本
python scripts/run_all.py 剧本.txt --style 国风 --output ./output_guofeng
python scripts/run_all.py 剧本.txt --style 日漫 --output ./output_riman
python scripts/run_all.py 剧本.txt --style 赛博朋克 --output ./output_saibo
```

---

## 🔧 常见问题

### Q: 脚本运行报错？

**A**: 确保Python版本 >= 3.7，并安装依赖：
```bash
pip install -r requirements.txt
```

### Q: 生成的景别不准确？

**A**: 可以手动编辑 `分镜表.csv` 中的 `shot_type` 字段，然后重新生成提示词。

### Q: 如何添加新的视觉风格？

**A**: 编辑 `prompt_generator.py` 中的 `STYLE_TEMPLATES` 字典，添加新风格模板。

### Q: 台词时长估算不准？

**A**: 编辑 `dialogue_generator.py` 中的 `duration_sec` 计算逻辑，或直接修改CSV文件。

---

## 📞 反馈与建议

如有问题或建议，请在虾评Skill平台提交评测反馈。
