#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
短剧工坊 - 批量生成自动化脚本
一键生成分镜表、台词表、镜头提示词
"""

import os
import sys
import argparse
from pathlib import Path

# 导入各模块
from storyboard_generator import StoryboardGenerator
from dialogue_generator import DialogueGenerator
from prompt_generator import PromptGenerator


def read_script(script_path: str) -> str:
    """读取剧本文本"""
    with open(script_path, 'r', encoding='utf-8') as f:
        return f.read()


def main():
    parser = argparse.ArgumentParser(description='短剧工坊批量生成工具')
    parser.add_argument('script', help='剧本文本文件路径')
    parser.add_argument('--style', default='国风', choices=['国风', '日漫', '3D皮克斯', '赛博朋克', '超现实写真', '美漫', '水墨国风', '像素风'], help='视觉风格')
    parser.add_argument('--output', default='./output', help='输出目录')
    
    args = parser.parse_args()
    
    # 创建输出目录
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print("=" * 60)
    print("🎬 短剧工坊 - 批量生成工具")
    print("=" * 60)
    print(f"剧本文件: {args.script}")
    print(f"视觉风格: {args.style}")
    print(f"输出目录: {output_dir}")
    print("=" * 60)
    
    # 读取剧本
    print("\n📖 正在读取剧本...")
    script_text = read_script(args.script)
    
    # 1. 生成分镜表
    print("\n📊 正在生成分镜表...")
    storyboard_gen = StoryboardGenerator()
    scenes = storyboard_gen.parse_script(script_text)
    shots = storyboard_gen.auto_split_shots(scenes)
    storyboard_gen.generate_csv(shots, output_dir / "分镜表.csv")
    storyboard_gen.generate_json(shots, output_dir / "分镜表.json")
    
    # 2. 生成台词表
    print("\n💬 正在生成台词表...")
    dialogue_gen = DialogueGenerator()
    dialogues = dialogue_gen.extract_dialogues(script_text)
    dialogue_gen.generate_csv(dialogues, output_dir / "台词表.csv")
    dialogue_gen.generate_doubao_format(dialogues, output_dir / "豆包TTS台词.txt")
    dialogue_gen.generate_xunfei_format(dialogues, output_dir / "讯飞配音台词.txt")
    
    # 3. 生成镜头提示词
    print("\n🎨 正在生成镜头提示词...")
    prompt_gen = PromptGenerator(style=args.style)
    prompt_gen.generate_json(shots, output_dir / "镜头提示词.json")
    prompt_gen.generate_kling_format(shots, output_dir / "可灵AI提示词.txt")
    
    # 汇总
    print("\n" + "=" * 60)
    print("✅ 生成完成！")
    print("=" * 60)
    print(f"📊 分镜表: {len(shots)} 个镜头")
    print(f"💬 台词表: {len(dialogues)} 句台词")
    print(f"🎨 提示词: {len(shots)} 条")
    print(f"\n📁 输出文件:")
    for f in output_dir.iterdir():
        print(f"   - {f.name}")
    print("=" * 60)


if __name__ == "__main__":
    main()
