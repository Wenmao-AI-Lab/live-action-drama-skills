#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分镜表生成器
从剧本自动生成分镜表CSV
"""

import csv
import json
import re
from typing import List, Dict

class StoryboardGenerator:
    """分镜表生成器"""
    
    def __init__(self):
        self.shots = []
        self.current_scene = "SC01"
        self.shot_counter = 0
        
    def parse_script(self, script_text: str) -> List[Dict]:
        """
        解析剧本文本，提取场景和动作
        
        Args:
            script_text: 剧本文本
            
        Returns:
            场景列表
        """
        scenes = []
        lines = script_text.strip().split('\n')
        
        current_scene = {
            "scene_id": "SC01",
            "location": "",
            "time": "",
            "actions": []
        }
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # 识别场景标记 【场景：xxx】或 [场景：xxx]
            scene_match = re.match(r'[【\[]场景[：:](.+?)[】\]]', line)
            if scene_match:
                if current_scene["actions"]:
                    scenes.append(current_scene)
                current_scene = {
                    "scene_id": f"SC{len(scenes)+1:02d}",
                    "location": scene_match.group(1).strip(),
                    "time": "",
                    "actions": []
                }
                continue
            
            # 识别时间标记 【时间：xxx】
            time_match = re.match(r'[【\[]时间[：:](.+?)[】\]]', line)
            if time_match:
                current_scene["time"] = time_match.group(1).strip()
                continue
            
            # 识别角色对话
            dialogue_match = re.match(r'([^：:]+)[：:](.+)', line)
            if dialogue_match:
                character = dialogue_match.group(1).strip()
                dialogue = dialogue_match.group(2).strip()
                current_scene["actions"].append({
                    "type": "dialogue",
                    "character": character,
                    "content": dialogue
                })
                continue
            
            # 识别动作描述（括号内容）
            action_match = re.findall(r'[（(](.+?)[）)]', line)
            if action_match:
                for action in action_match:
                    current_scene["actions"].append({
                        "type": "action",
                        "content": action
                    })
            
            # 其他文本作为场景描述
            if not action_match and not dialogue_match:
                current_scene["actions"].append({
                    "type": "description",
                    "content": line
                })
        
        if current_scene["actions"]:
            scenes.append(current_scene)
            
        return scenes
    
    def auto_split_shots(self, scenes: List[Dict]) -> List[Dict]:
        """
        自动将场景拆分为镜头
        
        Args:
            scenes: 场景列表
            
        Returns:
            镜头列表
        """
        shots = []
        shot_counter = 0
        
        for scene in scenes:
            scene_id = scene["scene_id"]
            
            # 每个场景生成1-3个镜头
            if len(scene["actions"]) <= 1:
                # 简单场景，一个镜头
                shot_counter += 1
                shots.append(self._create_shot(
                    shot_id=f"S{shot_counter:03d}",
                    scene_id=scene_id,
                    description=scene["actions"][0]["content"] if scene["actions"] else scene["location"],
                    duration=3.0,
                    shot_type="中景"
                ))
            else:
                # 复杂场景，拆分多个镜头
                for i, action in enumerate(scene["actions"]):
                    shot_counter += 1
                    
                    # 智能判断景别
                    shot_type = self._guess_shot_type(action, i, len(scene["actions"]))
                    
                    # 智能判断时长
                    duration = self._guess_duration(action)
                    
                    shots.append(self._create_shot(
                        shot_id=f"S{shot_counter:03d}",
                        scene_id=scene_id,
                        description=action["content"],
                        duration=duration,
                        shot_type=shot_type,
                        characters=action.get("character", ""),
                        emotion=self._guess_emotion(action)
                    ))
        
        return shots
    
    def _create_shot(self, shot_id, scene_id, description, duration, shot_type, **kwargs):
        """创建镜头字典"""
        return {
            "shot_id": shot_id,
            "scene_id": scene_id,
            "duration_sec": duration,
            "shot_type": shot_type,
            "camera_move": kwargs.get("camera_move", "固定"),
            "description": description,
            "characters": kwargs.get("characters", ""),
            "emotion": kwargs.get("emotion", "平静"),
            "dialogue_id": kwargs.get("dialogue_id", ""),
            "sfx": kwargs.get("sfx", ""),
            "music_mood": kwargs.get("music_mood", ""),
            "notes": kwargs.get("notes", "")
        }
    
    def _guess_shot_type(self, action, index, total):
        """智能判断景别"""
        if action["type"] == "dialogue":
            if index == 0:
                return "中景"
            elif index == total - 1:
                return "近景"
            else:
                return "中近景"
        elif action["type"] == "action":
            return "特写"
        else:
            if index == 0:
                return "远景"
            else:
                return "中景"
    
    def _guess_duration(self, action):
        """智能判断时长"""
        content = action.get("content", "")
        
        # 根据内容长度判断
        if len(content) < 10:
            return 2.0
        elif len(content) < 20:
            return 3.0
        elif len(content) < 50:
            return 4.0
        else:
            return 5.0
    
    def _guess_emotion(self, action):
        """智能判断情绪"""
        content = action.get("content", "")
        
        # 情绪关键词
        emotion_keywords = {
            "悲伤": ["哭", "泪", "伤心", "难过", "悲痛"],
            "愤怒": ["怒", "气", "愤", "吼", "骂"],
            "开心": ["笑", "开心", "高兴", "快乐", "喜悦"],
            "紧张": ["紧张", "惊", "怕", "恐惧", "颤抖"],
            "激动": ["激动", "兴奋", "热血", "激情"],
        }
        
        for emotion, keywords in emotion_keywords.items():
            if any(kw in content for kw in keywords):
                return emotion
        
        return "平静"
    
    def generate_csv(self, shots: List[Dict], output_path: str = "分镜表.csv"):
        """
        生成分镜表CSV文件
        
        Args:
            shots: 镜头列表
            output_path: 输出文件路径
        """
        fieldnames = [
            "shot_id", "scene_id", "duration_sec", "shot_type", 
            "camera_move", "description", "characters", "emotion",
            "dialogue_id", "sfx", "music_mood", "notes"
        ]
        
        with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(shots)
        
        print(f"✅ 分镜表已生成: {output_path}")
        print(f"   共 {len(shots)} 个镜头")
        return output_path
    
    def generate_json(self, shots: List[Dict], output_path: str = "分镜表.json"):
        """生成分镜表JSON文件"""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({"shots": shots}, f, ensure_ascii=False, indent=2)
        print(f"✅ 分镜表JSON已生成: {output_path}")


def main():
    """示例用法"""
    generator = StoryboardGenerator()
    
    # 示例剧本
    script = """
【场景：竹林修炼地】
【时间：清晨】

晨雾缭绕的竹林中，少年静静站立。
少年：（坚定）我要成为最强的修仙者！

突然，一道金光从天而降。
师父：（沉稳）修仙之路，心如止水。

少年抬头，眼中闪过一丝惊喜。
少年：（激动）师父，我明白了！
"""
    
    # 解析剧本
    scenes = generator.parse_script(script)
    print(f"解析出 {len(scenes)} 个场景")
    
    # 自动拆分镜头
    shots = generator.auto_split_shots(scenes)
    print(f"生成 {len(shots)} 个镜头")
    
    # 生成CSV
    generator.generate_csv(shots)
    
    # 打印预览
    print("\n📊 分镜表预览:")
    print("-" * 80)
    for shot in shots[:5]:
        print(f"{shot['shot_id']} | {shot['scene_id']} | {shot['shot_type']} | {shot['duration_sec']}s | {shot['description'][:30]}...")


if __name__ == "__main__":
    main()
