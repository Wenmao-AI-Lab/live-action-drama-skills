#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
镜头提示词批量生成器
从分镜表生成视频生成工具兼容的提示词
"""

import json
import csv
from typing import List, Dict

class PromptGenerator:
    """镜头提示词生成器"""
    
    # 风格模板
    STYLE_TEMPLATES = {
        "国风": {
            "prefix": "国风水墨风格，",
            "suffix": "，优雅大气，水墨意境，中国传统美学",
            "negative": "modern, western, realistic, 3d render"
        },
        "日漫": {
            "prefix": "日式动漫风格，",
            "suffix": "，线条流畅，色彩明快，日系动画质感",
            "negative": "realistic, photo, western style"
        },
        "3D皮克斯": {
            "prefix": "皮克斯3D动画风格，",
            "suffix": "，卡通渲染，光影柔和，表情生动",
            "negative": "realistic, dark, horror"
        },
        "赛博朋克": {
            "prefix": "赛博朋克风格，",
            "suffix": "，霓虹光影，科技感，未来都市",
            "negative": "natural, countryside, peaceful"
        },
        "超现实写真": {
            "prefix": "电影级写实风格，",
            "suffix": "，高质量，真实光影，细节丰富",
            "negative": "cartoon, anime, low quality"
        },
        "美漫": {
            "prefix": "美式漫画风格，",
            "suffix": "，粗犷线条，高对比度，动态感强",
            "negative": "anime, realistic, soft"
        },
        "水墨国风": {
            "prefix": "传统水墨画风格，",
            "suffix": "，留白意境，诗情画意，东方美学",
            "negative": "modern, colorful, western"
        },
        "像素风": {
            "prefix": "复古像素风格，",
            "suffix": "，怀旧感，8-bit艺术，独特像素美学",
            "negative": "realistic, high resolution, modern"
        }
    }
    
    SHOT_TYPE_MAP = {
        "远景": "wide shot", "全景": "full shot", "中景": "medium shot",
        "近景": "close-up", "特写": "extreme close-up"
    }
    
    CAMERA_MOVE_MAP = {
        "固定": "static", "推": "push in", "拉": "pull back",
        "摇": "pan", "移": "tracking", "跟": "follow"
    }
    
    def __init__(self, style: str = "国风"):
        self.style = style
        self.style_template = self.STYLE_TEMPLATES.get(style, self.STYLE_TEMPLATES["国风"])
    
    def generate_prompt(self, shot: Dict) -> Dict:
        """为单个镜头生成提示词"""
        prompt_zh = f"{self.style_template['prefix']}{shot.get('description', '')}，{shot.get('shot_type', '中景')}，{shot.get('camera_move', '固定')}镜头{self.style_template['suffix']}"
        
        return {
            "shot_id": shot.get("shot_id", "S001"),
            "style": self.style,
            "prompt_zh": prompt_zh,
            "negative_prompt": self.style_template["negative"],
            "aspect_ratio": "16:9",
            "motion_strength": 0.3 if shot.get("camera_move") == "固定" else 0.6
        }
    
    def batch_generate(self, shots: List[Dict]) -> Dict:
        """批量生成提示词"""
        return {
            "project_name": "短剧项目",
            "style": self.style,
            "shots": [self.generate_prompt(shot) for shot in shots]
        }
    
    def generate_json(self, shots: List[Dict], output_path: str = "镜头提示词.json"):
        """生成JSON文件"""
        project = self.batch_generate(shots)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(project, f, ensure_ascii=False, indent=2)
        print(f"✅ 镜头提示词已生成: {output_path} ({len(project['shots'])}个镜头)")
        return output_path
    
    def generate_kling_format(self, shots: List[Dict], output_path: str = "可灵AI提示词.txt"):
        """生成可灵AI批量粘贴格式"""
        with open(output_path, 'w', encoding='utf-8') as f:
            for i, shot in enumerate(shots, 1):
                prompt = self.generate_prompt(shot)
                f.write(f"【镜头{i}】{prompt['prompt_zh']}\n")
        print(f"✅ 可灵AI格式已生成: {output_path}")
        return output_path
    
    def load_from_csv(self, csv_path: str) -> List[Dict]:
        """从CSV加载分镜表"""
        shots = []
        with open(csv_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                shots.append(row)
        return shots


if __name__ == "__main__":
    generator = PromptGenerator(style="国风")
    shots = [{"shot_id": "S001", "description": "竹林中少年仰望天空", "shot_type": "远景", "camera_move": "固定"}]
    generator.generate_json(shots)
