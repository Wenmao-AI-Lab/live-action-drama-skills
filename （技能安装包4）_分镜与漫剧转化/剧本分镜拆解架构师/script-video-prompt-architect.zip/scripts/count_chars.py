#!/usr/bin/env python3
"""字数统计脚本 —— 供「长文本输出规则」判断分镜脚本/视频提示词是否超长。

字符数包含中文、英文、标点、换行等所有字符（按 Unicode code point 计数）。
阈值 8000：>8000 走"写入 .md 文件"分支，否则走"直接在对话中输出"分支。

用法：
    python scripts/count_chars.py <文件路径>
    cat draft.md | python scripts/count_chars.py
    python scripts/count_chars.py --threshold 8000 <文件路径>
"""
import argparse
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="统计文本字符数并判断是否超过阈值")
    parser.add_argument("path", nargs="?", help="待统计文件路径；省略则从标准输入读取")
    parser.add_argument("--threshold", type=int, default=8000, help="超长阈值，默认 8000")
    args = parser.parse_args()

    if args.path:
        try:
            with open(args.path, "r", encoding="utf-8") as f:
                text = f.read()
        except OSError as e:
            print(f"读取失败：{e}", file=sys.stderr)
            return 1
    else:
        text = sys.stdin.read()

    count = len(text)
    over = count > args.threshold
    branch = "写入 .md 文件（超长）" if over else "直接在对话中输出"

    print(f"字符总数：{count}")
    print(f"阈值：{args.threshold}")
    print(f"是否超长：{'是' if over else '否'}")
    print(f"建议分支：{branch}")
    # 退出码：超长返回 2，便于脚本化判断；正常 0
    return 2 if over else 0


if __name__ == "__main__":
    sys.exit(main())
