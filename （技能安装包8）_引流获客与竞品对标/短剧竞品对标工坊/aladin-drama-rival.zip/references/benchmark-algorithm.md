# 对标算法与数据契约（benchmark-algorithm）

## 一、竞品强度评分（100 分制，可复算）

对每部竞品剧计算「强度分」，用于排行与选出标杆剧：

```
强度分 = (播放归一 × 0.45 + 互动率归一 × 0.30 + 完播归一 × 0.25) × 100
```

- **播放归一** = 本剧播放量 ÷ 全体最高播放量（0-1）
- **互动率** = (点赞 + 追更) ÷ 播放量；**互动率归一** = min(互动率 ÷ 0.15, 1)（15% 记满分）
- **完播归一** = min(完播率 ÷ 100, 1)

缺失字段按 0 计入（不臆造），因此数据越全的竞品评分越可信。排名第 1 即「标杆剧」。

## 二、数值清洗规则

`rival_ingest.py` 自动把人类可读数值统一成整数：

| 原始写法 | 解析结果 |
|---|---|
| `1.2亿` | 120000000 |
| `9800万` / `12w` | 98000000 / 120000 |
| `3,500` / `3，500` | 3500 |
| `42%` | 42.0（完播率专用 parse_percent） |
| `-` / `无` / 空 | None（视为缺失） |

## 三、排播规律统计

- 平均 / 最小 / 最大集数
- 平均付费墙集数、平均付费墙位置比例（付费墙集 ÷ 总集数）
- 更新节奏分布（日更2集 / 日更3集 …）

付费墙位置比例是回灌 `money` 变现环的核心参考——竞品普遍卡在总集数的百分之几处。

## 四、数据契约（供闭环消费）

### 输入 IR（rival_ingest → `_rival_ir.json`）

```json
{
  "schema": "aladin-drama-rival/ir@1",
  "my_plan": {"genre": "甜宠", "platform": "红果"},
  "count": 8,
  "rivals": [
    {"title": "...", "genre": "甜宠", "genre_all": ["甜宠","豪门"],
     "platform": "红果", "episodes": 80, "update_pace": "日更2集",
     "views": 120000000, "likes": 8600000, "follows": 3100000,
     "finish_rate": 42.0, "paywall_ep": 12, "lead_type": "真人",
     "synopsis": "...", "tags": ["闪婚"], "tropes": ["先婚后爱","打脸反转"],
     "release_date": "2026-05-10"}
  ]
}
```

### 分析结论（rival_analyze → `_rival.json`）

关键字段：`genre_distribution` / `trope_frequency` / `matrix`(cell+crowded+blanks) /
`scheduling` / `ranking` / `benchmark` / `feedback`。

### feedback 回灌契约（对接 aladin-drama 系列）

```json
{
  "to_topic":  {"avoid_crowded_genres": [], "blue_ocean_genres": [],
                 "differentiation_ideas": [], "my_genre_note": ""},
  "to_money":  {"benchmark_paywall_ep": 13.0, "benchmark_paywall_ratio_pct": 15.5},
  "to_script": {"high_freq_tropes": []}
}
```

- `to_topic` → 选题环：避开扎堆题材、切入差异化空白
- `to_money` → 变现环：付费墙定位参考
- `to_script` → 剧本环：高频套路借鉴（换壳创新，不照搬）

## 五、人机分工（Hy3）

脚本只做**确定性检出与统计**（题材归类、套路命中、评分、矩阵、空白格）。
差异化定位的创意话术、套路的换壳创新、竞品成功原因的深度归因，交给模型 + 人工完成。
