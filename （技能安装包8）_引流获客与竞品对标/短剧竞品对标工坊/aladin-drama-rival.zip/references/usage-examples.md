# 使用示例（usage-examples）

## 场景 1：立项前扫一遍同题材竞品，找差异化切口

你打算做「甜宠」赛道、投「红果」，先把手头收集到的 8 部同题材热剧填进 JSON
（或从平台榜单导出 CSV），一键拆解：

```bash
# 1) 导入归一（带上我方计划，便于差异化定位）
python scripts/rival_ingest.py --json assets/sample_rivals.json \
    --my-genre 甜宠 --my-platform 红果 --out _rival_ir.json

# 2) 竞品拆解分析
python scripts/rival_analyze.py --ir _rival_ir.json --out _rival.json

# 3) 渲染看板 + 报告 + 台账
python scripts/rival_report.py --analysis _rival.json \
    --out-html rival_board.html --out-md _rival_report.md --out-csv rival_table.csv
```

打开 `rival_board.html` 即可看到：题材热度条形图、差异化矩阵热力图、竞品强度排行、
以及「题材 × 套路」空白机会清单和付费墙参考位置。

## 场景 2：只有一份平台榜单 CSV

CSV 表头可用中文（题材/播放量/集数/付费墙…），别名自动匹配：

```bash
python scripts/rival_ingest.py --csv 平台榜单.csv --out _rival_ir.json
python scripts/rival_analyze.py --ir _rival_ir.json --out _rival.json
python scripts/rival_report.py --analysis _rival.json
```

数值支持 `1.2亿` / `9800万` / `3,500` / `42%` 等人类写法，自动清洗。

## 场景 3：闭环联动（回灌选题 / 变现 / 剧本）

`_rival.json` 里的 `feedback` 字段是标准回灌契约：

- **回灌选题**：把 `to_topic.blue_ocean_genres` 与 `differentiation_ideas` 作为选题输入，
  避开 `avoid_crowded_genres` 扎堆题材。
- **回灌变现**：把 `to_money.benchmark_paywall_ratio_pct` 作为付费墙定位参考。
- **回灌剧本**：把 `to_script.high_freq_tropes` 作为可借鉴（需换壳）的套路清单。

## 场景 4：让模型接管语义层（Hy3）

脚本给出确定性数据后，可让模型基于 `_rival_report.md` 进一步：

- 为每个「差异化空白」写 2-3 个具体的一句话选题；
- 分析标杆剧「为什么火」的可迁移经验；
- 给出高频套路的「换壳创新」方案，避免同质化被平台限流。

> 提示：竞品数据全程本地处理，不上传任何云端，适合把敏感的对标情报留在本机。

## 输入字段速查

| 字段 | 说明 | 示例 |
|---|---|---|
| title | 剧名（必填） | 豪门第一盛宠 |
| genre | 题材（自由填，自动归一） | 甜宠 豪门 |
| platform | 平台 | 红果 / 抖音 / 快手 / 微信 / 番茄 |
| episodes | 总集数 | 80 |
| update_pace | 更新节奏 | 日更2集 |
| views | 播放量 | 1.2亿 / 9800万 |
| likes / follows | 点赞 / 追更 | 860万 / 310万 |
| finish_rate | 完播率 | 42% |
| paywall_ep | 付费墙集数 | 12 |
| lead_type | 主演类型 | 真人 / 数字人 |
| synopsis | 简介（用于套路识别） | 落魄千金闪婚神秘总裁… |
| tags | 卖点标签（数组或分号分隔） | 闪婚;先婚后爱;打脸 |

## 常见问题

- **Q：只填了剧名和播放量能用吗？** 能。缺失字段按缺失处理，评分与统计会相应弱化，
  但题材/套路仍会尽力从简介与标签识别。
- **Q：题材识别不准？** 编辑 `scripts/rival_ingest.py` 的 `GENRE_CANON` 补关键词即可。
- **Q：结果每次一样吗？** 是。全部为确定性规则，同输入必同输出，可复算、可版本管理。
