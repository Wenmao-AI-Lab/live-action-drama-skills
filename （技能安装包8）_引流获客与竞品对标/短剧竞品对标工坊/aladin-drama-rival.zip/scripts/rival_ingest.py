# -*- coding: utf-8 -*-
"""aladin-drama-rival · rival_ingest.py
AI 短剧竞品对标·多源导入归一：把「同题材竞品剧/爆款剧清单」统一成
竞品对标 IR（_rival_ir.json）。

支持输入（任意组合，至少一项）：
  1) JSON 竞品清单：可为顶层数组，或 {"rivals":[...]} / {"items":[...]} 包裹
  2) CSV/TSV 竞品清单：一行=一部剧，表头别名自动匹配（见 FIELD_ALIASES）
  3) 平台榜单导出 CSV（同上，文件名可含平台名用于兜底识别）

单部剧可用字段（缺失自动留空/推断）：
  title 剧名 | genre 题材 | platform 平台 | episodes 总集数 |
  update_pace 更新节奏 | views 播放量 | likes 点赞 | follows 追更/在追 |
  finish_rate 完播率(%) | paywall_ep 付费墙集数 | lead_type 主演类型 |
  synopsis 简介 | tags 卖点标签(分号/逗号分隔或数组) | release_date 上线日期

数值清洗：自动识别「万/w/亿」单位、千分位逗号、百分号，统一成整数/浮点。
题材归类：把自由填写的题材映射到标准题材词典（见 references/genre-trope-taxonomy.md）。

用法：
  python rival_ingest.py --json assets/sample_rivals.json --out _rival_ir.json
  python rival_ingest.py --csv rivals.csv --my-genre 甜宠 --my-platform 红果 --out _rival_ir.json

仅 Python 标准库，纯本地运行，竞品数据不出本机。
"""
import argparse
import csv
import io
import json
import os
import re
import sys

# ---------- 标准题材词典（同义归一） ----------
GENRE_CANON = {
    "甜宠": ["甜宠", "宠", "恋爱", "撒糖", "甜", "先婚后爱", "闪婚", "契约婚", "隐婚"],
    "逆袭": ["逆袭", "打脸", "扮猪吃虎", "崛起", "翻身", "小人物"],
    "复仇": ["复仇", "报复", "复仇记", "手撕", "反击"],
    "重生": ["重生", "重来", "回到过去", "一世"],
    "穿越": ["穿越", "穿书", "穿成", "魂穿"],
    "战神": ["战神", "兵王", "军门", "龙王", "最强", "王者归来", "退伍"],
    "赘婿": ["赘婿", "上门女婿", "女婿"],
    "豪门": ["豪门", "总裁", "首富", "京圈", "太子妃", "少奶奶", "阔太"],
    "古装": ["古装", "王爷", "皇上", "医妃", "宫斗", "将军", "郡主", "侯府"],
    "都市": ["都市", "职场", "现代", "都市异能"],
    "悬疑": ["悬疑", "推理", "探案", "犯罪", "谜案", "凶案"],
    "年代": ["年代", "民国", "七零", "八零", "知青"],
    "亲情": ["亲情", "family", "母女", "父子", "催泪"],
    "科幻": ["科幻", "末世", "系统", "星际", "未来"],
    "玄幻": ["玄幻", "仙侠", "修仙", "灵异", "神豪"],
}

# ---------- 套路信号词典（从简介/标签识别爽点套路） ----------
TROPE_KW = {
    "打脸反转": ["打脸", "反转", "扮猪吃虎", "真实身份", "身份揭示", "隐藏大佬", "马甲", "身份曝光"],
    "先婚后爱": ["闪婚", "契约", "隐婚", "先婚后爱", "假结婚", "领证"],
    "重生复仇": ["重生", "重来", "复仇", "报复", "手撕", "反击"],
    "逆袭崛起": ["逆袭", "崛起", "翻身", "白手起家", "登顶", "封神"],
    "身份反差": ["赘婿", "首富", "隐藏身份", "扮穷", "低调", "扮猪", "深藏"],
    "误会虐恋": ["误会", "错过", "虐恋", "追妻", "火葬场", "后悔", "追悔"],
    "马甲揭穿": ["马甲", "小号", "神秘", "隐藏大佬", "揭穿", "身份揭晓"],
    "护短宠溺": ["宠", "护短", "撒糖", "独宠", "娇妻", "掌心宠"],
    "失忆认亲": ["失忆", "认亲", "亲子", "血缘", "错抱", "认回"],
    "系统金手指": ["系统", "金手指", "签到", "外挂", "面板", "神豪"],
}

# CSV 表头别名 -> 标准字段
FIELD_ALIASES = {
    "title": ["title", "剧名", "名称", "作品", "标题", "剧集"],
    "genre": ["genre", "题材", "类型", "分类", "赛道"],
    "platform": ["platform", "平台", "渠道", "来源"],
    "episodes": ["episodes", "集数", "总集数", "共几集"],
    "update_pace": ["update_pace", "更新节奏", "更新", "更新频率", "排播"],
    "views": ["views", "播放", "播放量", "plays", "热度", "观看量"],
    "likes": ["likes", "点赞", "赞", "点赞量"],
    "follows": ["follows", "追更", "在追", "收藏", "追剧"],
    "finish_rate": ["finish_rate", "完播率", "完播", "完成率"],
    "paywall_ep": ["paywall_ep", "付费墙", "付费集", "付费卡点", "收费集", "第几集付费"],
    "lead_type": ["lead_type", "主演类型", "演员类型", "主演", "出演"],
    "synopsis": ["synopsis", "简介", "梗概", "剧情", "介绍", "看点"],
    "tags": ["tags", "标签", "卖点", "关键词", "亮点"],
    "release_date": ["release_date", "上线日期", "上线", "发布日期", "开播", "首播"],
}

NUM_FIELDS = ("episodes", "views", "likes", "follows", "paywall_ep")


def read_text(path):
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "utf-8", "gb18030", "utf-16"):
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, UnicodeError):
            continue
    return raw.decode("utf-8", errors="replace")


def load_json(path):
    return json.loads(read_text(path))


def parse_number(v):
    """把 '1.2亿' '9800万' '3,500' '12w' 等统一成整数。返回 None 表示无值。"""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    if not s or s in ("-", "—", "无", "n/a", "N/A"):
        return None
    s = s.replace(",", "").replace("，", "").replace(" ", "")
    mult = 1.0
    if s.endswith("亿"):
        mult = 1e8
        s = s[:-1]
    elif s.endswith("万") or s.lower().endswith("w"):
        mult = 1e4
        s = s[:-1]
    m = re.search(r"-?\d+(\.\d+)?", s)
    if not m:
        return None
    try:
        return int(round(float(m.group(0)) * mult))
    except ValueError:
        return None


def parse_percent(v):
    """完播率等百分数 -> 浮点(0-100)。"""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("%", "").replace("％", "")
    m = re.search(r"-?\d+(\.\d+)?", s)
    return float(m.group(0)) if m else None


def canon_genre(raw):
    """自由题材 -> 标准题材（可能命中多个，返回首个主类 + 全部命中列表）。"""
    if not raw:
        return "", []
    text = str(raw)
    hits = []
    for canon, kws in GENRE_CANON.items():
        if any(kw in text for kw in kws):
            hits.append(canon)
    primary = hits[0] if hits else str(raw).strip()
    return primary, hits


def detect_tropes(synopsis, tags):
    """从简介+标签识别套路，返回命中套路名列表（去重保序）。"""
    text = (synopsis or "") + " " + " ".join(tags or [])
    out = []
    for trope, kws in TROPE_KW.items():
        if any(kw in text for kw in kws):
            out.append(trope)
    return out


def norm_tags(v):
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    return [t.strip() for t in re.split(r"[;；,，、/|]", str(v)) if t.strip()]


def normalize_row(raw):
    """把一条原始记录归一成标准竞品剧对象。"""
    d = {}
    for std, aliases in FIELD_ALIASES.items():
        val = None
        for a in aliases:
            if a in raw and raw[a] not in (None, ""):
                val = raw[a]
                break
        d[std] = val
    rec = {
        "title": (str(d["title"]).strip() if d["title"] else "未命名剧"),
        "platform": (str(d["platform"]).strip() if d["platform"] else ""),
        "update_pace": (str(d["update_pace"]).strip() if d["update_pace"] else ""),
        "lead_type": (str(d["lead_type"]).strip() if d["lead_type"] else ""),
        "synopsis": (str(d["synopsis"]).strip() if d["synopsis"] else ""),
        "release_date": (str(d["release_date"]).strip() if d["release_date"] else ""),
        "tags": norm_tags(d["tags"]),
    }
    for f in NUM_FIELDS:
        rec[f] = parse_number(d[f])
    rec["finish_rate"] = parse_percent(d["finish_rate"])
    primary, all_g = canon_genre(d["genre"] or " ".join(rec["tags"]) or rec["synopsis"])
    rec["genre"] = primary
    rec["genre_all"] = all_g
    rec["tropes"] = detect_tropes(rec["synopsis"], rec["tags"])
    return rec


def load_csv(path):
    text = read_text(path)
    dialect = "excel-tab" if path.lower().endswith((".tsv", ".txt")) and "\t" in text[:2000] else "excel"
    rdr = csv.DictReader(io.StringIO(text), dialect=dialect)
    rows = []
    for r in rdr:
        clean = {(k.strip() if k else k): (v.strip() if isinstance(v, str) else v) for k, v in r.items()}
        rows.append(clean)
    return rows


def load_json_list(path):
    data = load_json(path)
    if isinstance(data, dict):
        for key in ("rivals", "items", "list", "data", "dramas"):
            if key in data and isinstance(data[key], list):
                return data[key]
        return [data]
    if isinstance(data, list):
        return data
    return []


def main():
    ap = argparse.ArgumentParser(description="AI 短剧竞品对标·多源导入归一")
    ap.add_argument("--json", action="append", default=[], help="竞品清单 JSON（可多次）")
    ap.add_argument("--csv", action="append", default=[], help="竞品清单 CSV/TSV（可多次）")
    ap.add_argument("--my-genre", default="", help="我方计划题材（用于差异化空白定位）")
    ap.add_argument("--my-platform", default="", help="我方目标平台")
    ap.add_argument("--out", default="_rival_ir.json", help="输出 IR 路径")
    args = ap.parse_args()

    raw_rows = []
    for p in args.json:
        if not os.path.exists(p):
            print("⚠️ 跳过不存在的 JSON：" + p)
            continue
        raw_rows.extend(load_json_list(p))
    for p in args.csv:
        if not os.path.exists(p):
            print("⚠️ 跳过不存在的 CSV：" + p)
            continue
        raw_rows.extend(load_csv(p))

    if not raw_rows:
        print("❌ 未导入任何竞品记录，请用 --json 或 --csv 指定输入。")
        sys.exit(1)

    rivals = [normalize_row(r) for r in raw_rows]
    # 去重：同名同平台合并（保留字段更全的一条）
    seen = {}
    for r in rivals:
        key = (r["title"], r["platform"])
        if key not in seen or sum(1 for v in r.values() if v) > sum(1 for v in seen[key].values() if v):
            seen[key] = r
    rivals = list(seen.values())

    ir = {
        "schema": "aladin-drama-rival/ir@1",
        "my_plan": {"genre": args.my_genre.strip(), "platform": args.my_platform.strip()},
        "count": len(rivals),
        "rivals": rivals,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(ir, f, ensure_ascii=False, indent=2)

    with_views = sum(1 for r in rivals if r["views"])
    genres = sorted({r["genre"] for r in rivals if r["genre"]})
    print("✅ 导入归一完成：" + str(len(rivals)) + " 部竞品剧 -> " + args.out)
    print("   题材覆盖：" + ("、".join(genres) if genres else "（未识别）"))
    print("   含播放量数据：" + str(with_views) + " 部；我方计划题材：" + (args.my_genre or "（未指定）"))


if __name__ == "__main__":
    main()
