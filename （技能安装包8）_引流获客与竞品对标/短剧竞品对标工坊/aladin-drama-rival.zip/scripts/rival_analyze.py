# -*- coding: utf-8 -*-
"""aladin-drama-rival · rival_analyze.py
AI 短剧竞品对标·拆解分析：读 _rival_ir.json，产出竞品对标结论 _rival.json。

拆解维度（全部确定性、可复算）：
  1) 题材热度分布：各题材剧数 / 均播放 / 竞争密度（扎堆 vs 蓝海）
  2) 套路频次：全局爆款套路命中排行（从简介/标签识别）
  3) 差异化空白矩阵：题材 × 套路 组合矩阵，标出扎堆格与空白格（= 机会点）
  4) 排播规律：集数 / 更新节奏 / 付费墙位置分布（竞品普遍怎么排）
  5) 竞品强弱评分：播放归一×0.45 + 互动率×0.30 + 完播×0.25 -> 100 分制排行 + 标杆剧
  6) 对标建议 & feedback 回灌：给 topic(差异化选题) / money(付费墙参考) / script(高频套路)

用法：
  python rival_analyze.py --ir _rival_ir.json --out _rival.json

仅 Python 标准库。语义级创意（差异化定位话术、套路创新）交给模型+人工。
"""
import argparse
import json
import sys

from rival_ingest import GENRE_CANON, TROPE_KW, read_text  # 复用词典与解码


def load_json(path):
    return json.loads(read_text(path))


def _safe_div(a, b):
    return (a / b) if b else 0.0


def analyze_genre(rivals):
    """题材热度分布 + 竞争密度分级。"""
    buckets = {}
    for r in rivals:
        g = r.get("genre") or "未分类"
        buckets.setdefault(g, []).append(r)
    total = len(rivals) or 1
    rows = []
    for g, items in buckets.items():
        views = [r["views"] for r in items if r["views"]]
        avg_v = int(sum(views) / len(views)) if views else 0
        share = round(len(items) / total * 100, 1)
        rows.append({
            "genre": g,
            "count": len(items),
            "share_pct": share,
            "avg_views": avg_v,
        })
    rows.sort(key=lambda x: (-x["count"], -x["avg_views"]))
    # 竞争密度：占比 >=25% 或 >=3 部为「扎堆」，1 部为「蓝海苗头」
    for row in rows:
        if row["count"] >= 3 or row["share_pct"] >= 25.0:
            row["density"] = "扎堆"
        elif row["count"] == 1:
            row["density"] = "蓝海苗头"
        else:
            row["density"] = "适中"
    return rows


def analyze_tropes(rivals):
    freq = {}
    for r in rivals:
        for t in r.get("tropes", []):
            freq[t] = freq.get(t, 0) + 1
    rows = [{"trope": t, "count": c} for t, c in freq.items()]
    rows.sort(key=lambda x: (-x["count"], x["trope"]))
    return rows


def build_matrix(rivals):
    """题材 × 套路 矩阵。返回 {genre:{trope:count}} 与扎堆/空白清单。"""
    genres = []
    for r in rivals:
        g = r.get("genre") or "未分类"
        if g not in genres:
            genres.append(g)
    tropes = list(TROPE_KW.keys())
    cell = {g: {t: 0 for t in tropes} for g in genres}
    for r in rivals:
        g = r.get("genre") or "未分类"
        for t in r.get("tropes", []):
            if t in cell[g]:
                cell[g][t] += 1
    crowded, blanks = [], []
    for g in genres:
        for t in tropes:
            n = cell[g][t]
            if n >= 2:
                crowded.append({"genre": g, "trope": t, "count": n})
    crowded.sort(key=lambda x: -x["count"])
    # 空白机会：出现过的题材里，没有任何一部用过的高价值套路组合
    hot_tropes = [row["trope"] for row in analyze_tropes(rivals)[:5]]
    for g in genres:
        for t in hot_tropes:
            if cell[g][t] == 0:
                blanks.append({"genre": g, "trope": t})
    return {"genres": genres, "tropes": tropes, "cell": cell,
            "crowded": crowded, "blanks": blanks[:12]}


def analyze_scheduling(rivals):
    eps = [r["episodes"] for r in rivals if r["episodes"]]
    pw = [r["paywall_ep"] for r in rivals if r["paywall_ep"]]
    pw_ratio = []
    for r in rivals:
        if r["paywall_ep"] and r["episodes"]:
            pw_ratio.append(r["paywall_ep"] / r["episodes"])
    paces = {}
    for r in rivals:
        p = r.get("update_pace") or "未标注"
        paces[p] = paces.get(p, 0) + 1
    pace_rows = sorted(([{"pace": k, "count": v} for k, v in paces.items()]),
                       key=lambda x: -x["count"])
    return {
        "avg_episodes": int(sum(eps) / len(eps)) if eps else 0,
        "min_episodes": min(eps) if eps else 0,
        "max_episodes": max(eps) if eps else 0,
        "avg_paywall_ep": round(sum(pw) / len(pw), 1) if pw else 0,
        "avg_paywall_ratio_pct": round(sum(pw_ratio) / len(pw_ratio) * 100, 1) if pw_ratio else 0,
        "pace_dist": pace_rows,
    }


def score_rivals(rivals):
    """竞品强弱 100 分制：播放归一×0.45 + 互动率×0.30 + 完播×0.25。"""
    max_v = max([r["views"] for r in rivals if r["views"]] or [0]) or 1
    rows = []
    for r in rivals:
        v = r["views"] or 0
        views_n = _safe_div(v, max_v)  # 0-1
        eng = _safe_div((r["likes"] or 0) + (r["follows"] or 0), v) if v else 0.0
        eng_n = min(eng / 0.15, 1.0)  # 互动率 15% 记满分
        fin_n = min((r["finish_rate"] or 0) / 100.0, 1.0)
        score = round((views_n * 0.45 + eng_n * 0.30 + fin_n * 0.25) * 100, 1)
        rows.append({
            "title": r["title"], "genre": r.get("genre", ""),
            "platform": r.get("platform", ""), "views": v,
            "engage_pct": round(eng * 100, 2), "finish_rate": r.get("finish_rate") or 0,
            "score": score,
        })
    rows.sort(key=lambda x: -x["score"])
    for i, row in enumerate(rows, 1):
        row["rank"] = i
    return rows


def make_feedback(genre_rows, trope_rows, matrix, sched, my_plan):
    """对标建议 + feedback 回灌契约（供 topic / money / script 消费）。"""
    # 差异化选题方向：优先蓝海苗头题材 + 高频套路未被占用的组合
    blue_genres = [g["genre"] for g in genre_rows if g["density"] in ("蓝海苗头", "适中")]
    crowded_genres = [g["genre"] for g in genre_rows if g["density"] == "扎堆"]
    top_tropes = [t["trope"] for t in trope_rows[:3]]
    diff_ideas = []
    for b in matrix["blanks"][:6]:
        diff_ideas.append(b["genre"] + " × " + b["trope"] + "（竞品未覆盖）")

    my_g = my_plan.get("genre", "")
    my_warn = ""
    if my_g and my_g in crowded_genres:
        my_warn = "你计划的题材「" + my_g + "」当前竞品扎堆，需靠差异化套路/人设突围。"
    elif my_g and my_g in blue_genres:
        my_warn = "你计划的题材「" + my_g + "」竞品较少，有先发窗口，可加快排播抢位。"

    return {
        "to_topic": {
            "avoid_crowded_genres": crowded_genres,
            "blue_ocean_genres": blue_genres,
            "differentiation_ideas": diff_ideas,
            "my_genre_note": my_warn,
        },
        "to_money": {
            "benchmark_paywall_ep": sched["avg_paywall_ep"],
            "benchmark_paywall_ratio_pct": sched["avg_paywall_ratio_pct"],
            "note": "竞品付费墙普遍卡在约总集数的 "
                    + str(sched["avg_paywall_ratio_pct"]) + "%，可作为你的付费墙定位参考。",
        },
        "to_script": {
            "high_freq_tropes": top_tropes,
            "note": "高频爆款套路可借鉴其节奏但需换壳创新，避免同质化。",
        },
    }


def main():
    ap = argparse.ArgumentParser(description="AI 短剧竞品对标·拆解分析")
    ap.add_argument("--ir", required=True, help="rival_ingest 产出的 _rival_ir.json")
    ap.add_argument("--out", default="_rival.json", help="分析结论输出")
    args = ap.parse_args()

    ir = load_json(args.ir)
    rivals = ir.get("rivals", [])
    if not rivals:
        print("❌ IR 中无竞品记录。")
        sys.exit(1)
    my_plan = ir.get("my_plan", {})

    genre_rows = analyze_genre(rivals)
    trope_rows = analyze_tropes(rivals)
    matrix = build_matrix(rivals)
    sched = analyze_scheduling(rivals)
    scored = score_rivals(rivals)
    feedback = make_feedback(genre_rows, trope_rows, matrix, sched, my_plan)

    result = {
        "schema": "aladin-drama-rival/analysis@1",
        "count": len(rivals),
        "my_plan": my_plan,
        "genre_distribution": genre_rows,
        "trope_frequency": trope_rows,
        "matrix": matrix,
        "scheduling": sched,
        "ranking": scored,
        "benchmark": scored[0] if scored else None,
        "feedback": feedback,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    bm = scored[0]["title"] if scored else "（无）"
    print("✅ 竞品拆解完成 -> " + args.out)
    print("   竞品 " + str(len(rivals)) + " 部；标杆剧：" + bm
          + "（" + str(scored[0]["score"]) + " 分）" if scored else "")
    print("   扎堆题材：" + ("、".join(feedback["to_topic"]["avoid_crowded_genres"]) or "无")
          + "；蓝海题材：" + ("、".join(feedback["to_topic"]["blue_ocean_genres"]) or "无"))
    print("   差异化机会：" + str(len(matrix["blanks"])) + " 个题材×套路空白格")
    print("   付费墙参考：约第 " + str(sched["avg_paywall_ep"]) + " 集（总集数 "
          + str(sched["avg_paywall_ratio_pct"]) + "% 位置）")


if __name__ == "__main__":
    main()
