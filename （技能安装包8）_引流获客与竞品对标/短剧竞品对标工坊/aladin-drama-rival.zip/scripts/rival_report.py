# -*- coding: utf-8 -*-
"""aladin-drama-rival · rival_report.py
AI 短剧竞品对标·报告渲染：读 _rival.json，产出
  - rival_board.html  自包含对标看板（题材分布条形图 SVG + 差异化矩阵热力图 + 竞品排行 + 机会清单）
  - _rival_report.md  Markdown 对标报告（可直接贴进立项文档）
  - rival_table.csv   竞品台账（Excel 可直接打开，utf-8-sig）

用法：
  python rival_report.py --analysis _rival.json \
      --out-html rival_board.html --out-md _rival_report.md --out-csv rival_table.csv

仅 Python 标准库；不使用 %-格式化以避免 CSS 中的 % 触发格式错误。
"""
import argparse
import csv
import json

from rival_ingest import read_text


def load_json(path):
    return json.loads(read_text(path))


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def fmt_num(n):
    n = n or 0
    if n >= 1e8:
        return str(round(n / 1e8, 2)) + "亿"
    if n >= 1e4:
        return str(round(n / 1e4, 1)) + "万"
    return str(n)


# ---------------- SVG 组件 ----------------

def svg_genre_bars(genre_rows):
    if not genre_rows:
        return "<p>无题材数据</p>"
    rows = genre_rows[:10]
    maxc = max(r["count"] for r in rows) or 1
    bar_w = 460
    line_h = 30
    height = line_h * len(rows) + 20
    parts = ['<svg viewBox="0 0 680 ' + str(height) + '" width="100%" role="img" aria-label="题材分布">']
    color = {"扎堆": "#e5484d", "适中": "#f5a623", "蓝海苗头": "#2ea043"}
    for i, r in enumerate(rows):
        y = 10 + i * line_h
        w = int(bar_w * r["count"] / maxc)
        c = color.get(r["density"], "#8a8f98")
        parts.append('<text x="0" y="' + str(y + 15) + '" font-size="13" fill="var(--fg)">'
                     + esc(r["genre"]) + '</text>')
        parts.append('<rect x="90" y="' + str(y + 3) + '" width="' + str(w)
                     + '" height="18" rx="4" fill="' + c + '"/>')
        parts.append('<text x="' + str(90 + w + 6) + '" y="' + str(y + 16)
                     + '" font-size="12" fill="var(--muted)">' + str(r["count"]) + " 部 · 均"
                     + fmt_num(r["avg_views"]) + " · " + esc(r["density"]) + '</text>')
    parts.append("</svg>")
    return "".join(parts)


def html_matrix(matrix):
    genres = matrix["genres"]
    tropes = matrix["tropes"]
    cell = matrix["cell"]
    if not genres:
        return "<p>无矩阵数据</p>"
    th = "".join('<th class="rot">' + esc(t) + "</th>" for t in tropes)
    body = []
    for g in genres:
        tds = []
        for t in tropes:
            n = cell[g][t]
            if n == 0:
                cls, txt = "c0", ""
            elif n == 1:
                cls, txt = "c1", "1"
            else:
                cls, txt = "c2", str(n)
            tds.append('<td class="' + cls + '">' + txt + "</td>")
        body.append("<tr><th>" + esc(g) + "</th>" + "".join(tds) + "</tr>")
    return ('<table class="mx"><thead><tr><th>题材＼套路</th>' + th + "</tr></thead><tbody>"
            + "".join(body) + "</tbody></table>")


def html_ranking(rows):
    trs = []
    for r in rows[:15]:
        trs.append("<tr><td>" + str(r["rank"]) + "</td><td>" + esc(r["title"])
                   + "</td><td>" + esc(r["genre"]) + "</td><td>" + esc(r["platform"])
                   + "</td><td>" + fmt_num(r["views"]) + "</td><td>" + str(r["engage_pct"])
                   + "%</td><td>" + str(r["finish_rate"]) + "%</td><td><b>" + str(r["score"])
                   + "</b></td></tr>")
    return ("<table class=\"rk\"><thead><tr><th>#</th><th>剧名</th><th>题材</th><th>平台</th>"
            "<th>播放</th><th>互动率</th><th>完播</th><th>强度分</th></tr></thead><tbody>"
            + "".join(trs) + "</tbody></table>")


def html_opportunities(fb):
    items = []
    for idea in fb["to_topic"]["differentiation_ideas"]:
        items.append("<li>" + esc(idea) + "</li>")
    if not items:
        items.append("<li>竞品已较充分覆盖主流题材×套路组合，建议在人设、视听或节奏上做差异化。</li>")
    note = fb["to_topic"].get("my_genre_note", "")
    warn = ('<p class="warn">' + esc(note) + "</p>") if note else ""
    return warn + "<ul class=\"opp\">" + "".join(items) + "</ul>"


def build_html(a):
    fb = a["feedback"]
    sched = a["scheduling"]
    bm = a.get("benchmark")
    bm_line = ""
    if bm:
        bm_line = ("标杆剧 <b>" + esc(bm["title"]) + "</b>（" + esc(bm["genre"]) + " · "
                   + fmt_num(bm["views"]) + " 播放 · 强度 " + str(bm["score"]) + " 分）")
    css = (
        ":root{--bg:#ffffff;--fg:#1c2024;--muted:#6b7280;--card:#f7f8fa;--line:#e6e8eb;"
        "--accent:#6e56cf}"
        "*{box-sizing:border-box}"
        "body{margin:0;background:var(--bg);color:var(--fg);"
        "font-family:'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;line-height:1.6}"
        ".wrap{max-width:960px;margin:0 auto;padding:28px 20px 60px}"
        "h1{font-size:24px;margin:0 0 4px}"
        ".sub{color:var(--muted);font-size:13px;margin-bottom:20px}"
        ".card{background:var(--card);border:1px solid var(--line);border-radius:12px;"
        "padding:18px 20px;margin:16px 0}"
        ".card h2{font-size:16px;margin:0 0 12px;display:flex;align-items:center;gap:8px}"
        ".dot{width:8px;height:8px;border-radius:50%;background:var(--accent);display:inline-block}"
        ".kpi{display:flex;flex-wrap:wrap;gap:14px}"
        ".kpi div{flex:1;min-width:130px;background:var(--bg);border:1px solid var(--line);"
        "border-radius:10px;padding:12px 14px}"
        ".kpi b{font-size:20px;display:block}"
        ".kpi span{font-size:12px;color:var(--muted)}"
        "table{border-collapse:collapse;width:100%;font-size:13px}"
        "th,td{border:1px solid var(--line);padding:6px 8px;text-align:center}"
        ".rk th{background:#eceef1}"
        ".rk td:nth-child(2){text-align:left}"
        ".mx td,.mx th{padding:4px 6px;font-size:12px}"
        ".mx th{background:#eceef1}"
        ".mx .c0{background:#f0fdf4}.mx .c1{background:#fde8e8}.mx .c2{background:#f6c2c2;font-weight:700}"
        ".opp li{margin:4px 0}"
        ".warn{background:#fff4e5;border-left:3px solid #f5a623;padding:8px 12px;border-radius:6px;"
        "font-size:13px}"
        ".foot{color:var(--muted);font-size:12px;text-align:center;margin-top:30px}"
        ".legend{font-size:12px;color:var(--muted);margin-top:8px}"
        ".legend b{color:var(--fg)}"
    )
    genres = a["genre_distribution"]
    tropes = a["trope_frequency"]
    top_tropes = "、".join(t["trope"] + "(" + str(t["count"]) + ")" for t in tropes[:6]) or "（未识别）"

    html = []
    html.append("<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">")
    html.append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
    html.append("<title>阿拉丁·AI短剧竞品对标看板</title><style>" + css + "</style></head><body><div class=\"wrap\">")
    html.append("<h1>阿拉丁 · AI短剧竞品对标看板</h1>")
    html.append("<div class=\"sub\">竞品 " + str(a["count"]) + " 部　|　" + bm_line
                + "　|　由阿拉丁 AI短剧竞品对标工坊生成</div>")

    # KPI
    html.append("<div class=\"card\"><h2><span class=\"dot\"></span>关键指标</h2><div class=\"kpi\">")
    html.append("<div><b>" + str(a["count"]) + "</b><span>竞品剧总数</span></div>")
    html.append("<div><b>" + str(sched["avg_episodes"]) + "</b><span>平均集数（"
                + str(sched["min_episodes"]) + "-" + str(sched["max_episodes"]) + "）</span></div>")
    html.append("<div><b>第" + str(sched["avg_paywall_ep"]) + "集</b><span>平均付费墙位置（约"
                + str(sched["avg_paywall_ratio_pct"]) + "%）</span></div>")
    html.append("<div><b>" + str(len(a["matrix"]["blanks"])) + "</b><span>差异化空白机会</span></div>")
    html.append("</div></div>")

    # 题材分布
    html.append("<div class=\"card\"><h2><span class=\"dot\"></span>题材热度与竞争密度</h2>")
    html.append(svg_genre_bars(genres))
    html.append("<div class=\"legend\">颜色：<b style=\"color:#e5484d\">扎堆</b>（避免硬碰硬）　"
                "<b style=\"color:#f5a623\">适中</b>　<b style=\"color:#2ea043\">蓝海苗头</b>（先发窗口）</div></div>")

    # 套路频次
    html.append("<div class=\"card\"><h2><span class=\"dot\"></span>高频爆款套路</h2>"
                "<p style=\"font-size:13px\">" + esc(top_tropes) + "</p>"
                "<div class=\"legend\">借鉴节奏但需换壳创新，避免同质化。</div></div>")

    # 差异化矩阵
    html.append("<div class=\"card\"><h2><span class=\"dot\"></span>差异化矩阵（题材 × 套路）</h2>")
    html.append(html_matrix(a["matrix"]))
    html.append("<div class=\"legend\"><b>绿=空白</b>（可切入）　<b>浅红=1 部</b>　<b>深红=2 部以上</b>（扎堆）</div></div>")

    # 竞品排行
    html.append("<div class=\"card\"><h2><span class=\"dot\"></span>竞品强度排行</h2>")
    html.append(html_ranking(a["ranking"]))
    html.append("</div>")

    # 机会与建议
    html.append("<div class=\"card\"><h2><span class=\"dot\"></span>差异化机会与对标建议</h2>")
    html.append(html_opportunities(fb))
    html.append("<div class=\"legend\">付费墙参考：竞品普遍卡在第 " + str(sched["avg_paywall_ep"])
                + " 集（约总集数 " + str(sched["avg_paywall_ratio_pct"])
                + "%）。回灌 topic 选题 / money 变现 / script 剧本。</div></div>")

    html.append("<div class=\"foot\">阿拉丁 · AI短剧创作闭环 · 竞品对标工坊　|　纯本地生成，竞品数据不出本机</div>")
    html.append("</div></body></html>")
    return "".join(html)


def build_md(a):
    fb = a["feedback"]
    sched = a["scheduling"]
    L = []
    L.append("# 阿拉丁 · AI短剧竞品对标报告\n")
    L.append("> 竞品 " + str(a["count"]) + " 部，由阿拉丁 AI短剧竞品对标工坊生成（纯本地，数据不出本机）。\n")
    bm = a.get("benchmark")
    if bm:
        L.append("**标杆剧**：" + bm["title"] + "（" + bm["genre"] + " · "
                 + fmt_num(bm["views"]) + " 播放 · 强度 " + str(bm["score"]) + " 分）\n")
    L.append("## 一、题材热度与竞争密度\n")
    L.append("| 题材 | 剧数 | 占比 | 均播放 | 竞争密度 |")
    L.append("|---|---|---|---|---|")
    for r in a["genre_distribution"]:
        L.append("| " + r["genre"] + " | " + str(r["count"]) + " | " + str(r["share_pct"])
                 + "% | " + fmt_num(r["avg_views"]) + " | " + r["density"] + " |")
    L.append("\n## 二、高频爆款套路\n")
    for t in a["trope_frequency"][:8]:
        L.append("- " + t["trope"] + "：" + str(t["count"]) + " 部命中")
    L.append("\n## 三、排播规律\n")
    L.append("- 平均集数：" + str(sched["avg_episodes"]) + " 集（区间 "
             + str(sched["min_episodes"]) + "-" + str(sched["max_episodes"]) + "）")
    L.append("- 付费墙位置：平均第 " + str(sched["avg_paywall_ep"]) + " 集（约总集数 "
             + str(sched["avg_paywall_ratio_pct"]) + "%）")
    L.append("- 更新节奏分布：" + ("；".join(p["pace"] + "×" + str(p["count"])
             for p in sched["pace_dist"]) or "未标注"))
    L.append("\n## 四、竞品强度排行\n")
    L.append("| # | 剧名 | 题材 | 平台 | 播放 | 互动率 | 完播 | 强度分 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for r in a["ranking"][:15]:
        L.append("| " + str(r["rank"]) + " | " + r["title"] + " | " + r["genre"] + " | "
                 + r["platform"] + " | " + fmt_num(r["views"]) + " | " + str(r["engage_pct"])
                 + "% | " + str(r["finish_rate"]) + "% | " + str(r["score"]) + " |")
    L.append("\n## 五、差异化机会（题材 × 套路空白）\n")
    ideas = fb["to_topic"]["differentiation_ideas"]
    if ideas:
        for idea in ideas:
            L.append("- " + idea)
    else:
        L.append("- 主流组合已被覆盖，建议在人设/视听/节奏做差异化。")
    note = fb["to_topic"].get("my_genre_note", "")
    if note:
        L.append("\n> ⚠️ " + note)
    L.append("\n## 六、对标建议（回灌闭环）\n")
    L.append("- **选题（topic）**：避开扎堆题材 " + ("、".join(fb["to_topic"]["avoid_crowded_genres"]) or "无")
             + "；关注蓝海 " + ("、".join(fb["to_topic"]["blue_ocean_genres"]) or "无"))
    L.append("- **变现（money）**：付费墙参考第 " + str(fb["to_money"]["benchmark_paywall_ep"])
             + " 集（约 " + str(fb["to_money"]["benchmark_paywall_ratio_pct"]) + "%）")
    L.append("- **剧本（script）**：高频套路 " + ("、".join(fb["to_script"]["high_freq_tropes"]) or "无")
             + "，借鉴节奏但需换壳创新")
    L.append("\n---\n_阿拉丁 · AI短剧创作闭环 · 竞品对标工坊_\n")
    return "\n".join(L)


def build_csv_rows(a):
    rows = [["排名", "剧名", "题材", "平台", "播放量", "互动率(%)", "完播率(%)", "强度分"]]
    for r in a["ranking"]:
        rows.append([r["rank"], r["title"], r["genre"], r["platform"], r["views"],
                     r["engage_pct"], r["finish_rate"], r["score"]])
    return rows


def main():
    ap = argparse.ArgumentParser(description="AI 短剧竞品对标·报告渲染")
    ap.add_argument("--analysis", required=True, help="rival_analyze 产出的 _rival.json")
    ap.add_argument("--out-html", default="rival_board.html")
    ap.add_argument("--out-md", default="_rival_report.md")
    ap.add_argument("--out-csv", default="rival_table.csv")
    args = ap.parse_args()

    a = load_json(args.analysis)

    with open(args.out_html, "w", encoding="utf-8") as f:
        f.write(build_html(a))
    with open(args.out_md, "w", encoding="utf-8") as f:
        f.write(build_md(a))
    with open(args.out_csv, "w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerows(build_csv_rows(a))

    print("✅ 报告已生成：")
    print("   看板 HTML：" + args.out_html)
    print("   报告 MD  ：" + args.out_md)
    print("   台账 CSV ：" + args.out_csv)


if __name__ == "__main__":
    main()
