---

name: axin666
description: 面向实体商家的短剧营销视频脚本创作。生成模仿'新村联·武汉江汉路'爆款形式的群口宣讲式短视频脚本。当用户要求创作短视频营销脚本、推广视频脚本、群口宣讲脚本，或任何面向本地实体商家（实体老板）的视频广告脚本时使用。覆盖脚本结构、镜头拆解、城市/行业定制与产品定位适配。触发词：短剧营销脚本, 群口宣讲, 视频文案, 实体老板获客, AI做剧情获客, 豆包排名, GEO获客脚本。
---




# Short Drama Marketing Script (短剧营销视频脚本创作)

## Overview

Generate viral-style short video marketing scripts for local business owners using the "group announcement" (群口宣讲) format — a team-formation, ritual-style video where 15-20+ people in matching T-shirts march in formation at a city landmark, with a lead speaker announcing a product/service to the camera.

The format is modeled after the "新村联·武汉江汉路" viral video, which used a 5-segment structure (city announcement → solemn declaration → target audience → service → price) to generate massive engagement for a kitchen/bathroom renovation service.

## When to Use This Skill

- User asks for short video marketing scripts (短视频营销脚本/文案)
- User asks for "群口宣讲" style video scripts
- User wants to promote a product/service to physical business owners (实体老板)
- User references the "新村联" video format or similar team-formation ads
- User wants to create viral-style promotional video content
- User mentions: 获客, 排名, AI做视频, 剧情获客, 实体老板, or similar marketing terms

## Core Script Structure (6-Segment Template)

Every script follows this fixed 6-segment structure. Only the bracketed variables change:

```
【地点+气势】今天我们在——[城市地标]——
【仪式升级】郑重宣布——
【目标点名】点了小红心的[目标人群]——
【业务亮相】[产品/服务核心描述]——
【效果说明】[一句话说清效果，让外行秒懂]——
【价格落地】只要[价格]—— / 不要钱——
```

### Segment Details

| Segment | Duration | Visual | Emotion | Marketing Logic |
|---------|----------|--------|---------|-----------------|
| 地点+气势 | 0-5s | Team in matching T-shirts marching in formation at landmark | 庄重 | Ritual opening + geographic trust |
| 仪式升级 | 5-8s | Lead speaker stops, faces camera, all stop | 紧张 | Raise expectation |
| 目标点名 | 8-12s | Team points at camera in unison | 亲切 | "This video is for ME" |
| 业务亮相 | 12-17s | Lead speaker gestures forward | 专业 | Name the service |
| 效果说明 | 17-21s | Lead speaker demonstrates, team follows | 震撼 | One sentence, plain language |
| 价格落地 | 21-24s | Team points at camera, shouts together | 冲击 | Extreme price anchor |

## Key Design Principles

### 1. "点了小红心的" — Engagement Hook

Every script must include "点了小红心的" before the target audience description. This phrase serves triple duty:
- Guides viewers to click the heart (boosts video engagement metrics)
- Makes those who already clicked feel "called out" — they feel special
- Those who haven't clicked will subconsciously click after hearing it

### 2. City Landmarks — Geographic Trust

Each script must specify a real, recognizable city landmark (步行街/广场). This creates:
- Local trust: "They're at MY city's landmark"
- Built-in traffic: famous landmarks have search volume
- Visual recognition: viewers identify the city in 1 second

### 3. Unified White T-Shirts — Brand Consistency

All team members (including lead speaker) wear identical white T-shirts:
- No color differentiation between lead and team — distinction comes from positioning (lead walks front) and action (lead speaks, team follows)
- White works against any landmark background
- Batch production requires only one T-shirt type
- "A group of identically-dressed people moving in unison" is more visually striking than "one special + many ordinary"

### 4. Three "不" Selling Points (for AI video products)

When the product involves AI-generated content, use three consecutive "不" to eliminate all objections:
- **不需要用手机拍** — eliminates "I don't know how to film"
- **不需要出镜** — eliminates "I don't want to show my face"
- **每天用AI做几十条** — eliminates "I don't have time"

### 5. Effect Statement — Plain Language, No Jargon

Never use technical terms (GEO, SEO, ranking algorithm). Instead, describe the outcome in one sentence anyone can understand:
- BAD: "做GEO获客排名优化"
- GOOD: "顾客一搜行业，第一个就是你"
- BAD: "AI视频批量生成"
- GOOD: "不需要用手机拍，不需要出镜，每天用AI做几十条视频"

## Customization Variables

### Variable 1: City Landmark

Choose landmarks that are:
- Famous enough for instant recognition
- Open spaces suitable for team formation (步行街/广场 preferred)
- Associated with commerce/business (not tourist-only sites)

15-city reference list (see references/city_landmarks.md for full list):
重庆·解放碑 / 成都·春熙路 / 郑州·二七广场 / 长沙·黄兴路 / 义乌·国际商贸城 / 武汉·江汉路 / 西安·大雁塔 / 昆明·南屏街 / 南昌·八一广场 / 南宁·朝阳广场 / 北京·王府井 / 上海·南京路 / 广州·北京路 / 深圳·华强北 / 杭州·湖滨步行街

### Variable 2: Target Audience

Two modes:
- **Unified mode** (default): "本地的实体老板" — covers all physical business types, one video hits all industries
- **Industry-specific mode** (when user specifies): "教培机构校长" / "中医大健康老板" / "餐饮老板" / "汽修老板" etc.

Always prefix with "点了小红心的".

### Variable 3: Product/Service

The core offering description. Must be stated in one short phrase:
- "免费教你用AI做剧情获客"
- "找我们做豆包排名"
- "做厨卫翻新"

### Variable 4: Effect Statement

One sentence explaining what the customer gets, in plain language:
- "顾客一搜'佛山家具厂'，第一个就是你"
- "不需要用手机拍，不需要出镜，每天用AI做几十条视频"
- "家长一搜'周口培训班'，第一个就是你"

### Variable 5: Price

- "只要199" / "只要9000元" / "不要钱"
- Must be the final segment — ends on the strongest hook

## Shot Breakdown Format

Each script must include a shot-by-shot breakdown table:

| 秒数 | 画面 | 字幕/台词 |
|------|------|----------|
| 0-5s | [City landmark], team in white T-shirts marching forward, lead speaker at front | 今天我们在——[城市地标]—— |
| 5-8s | Lead speaker stops, faces camera, all stop | 郑重宣布—— |
| 8-12s | Team points at camera in unison | 点了小红心的[目标人群]—— |
| 12-17s | Lead speaker gestures forward, team follows | [产品/服务描述]—— |
| 17-21s | Lead speaker demonstrates effect, team follows | [效果说明]—— |
| 21-24s | Team points at camera, shouts together | 只要[价格]—— / 不要钱—— |

## Output Format

Generate an HTML file with:
1. Header with version tag and subtitle
2. Product change summary box (if updating from previous version)
3. Unified template box (dark background, highlighted variables)
4. Design principle cards (3-column grid)
5. Script cards (one per city), each containing:
   - Number badge + city tag
   - Full text (key phrases highlighted)
   - Shot breakdown table
6. Production notes (key shot details, costume notes)
7. Footer with version info

## Adaptation Guidelines

### When Product Changes

Only 3 segments change (业务亮相 / 效果说明 / 价格落地). The other 3 (地点+气势 / 仪式升级 / 目标点名) remain identical. This means switching products requires editing only ~40% of the script.

### When Adding Cities

Copy any existing city's script card, change only:
1. City name + landmark name in segment 1
2. City name in the shot table's 0-5s description

Everything else stays identical.

### When Targeting Specific Industries

Replace "本地的实体老板" with industry-specific term:
- Education: "教培机构校长" + search term "周口培训班" + search subject "家长一搜"
- Healthcare: "中医大健康老板" + search term "上海中医馆" + search subject "客人一搜"
- Generic: "本地的实体老板" + search term "城市+行业" + search subject "顾客一搜"

## Resources

### references/
- `city_landmarks.md` — Full 15-city landmark reference with T-shirt color history (now unified to white)
- `script_evolution.md` — Version history showing how the format evolved from V1 (industry-specific, colored T-shirts) to V4 (unified "实体老板", white T-shirts)

### assets/
- (No assets needed — scripts are generated as HTML output)

## Common Mistakes to Avoid

1. **Do NOT use technical jargon** — "GEO获客" means nothing to a restaurant owner. Always translate to "顾客一搜就看到你"
2. **Do NOT skip "点了小红心的"** — This is the engagement driver; without it the video loses its data-boosting mechanism
3. **Do NOT differentiate lead speaker's clothing** — All team members wear identical white T-shirts
4. **Do NOT add dialogue beyond the template** — The format's power is in its brevity and ritual; extra words dilute impact
5. **Do NOT use abstract marketing language** — "赋能" "闭环" "矩阵" are forbidden; use "顾客一搜" "第一个就是你" "不要钱"
6. **Do NOT forget the city name** — Local trust is a core conversion driver; omitting the city name kills local engagement
