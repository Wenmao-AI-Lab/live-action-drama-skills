# City Landmarks Reference

## 15-City Landmark List (V4 Unified)

All cities use identical white T-shirts. The only variable per city is the landmark name.

| # | City | Landmark | Region |
|---|------|----------|--------|
| 01 | 重庆 | 解放碑 | 西南 |
| 02 | 成都 | 春熙路 | 西南 |
| 03 | 郑州 | 二七广场 | 华中 |
| 04 | 长沙 | 黄兴路 | 华中 |
| 05 | 义乌 | 国际商贸城 | 华东 |
| 06 | 武汉 | 江汉路 | 华中 |
| 07 | 西安 | 大雁塔广场 | 西北 |
| 08 | 昆明 | 南屏街 | 西南 |
| 09 | 南昌 | 八一广场 | 华东 |
| 10 | 南宁 | 朝阳广场 | 华南 |
| 11 | 北京 | 王府井大街 | 华北 |
| 12 | 上海 | 南京路步行街 | 华东 |
| 13 | 广州 | 北京路步行街 | 华南 |
| 14 | 深圳 | 华强北步行街 | 华南 |
| 15 | 杭州 | 湖滨步行街 | 华东 |

## Landmark Selection Criteria

When adding new cities, choose landmarks that meet ALL of the following:

1. **Instantly recognizable** — A local person sees 1 frame and knows the city
2. **Open space** — Wide enough for 15-20 people to march in formation (步行街/广场 preferred over narrow streets)
3. **Commerce-adjacent** — Associated with shopping/business district, not pure tourist site
4. **Pedestrian-accessible** — No need for special permits to film with a team
5. **Good lighting** — Open-air, natural light preferred

## T-Shirt Color History

- V1-V3: Each city had a different color (red/blue/orange/green/yellow/purple/gray/teal/brown/white/navy/wine/green/skyblue/rose)
- V4 (current): **All cities unified to white T-shirts** — simplifies batch production, works against any background, stronger team visual

## Industry-Specific City+Search Term Examples

When using industry-specific mode instead of unified "实体老板":

| Industry | City | Landmark | Target Audience | Search Term | Search Subject |
|----------|------|----------|----------------|-------------|----------------|
| 教培 | 周口 | 五一广场 | 教培机构校长 | 周口培训班 | 家长一搜 |
| 中医大健康 | 上海 | 豫园 | 中医大健康老板 | 上海中医馆 | 客人一搜 |
| 餐饮 | 重庆 | 解放碑 | 餐饮老板 | 重庆吃饭 | 顾客一搜 |
| 汽修 | 郑州 | 二七广场 | 汽修老板 | 郑州修车 | 顾客一搜 |
| 建材 | 成都 | 春熙路 | 建材老板 | 成都建材 | 顾客一搜 |
| 批发 | 义乌 | 国际商贸城 | 批发老板 | 义乌批发 | 顾客一搜 |
| 工厂 | 长沙 | 黄兴路 | 工厂老板 | 长沙工厂 | 顾客一搜 |
| 装修 | 武汉 | 江汉路 | 装修老板 | 武汉装修 | 顾客一搜 |
| 五金 | 西安 | 大雁塔 | 五金老板 | 西安五金 | 顾客一搜 |
| 茶叶 | 昆明 | 南屏街 | 茶叶老板 | 昆明茶叶 | 顾客一搜 |
| 家具 | 南昌 | 八一广场 | 家具老板 | 南昌家具 | 顾客一搜 |
| 生鲜 | 南宁 | 朝阳广场 | 生鲜老板 | 南宁生鲜 | 顾客一搜 |

## Search Term Construction Rules

Format: **[城市名] + [行业通用搜索词]**

- Use the word ordinary customers would type, NOT industry jargon
- "修车" not "汽车维修服务"
- "吃饭" not "餐饮业态"
- "培训班" not "教育培训机构"
- Keep it to 2-5 characters after the city name for punchy delivery

## Search Subject Rules

Choose the right word for who is searching:

| Industry | Who Searches | Use |
|----------|-------------|-----|
| Retail/Food/Auto | 顾客 | 顾客一搜 |
| Education | 家长 | 家长一搜 |
| Healthcare/Wellness | 客人 | 客人一搜 |
| B2B/Wholesale | 客户 | 客户一搜 |
| Generic/All industries | 顾客 | 顾客一搜 |
