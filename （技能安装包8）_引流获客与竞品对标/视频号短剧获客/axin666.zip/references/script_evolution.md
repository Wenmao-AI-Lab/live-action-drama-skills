# Script Evolution History

This document tracks how the "群口宣讲" video script format evolved through multiple versions, capturing key decisions and the reasoning behind each change.

## Origin: 新村联·武汉江汉路 (Reference Video)

**Source**: A viral marketing video by "新村联" (a kitchen/bathroom renovation company)
**Location**: 武汉江汉路步行街
**Format**: 20+ people in purple T-shirts, team formation, lead speaker announces to camera
**Core Copy**:
> 今天我们在武汉的江汉路——
> 郑重宣布——
> 小红心的叔叔阿姨——
> 找我们做厨卫翻新的——
> 只要9,000元——

**Why it worked**:
1. Team collective action — 20+ people moving in unison creates spectacle, triggers围观 + filming
2. Ritual language — "郑重宣布" + "今天在…" turns an ad into a press conference
3. "小红心的" — engagement暗号, targets users who already interacted
4. Extreme price — 9,000 for kitchen/bath renovation (market: 10K-30K)
5. Landmark scene — famous步行街 adds geographic trust + traffic

---

## V1: 豆包GEO获客199元 (First Adaptation)

**Product**: 豆包排名 (Douyin/Bao search ranking) at 199 yuan
**Changes from original**:
- Price: 9,000元 → 199
- Service: 厨卫翻新 → 豆包排名
- Added effect statement: "顾客一搜行业，第一个就是你" (original lacked this)
- Target: 叔叔阿姨 → 行业老板 (餐饮/建材/汽修 etc.)
- Engagement hook: "小红心的" → "点了小红心的" (more explicit)

**Key insight**: The original video didn't explain what the service DOES. Adding "顾客一搜就看到你" makes the abstract "GEO排名" instantly understandable.

---

## V2: 5 Cities, Industry-Specific (5条)

**Cities**: 佛山/长沙/郑州/成都/义乌
**Each city had a different industry**: 家具/餐饮/汽修/建材/批发
**T-shirts**: Each city a different color
**Target audience**: Industry-specific (餐饮老板/建材老板 etc.)

**Issue**: Too fragmented — one video only hits one industry. Batch production requires 5 different T-shirt colors.

---

## V3: 10 Cities → 15 Cities, Mixed Mode

**Added 5 more cities**: 武汉/西安/昆明/南昌/南宁
**Then added 5 tier-1 cities**: 北京/上海/广州/深圳/杭州
**Target audience split**:
- Tier-2 cities: industry-specific (餐饮老板/建材老板 etc.)
- Tier-1 cities: unified "实体老板"

**Issue**: Inconsistent — why are tier-1 cities different from tier-2? Adds complexity without benefit.

---

## V4: Full Unification (Current Version)

**Two key changes**:
1. **All 15 cities unified to "本地的实体老板"** — no more industry differentiation
2. **All team members wear white T-shirts** — no more per-city colors

**Reasoning**:
- "本地的实体老板" covers ALL physical business types — one video hits every industry
- "本地" creates geographic belonging; "实体老板" is broad enough for shops/factories/wholesale
- White T-shirts: batch production needs only 1 type, works against any background, stronger team visual
- The only variable per video is the city name — copy-paste efficiency

---

## V5: Product Pivot to "免费教AI做剧情获客"

**Product change**: 豆包排名199 → 免费教AI做剧情获客
**Only 3 segments changed** (40% of script):

| Segment | V1-V4 | V5 |
|---------|-------|-----|
| 业务亮相 | 找我们做豆包排名 | 免费教你用AI做剧情获客 |
| 效果说明 | 顾客一搜行业就看到你 | 不需要用手机拍，不需要出镜，每天用AI做几十条视频 |
| 价格落地 | 只要199 | 不要钱 |

**Three "不" design**:
- 不需要用手机拍 — kills "我不会拍"
- 不需要出镜 — kills "我不想露脸"
- 每天用AI做几十条 — kills "我没时间"

**17-21s shot change**: Instead of showing a phone with search results, lead speaker spreads hands ("nothing to do") while team does "scrolling phone" gesture — no filming equipment visible, only "do nothing" and "watch results".

---

## Product Adaptation Framework

When the product changes, only modify these 3 segments:

| Segment | Slot | Rule |
|---------|------|------|
| 业务亮相 | What you sell | One short phrase, no jargon |
| 效果说明 | What customer gets | One sentence, plain language, outcome-focused |
| 价格落地 | How much | End on the strongest hook — "免费" beats any number |

Everything else (地点/仪式/目标人群) stays identical regardless of product.

### Product History

| Version | Product | Price | Effect Statement |
|---------|---------|-------|-----------------|
| V1-V3 | 豆包排名 | 199元 | 顾客一搜行业就看到你 |
| V4 | 豆包排名 | 199元 | 顾客一搜行业就看到你 |
| V5 | 免费教AI做剧情获客 | 不要钱 | 不需要用手机拍，不需要出镜，每天用AI做几十条视频 |
| Future | [User-defined] | [User-defined] | [One sentence, plain language] |
