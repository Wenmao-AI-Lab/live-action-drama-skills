#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""traffic_report.py —— 引流看板 + 执行清单生成器。

阿拉丁·AI短剧引流工坊（aladin-drama-traffic）第 3 脚本。
输入：hooks.json + _traffic_plan.json
输出：traffic_board.html（自包含看板，内联 CSS/JS）+ traffic_notes.md（执行清单）
零依赖：仅 Python 标准库。
"""
import argparse
import html
import json
import os
from datetime import datetime, timezone


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def esc(s):
    return html.escape(str(s), quote=True)


def hook_cards(hooks):
    cards = []
    for h in hooks.get("hook_copy", []):
        cards.append(f"""
        <div class="card">
          <div class="plat">{esc(h.get('platform',''))}</div>
          <div class="tone">{esc(h.get('tone',''))}</div>
          <div class="row"><span class="k">前3秒</span><span class="v">{esc(h.get('hook_3s',''))}</span></div>
          <div class="row"><span class="k">置顶</span><span class="v">{esc(h.get('pinned_comment',''))}</span></div>
          <div class="row"><span class="k">关注</span><span class="v">{esc(h.get('follow_cta',''))}</span></div>
          <div class="row"><span class="k">提问</span><span class="v">{esc(h.get('debate_question',''))}</span></div>
        </div>""")
    return "\n".join(cards)


def matrix_block(hooks):
    m = hooks.get("distribution_matrix", {})
    rows = []
    mp = m.get("main_publish", {})
    if mp:
        rows.append(f"<tr class='main'><td>主平台</td><td>{esc(mp.get('platform',''))}</td><td>{esc(mp.get('format',''))}</td><td>{esc(mp.get('caption',''))}</td></tr>")
    for s in m.get("slices", []):
        rows.append(f"<tr><td>切片</td><td>{esc(s.get('platform',''))}</td><td>{esc(s.get('adapt_strategy',''))}</td><td>{esc(s.get('title_twist',''))} / {esc(s.get('duration_hint',''))}</td></tr>")
    return "\n".join(rows)


def tier_block(plan):
    rows = []
    for t in plan.get("advice", {}).get("budget_tiers", []):
        rows.append(f"<tr><td>{esc(t.get('tier',''))}</td><td>{esc(t.get('budget',''))}</td><td>{esc(t.get('goal',''))}</td><td>{esc(t.get('targeting',''))}</td><td>{esc(t.get('action',''))}</td></tr>")
    return "\n".join(rows)


def feedback_block(plan):
    fb = plan.get("feedback", {})
    return f"""
      <div class="fb">
        <div class="fb-row"><b>加题材：</b>{esc('、'.join(fb.get('add_genres',[])))}</div>
        <div class="fb-row"><b>砍题材：</b>{esc('、'.join(fb.get('cut_genres',[])))}</div>
        <div class="fb-row"><b>追热点：</b>{esc('、'.join(fb.get('chase_hotspots',[])))}</div>
        <div class="fb-row"><b>钩子迭代：</b>{esc(fb.get('hook_iteration',''))}</div>
        <div class="fb-brief"><b>next_brief（回灌 topic 工坊）：</b><br>{esc(fb.get('next_brief',''))}</div>
      </div>"""


def build_html(hooks, plan, pb_section=""):
    drama = hooks.get("drama", {})
    sop = plan.get("comment_sop", {})
    sop_items = "".join(f"<li><b>{esc(k)}：</b>{esc(v)}</li>" for k, v in sop.items())
    kol = plan.get("kol_advice", {})
    kol_items = "".join(f"<li><b>{esc(k)}：</b>{esc(v)}</li>" for k, v in kol.items())
    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>阿拉丁·AI短剧引流看板 · {esc(drama.get('title',''))}</title>
<style>
*{{box-sizing:border-box}} body{{font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;margin:0;background:#0f1220;color:#e8ecf5}}
header{{padding:18px 22px;background:linear-gradient(90deg,#ff5a5f,#ff9a3c);color:#fff}}
header h1{{margin:0;font-size:20px}} header .sub{{opacity:.9;font-size:13px;margin-top:4px}}
.wrap{{padding:18px 22px;max-width:1100px;margin:0 auto}}
section{{margin:18px 0}} h2{{font-size:16px;border-left:4px solid #ff9a3c;padding-left:10px;margin:0 0 10px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px}}
.card{{background:#1a1f33;border:1px solid #2a3150;border-radius:10px;padding:12px}}
.plat{{font-weight:700;color:#ff9a3c}} .tone{{font-size:12px;color:#9aa3c0;margin:2px 0 8px}}
.row{{display:flex;gap:8px;font-size:13px;margin:5px 0}} .k{{flex:0 0 44px;color:#7f8bb0}} .v{{flex:1}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th,td{{border:1px solid #2a3150;padding:7px 9px;text-align:left}}
th{{background:#1a1f33;color:#ff9a3c}} tr.main{{background:#241a12}}
ul{{font-size:13px;line-height:1.7}}
.fb{{background:#141a2e;border:1px solid #2a3150;border-radius:10px;padding:12px;font-size:13px}}
.fb-row{{margin:4px 0}} .fb-brief{{margin-top:8px;padding-top:8px;border-top:1px dashed #2a3150;color:#ffd9a0}}
footer{{text-align:center;color:#5a6488;font-size:12px;padding:16px}}
</style></head>
<body>
<header><h1>阿拉丁·AI短剧引流看板｜{esc(drama.get('title','未命名'))}</h1>
<div class="sub">第 {esc(drama.get('episode',1))} 集 · {esc(drama.get('genre',''))} · 钩子DNA：{esc(drama.get('hook_dna',''))} · 生成于 {esc(plan.get('generated_at',''))}</div></header>
<div class="wrap">
<section><h2>① 各平台钩子卡</h2><div class="grid">{hook_cards(hooks)}</div></section>
<section><h2>② 跨平台分发矩阵</h2><table><tr><th>类型</th><th>平台</th><th>策略</th><th>说明</th></tr>{matrix_block(hooks)}</table></section>
<section><h2>③ 轻量投放梯度（不调API）</h2><table><tr><th>梯度</th><th>预算</th><th>目标</th><th>人群定向</th><th>动作</th></tr>{tier_block(plan)}</table>
<div class="fb" style="margin-top:8px"><b>人群提示：</b>{esc(plan.get('advice',{}).get('audience_hint',''))}<br><b>出价提示：</b>{esc(plan.get('advice',{}).get('bid_hint',''))}</div></section>
<section><h2>④ 评论区运营 SOP</h2><ul>{sop_items}</ul></section>
<section><h2>⑤ KOL / 合拍建议</h2><ul>{kol_items}</ul></section>
<section><h2>⑥ 数据反哺选题（feedback → topic 闭环）</h2>{feedback_block(plan)}</section>
{pb_section}
</div>
<footer>aladin-drama-traffic · 纯本地零依赖 · 引流收口环</footer>
</body></html>"""


def build_notes(hooks, plan, pb_section=""):
    drama = hooks.get("drama", {})
    lines = []
    lines.append(f"# 引流执行清单 · 《{drama.get('title','未命名')}》第{drama.get('episode',1)}集\n")
    lines.append(f"> 生成于 {plan.get('generated_at','')} ｜ aladin-drama-traffic\n")
    lines.append("\n## 1. 各平台发布动作")
    for h in hooks.get("hook_copy", []):
        lines.append(f"\n### {h.get('platform','')}")
        lines.append(f"- [ ] 前3秒钩子：{h.get('hook_3s','')}")
        lines.append(f"- [ ] 置顶评论：{h.get('pinned_comment','')}")
        lines.append(f"- [ ] 关注引导：{h.get('follow_cta','')}")
        lines.append(f"- [ ] 互动提问：{h.get('debate_question','')}")
    m = hooks.get("distribution_matrix", {})
    lines.append("\n## 2. 跨平台分发矩阵")
    lines.append(f"- [ ] 主平台精发：{m.get('main_publish',{}).get('platform','')}（{m.get('main_publish',{}).get('caption','')}）")
    for s in m.get("slices", []):
        lines.append(f"- [ ] {s.get('platform','')}切片：{s.get('adapt_strategy','')}｜{s.get('duration_hint','')}")
    lines.append("\n## 3. 投放节奏（不调API，按梯度手动下单）")
    for t in plan.get("advice", {}).get("budget_tiers", []):
        lines.append(f"- [ ] {t.get('tier','')}（{t.get('budget','')}）：{t.get('goal','')} → {t.get('action','')}")
    lines.append(f"- [ ] 人群定向：{plan.get('advice',{}).get('audience_hint','')}")
    lines.append("\n## 4. 评论区运营 SOP")
    for k, v in plan.get("comment_sop", {}).items():
        lines.append(f"- [ ] {k}：{v}")
    lines.append("\n## 5. KOL / 合拍")
    for k, v in plan.get("kol_advice", {}).items():
        lines.append(f"- [ ] {k}：{v}")
    fb = plan.get("feedback", {})
    lines.append("\n## 6. 数据反哺（回灌 topic 工坊）")
    lines.append(f"- [ ] 加题材：{'、'.join(fb.get('add_genres',[]))}")
    lines.append(f"- [ ] 砍题材：{'、'.join(fb.get('cut_genres',[]))}")
    lines.append(f"- [ ] 追热点：{'、'.join(fb.get('chase_hotspots',[]))}")
    lines.append(f"- [ ] 钩子迭代：{fb.get('hook_iteration','')}")
    lines.append(f"\n**next_brief（直接喂 aladin-drama-topic 的 --brief）：**\n{fb.get('next_brief','')}\n")
    if pb_section:
        lines.append(pb_section)
    return "\n".join(lines)


def load_playbook(path):
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def playbook_section(pb):
    if not pb or pb.get("global", {}).get("n", 0) == 0:
        return "", ""
    tips = []
    for group, label, srcfield in [
        ("by_platform", "主投平台", "platform"), ("by_hook_dna", "钩子DNA", "hook_dna"),
        ("by_ad_tier", "投放梯度", "ad_tier"), ("by_comment_tactic", "评论区打法", "comment_tactic"),
        ("by_slice_strategy", "分发策略", "slice_strategy")]:
        items = sorted(pb.get(group, {}).items(), key=lambda kv: kv[1].get("weight", 1.0), reverse=True)
        if items:
            tips.append(f"<li><b>{label}：</b>优先复用「{esc(items[0][0])}」(验证权重 {items[0][1].get('weight',1.0)})</li>")
    html_block = f"""
    <section><h2>⑦ 基于你历史验证的引流建议</h2><ul>{''.join(tips)}</ul>
    <div class="fb" style="margin-top:8px">样本数 n={pb['global']['n']} ｜ 越用验证库越准，本块随你的真实数据自动更新。</div></section>"""
    md_block = "\n## 7. 基于你历史验证的引流建议（验证库反哺）\n" + "\n".join(
        "- " + t.split("</b>")[0].replace("<li><b>", "") + "：" + t.split("</b>")[1].split("</li>")[0]
        for t in tips) + f"\n\n> 样本数 n={pb['global']['n']}，越用验证库越准。\n"
    return html_block, md_block


def main():
    ap = argparse.ArgumentParser(description="生成引流看板与执行清单")
    ap.add_argument("--hooks", required=True, help="hooks.json 路径")
    ap.add_argument("--plan", required=True, help="_traffic_plan.json 路径")
    ap.add_argument("--out", required=True, help="产物输出目录")
    ap.add_argument("--playbook", default=None, help="可选：traffic_playbook.json 验证库，在看板附历史验证建议")
    args = ap.parse_args()

    hooks = load_json(args.hooks)
    plan = load_json(args.plan)
    pb = load_playbook(args.playbook)
    pb_html, pb_md = playbook_section(pb)
    os.makedirs(args.out, exist_ok=True)

    html_path = os.path.join(args.out, "traffic_board.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(build_html(hooks, plan, pb_html))
    md_path = os.path.join(args.out, "traffic_notes.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(build_notes(hooks, plan, pb_md))
    print(f"[traffic_report] 已生成 {html_path}")
    print(f"[traffic_report] 已生成 {md_path}")


if __name__ == "__main__":
    main()
