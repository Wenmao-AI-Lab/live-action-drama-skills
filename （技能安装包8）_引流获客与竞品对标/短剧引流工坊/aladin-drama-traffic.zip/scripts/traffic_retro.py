#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""traffic_retro.py —— 阿拉丁·AI短剧引流工坊 复盘反哺闭环。

add / summary / benchmark / seed 四子命令。
把每次引流部署的「策略特征 + 真实表现」沉淀为 traffic_playbook.json 验证库，
让下次引流越做越准（与 aladin 家族 topic/roi/bgm/shoot/script/clip 共用验证库反哺范式）。
零依赖：仅 Python 标准库。纯本地、不联网、数据不出本机。
"""
import argparse
import json
import os
from datetime import datetime, timezone

PLAYBOOK = "traffic_playbook.json"

GROUP_FIELDS = {
    "by_hook_dna": "hook_dna",
    "by_slice_strategy": "slice_strategy",
    "by_ad_tier": "ad_tier",
    "by_comment_tactic": "comment_tactic",
    "by_platform": "platform",
}


def load_playbook(path):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "version": "1.0",
        "global": {"n": 0, "sum_follow_rate": 0.0, "sum_completion": 0.0,
                   "sum_interaction": 0.0, "perform_sum": 0.0},
        "by_hook_dna": {}, "by_slice_strategy": {}, "by_ad_tier": {},
        "by_comment_tactic": {}, "by_platform": {}, "records": [],
    }


def perf_score(rec):
    """引流表现分：涨粉率为主信号，互动率为辅（均归一化到 0~1 量级）。"""
    fr = rec.get("follow_rate") or 0.0
    ir = rec.get("interaction_rate") or 0.0
    return fr * 1.0 + ir * 0.5


def _recompute_weights(pb):
    g = pb["global"]
    base = (g["perform_sum"] / g["n"]) if g["n"] else 0.0
    if base <= 0:
        return
    for group in GROUP_FIELDS:
        for key, b in pb.get(group, {}).items():
            local = (b["perform_sum"] / b["n"]) if b["n"] else 0.0
            w = local / base if base else 1.0
            b["weight"] = round(max(0.7, min(1.6, w)), 3)  # clamp 0.7~1.6
            b["avg_follow_rate"] = round(b["sum_follow_rate"] / b["n"], 5) if b["n"] else 0.0
            b["avg_completion"] = round(b["sum_completion"] / b["n"], 5) if b["n"] else 0.0
            b["avg_interaction"] = round(b["sum_interaction"] / b["n"], 5) if b["n"] else 0.0


def add_record(pb_path, rec):
    pb = load_playbook(pb_path)
    fr = rec.get("follow_rate")
    if fr is None and rec.get("views"):
        fr = (rec.get("follows") or 0) / rec["views"]
    fr = fr or 0.0
    cr = rec.get("completion_rate")
    ir = rec.get("interaction_rate") or 0.0
    score = perf_score(rec)

    g = pb["global"]
    g["n"] += 1
    g["sum_follow_rate"] += fr
    g["sum_completion"] += (cr or 0.0)
    g["sum_interaction"] += ir
    g["perform_sum"] += score

    for group, field in GROUP_FIELDS.items():
        key = rec.get(field)
        if not key:
            continue
        b = pb.setdefault(group, {}).setdefault(key, {
            "n": 0, "sum_follow_rate": 0.0, "sum_completion": 0.0,
            "sum_interaction": 0.0, "perform_sum": 0.0})
        b["n"] += 1
        b["sum_follow_rate"] += fr
        b["sum_completion"] += (cr or 0.0)
        b["sum_interaction"] += ir
        b["perform_sum"] += score

    rec_out = dict(rec)
    rec_out["added_at"] = datetime.now(timezone.utc).isoformat()
    pb["records"].append(rec_out)
    _recompute_weights(pb)

    with open(pb_path, "w", encoding="utf-8") as f:
        json.dump(pb, f, ensure_ascii=False, indent=2)
    return pb


def best_of(pb, group, metric="weight", top=3):
    items = []
    for key, b in pb.get(group, {}).items():
        items.append((key, b.get(metric, 0.0), b.get("n", 0)))
    items.sort(key=lambda x: x[1], reverse=True)
    return items[:top]


def cmd_add(args):
    pb_path = os.path.join(args.out, PLAYBOOK)
    rec = json.load(open(args.record, "r", encoding="utf-8"))
    pb = add_record(pb_path, rec)
    print(f"[traffic_retro] 已沉淀 1 条引流记录 → {pb_path}")
    fr_show = rec.get("follow_rate")
    if fr_show is None and rec.get("views"):
        fr_show = (rec.get("follows") or 0) / rec["views"]
    print(f"[traffic_retro] 验证库样本数 n={pb['global']['n']} | 本次 follow_rate={fr_show} interaction_rate={rec.get('interaction_rate')}")


def cmd_summary(args):
    pb_path = os.path.join(args.out, PLAYBOOK)
    pb = load_playbook(pb_path)
    if pb["global"]["n"] == 0:
        print("[traffic_retro] 验证库为空，先用 add 或 seed 沉淀数据。")
        return
    g = pb["global"]
    print(f"[traffic_retro] 验证库样本 n={g['n']} | 平均涨粉率={g['sum_follow_rate']/g['n']:.4%} "
          f"平均完播={g['sum_completion']/g['n']:.2%} 平均互动率={g['sum_interaction']/g['n']:.4%}")
    for group, label in [
        ("by_hook_dna", "钩子DNA"), ("by_slice_strategy", "分发策略"),
        ("by_ad_tier", "投放梯度"), ("by_comment_tactic", "评论区打法"), ("by_platform", "平台")]:
        rows = best_of(pb, group, "weight", args.top)
        print(f"\n▶ 最值得复用的{label}（按表现权重）：")
        for key, w, n in rows:
            print(f"   - {key}  w={w} (样本{n})")


def cmd_benchmark(args):
    """对一份引流方案给出基于历史验证的跑量预测分与建议。"""
    pb_path = os.path.join(args.out, PLAYBOOK)
    pb = load_playbook(pb_path)
    plan = json.load(open(args.plan, "r", encoding="utf-8"))
    if pb["global"]["n"] == 0:
        print("[traffic_retro] 验证库为空，无法对标；建议先 seed/add 沉淀。")
        return
    weights = []
    hints = []
    for group, field in GROUP_FIELDS.items():
        key = plan.get(field)
        if key and key in pb.get(group, {}):
            w = pb[group][key].get("weight", 1.0)
            weights.append(w)
            hints.append(f"{field}={key}(w={w})")
    base = 1.0
    pred = (sum(weights) / len(weights)) if weights else base
    pred = round(max(0.7, min(1.6, pred)), 3)
    print(f"[traffic_retro] 方案特征命中历史验证：{', '.join(hints) if hints else '无命中'}")
    # 推荐最优组合
    rec_top = {f: best_of(pb, grp, "weight", 1)[0][0] for f, grp in
               [("hook_dna", "by_hook_dna"), ("slice_strategy", "by_slice_strategy"),
                ("ad_tier", "by_ad_tier"), ("comment_tactic", "by_comment_tactic"),
                ("platform", "by_platform")] if best_of(pb, grp, "weight", 1)}
    print(f"[traffic_retro] 预测跑量分={pred}（1.0 为历史均值，越高越值得优先投）")
    print(f"[traffic_retro] 基于你历史验证推荐组合：{rec_top}")


def cmd_seed(args):
    """写入 4 条示例引流记录，上手即见效果。"""
    pb_path = os.path.join(args.out, PLAYBOOK)
    seeds = [
        {"title": "《逆袭归来》第3集", "platform": "抖音", "hook_dna": "隐忍反击",
         "slice_strategy": "切片改编", "ad_tier": "试投", "comment_tactic": "神评预埋",
         "views": 1200000, "follows": 42000, "completion_rate": 0.34, "interaction_rate": 0.07},
        {"title": "《重生之我在80年代》第5集", "platform": "快手", "hook_dna": "重生逆袭",
         "slice_strategy": "主平台精发", "ad_tier": "放量", "comment_tactic": "高赞回复",
         "views": 900000, "follows": 27000, "completion_rate": 0.31, "interaction_rate": 0.05},
        {"title": "《她的小心思》第2集", "platform": "小红书", "hook_dna": "情感共鸣",
         "slice_strategy": "切片改编", "ad_tier": "试投", "comment_tactic": "置顶引导",
         "views": 600000, "follows": 30000, "completion_rate": 0.29, "interaction_rate": 0.09},
        {"title": "《代码江湖》第1集", "platform": "B站", "hook_dna": "玩梗反转",
         "slice_strategy": "同平台二传补量", "ad_tier": "爆发", "comment_tactic": "神评预埋",
         "views": 800000, "follows": 24000, "completion_rate": 0.27, "interaction_rate": 0.06},
    ]
    for s in seeds:
        add_record(pb_path, s)
    pb = load_playbook(pb_path)
    print(f"[traffic_retro] 已 seed {len(seeds)} 条示例 → {pb_path}（n={pb['global']['n']}）")


def main():
    ap = argparse.ArgumentParser(description="阿拉丁·AI短剧引流工坊 复盘反哺闭环")
    sub = ap.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("add", help="沉淀一条引流部署记录")
    pa.add_argument("--record", required=True, help="引流记录 JSON 路径")
    pa.add_argument("--out", default=".", help="验证库输出目录（默认当前目录）")
    pa.set_defaults(func=cmd_add)

    ps = sub.add_parser("summary", help="汇总最值得复用的引流策略")
    ps.add_argument("--out", default=".", help="验证库目录")
    ps.add_argument("--top", type=int, default=3, help="每组展示前 N")
    ps.set_defaults(func=cmd_summary)

    pb = sub.add_parser("benchmark", help="对方案做历史验证对标")
    pb.add_argument("--plan", required=True, help="引流方案 JSON（含 hook_dna/slice_strategy/ad_tier/comment_tactic/platform）")
    pb.add_argument("--out", default=".", help="验证库目录")
    pb.set_defaults(func=cmd_benchmark)

    pd = sub.add_parser("seed", help="写入示例验证库")
    pd.add_argument("--out", default=".", help="验证库输出目录")
    pd.set_defaults(func=cmd_seed)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
