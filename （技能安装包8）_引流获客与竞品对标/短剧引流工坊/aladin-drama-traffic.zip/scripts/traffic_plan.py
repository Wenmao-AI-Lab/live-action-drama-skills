#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""traffic_plan.py —— 引流方案 + 数据反哺选题生成器。

阿拉丁·AI短剧引流工坊（aladin-drama-traffic）第 2 脚本。
输入：publish 工坊 _publish_plan.json + 可选真实数据 --metrics
输出：_traffic_plan.json（投放建议 + 评论区 SOP + KOL 建议 + feedback 闭环字段）
零依赖：仅 Python 标准库。投放建议不连任何广告 API。
"""
import argparse
import json
import os
from datetime import datetime, timezone


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def safe_get(d, *keys, default=None):
    cur = d
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return default
    return cur


def build_advice(platforms, ctx):
    """轻量投放建议：预算梯度 + 人群定向提示（不调 API）。"""
    main = platforms[0] if platforms else "抖音"
    tiers = [
        {"tier": "试投", "budget": "300-800 元/轮", "goal": "小样本测钩子与人群",
         "targeting": "宽定向+相似达人人群包，看完播与涨粉率", "action": "跑 3 天，留 CTR>5% 素材"},
        {"tier": "放量", "budget": "2000-5000 元/轮", "goal": "放大已验证素材",
         "targeting": "收紧到'完播高+互动高'人群，叠加兴趣标签", "action": "集中预算给 top2 切片"},
        {"tier": "爆发", "budget": "1万+ 元/轮", "goal": "冲量+冲榜",
         "targeting": "核心人群扩量+lookalike 扩包", "action": "配合更新节奏日预算阶梯上调"},
    ]
    return {
        "note": "以下为本地梯度方案，仅供决策参考，不连接任何广告/投放平台接口。",
        "main_platform": main,
        "budget_tiers": tiers,
        "audience_hint": (
            f"基础定向：{ctx['genre']}兴趣人群 + 18-40 岁 + 同题材追剧人群包；"
            f"《{ctx['title']}》人设={ctx['persona']}，可叠加'逆袭/情感/爽剧'标签。"
        ),
        "bid_hint": "优先 oCPM 按涨粉/互动优化；试投期控成本，放量期提预算降时长。",
    }


def build_comment_sop():
    return {
        "golden_1h": "发布后 1 小时内本人/矩阵号抢评前 3 条神评，置顶引导看完",
        "pinned_rule": "每条视频置顶 1 条'后续在专辑/关注看全集'话术",
        "god_comment": "预埋 2-3 条争议性但合规提问，引用户站队（不引战）",
        "follow_rhythm": "高赞评论逐一回复'关注不迷路'，把互动流量转关注",
        "crisis": "遇负面先共情再引导，不删评不硬怼，必要时私信承接",
    }


def build_kol_advice(platforms, ctx):
    return {
        "filter": "筛选维度：题材匹配度>粉丝重合度>近期完播率>评论区活跃度",
        "tier": "腰尾部(1-50w)性价比最高，适合合拍/口播植入；头部做爆发期背书",
        "collab_template": (
            f"合作话术：'我是《{ctx['title']}》主创，想请你用你的视角二创第"
            f"{ctx['episode']}集的{ctx['hook_dna']}名场面，挂主页引流互导粉。'"
        ),
        "duet_hint": "开放二创素材包（去水印高潮切片+人物卡），降低合拍门槛",
    }


def build_feedback(plan, metrics, ctx):
    """数据反哺选题：基于 metrics 或选题基因，产出可回灌 topic 工坊的 feedback。"""
    genes = safe_get(plan, "topic_genes", default={}) or {}
    base_genres = genes.get("genres", [ctx["genre"]])
    hotspots = genes.get("hotspots", [])

    add_genres, cut_genres, chase, hook_iter = [], [], [], ""

    if metrics:
        views = metrics.get("views", 0) or 0
        follows = metrics.get("follows", 0) or 0
        cr = metrics.get("completion_rate", None)
        per = metrics.get("per_platform", {}) or {}
        top_hook = metrics.get("top_hook", "")
        weak_ep = metrics.get("weak_episode", None)

        follow_rate = (follows / views) if views else 0
        if follow_rate >= 0.02:
            add_genres = list(base_genres) + ["高黏性续作"]
            cut_genres = []
        else:
            add_genres = list(base_genres)
            cut_genres = ["低完播支线"]

        if cr is not None and cr < 0.3:
            hook_iter = f"完播率仅 {cr:.0%}，前3秒钩子偏弱，下期强化'{ctx['hook_dna']}'式强冲突开场"
        else:
            hook_iter = f"完播率 { (cr or 0):.0%}，钩子合格，下期复用'{ctx['hook_dna']}'DNA 并加新变量"

        # 平台表现差则砍该平台投入，表现好则追
        if per:
            best = max(per.items(), key=lambda kv: kv[1].get("follows", 0))
            chase = [f"主投 {best[0]}（涨粉最优），复制其钩子范式"]
        if weak_ep is not None:
            cut_genres = cut_genres + [f"第{weak_ep}集式铺垫过长，下期压缩"]
        if top_hook:
            add_genres = add_genres + [f"放大'{top_hook}'题材"]
    else:
        # 无真实数据：给基于选题基因的默认反哺策略
        add_genres = list(base_genres) + ["系列化续作"]
        cut_genres = ["未验证新题材（先小样测再上）"]
        chase = ["盯同赛道周榜热点，做 1 条热点借势切片"]
        hook_iter = f"无真实数据，默认复用'{ctx['hook_dna']}'钩子DNA，上线后按 metrics 校准"

    next_brief = (
        f"基于本期反馈：加【{', '.join(add_genres)}】；"
        f"砍【{', '.join(cut_genres)}】；"
        f"追【{', '.join(chase)}】；"
        f"钩子迭代：{hook_iter}"
    )
    return {
        "has_metrics": metrics is not None,
        "add_genres": add_genres,
        "cut_genres": cut_genres,
        "chase_hotspots": chase,
        "hook_iteration": hook_iter,
        "next_brief": next_brief,
        "note": "next_brief 可直接作为 aladin-drama-topic 工坊的 --brief 或趋势输入，闭合创作环。",
    }


def recommend_from_playbook(pb):
    """基于历史验证库，给出最值得优先用的投放梯度 / 评论区打法。"""
    rec = {}
    for group, field in [("by_ad_tier", "ad_tier"), ("by_comment_tactic", "comment_tactic"),
                         ("by_hook_dna", "hook_dna"), ("by_slice_strategy", "slice_strategy")]:
        items = sorted(pb.get(group, {}).items(), key=lambda kv: kv[1].get("weight", 1.0), reverse=True)
        if items:
            rec[field] = {"best": items[0][0], "weight": items[0][1].get("weight", 1.0),
                          "avg_follow_rate": items[0][1].get("avg_follow_rate", 0.0)}
    return rec


def main():
    ap = argparse.ArgumentParser(description="生成引流方案与数据反哺选题")
    ap.add_argument("--publish", required=True, help="publish 工坊 _publish_plan.json")
    ap.add_argument("--metrics", default=None, help="可选真实数据 JSON（播放/涨粉/完播）")
    ap.add_argument("--out", required=True, help="产物输出目录")
    ap.add_argument("--playbook", default=None, help="可选：traffic_playbook.json 验证库路径，按历史验证推荐投放/评论策略")
    args = ap.parse_args()

    plan = load_json(args.publish)
    metrics = load_json(args.metrics) if args.metrics else None
    drama = safe_get(plan, "drama", default={}) or {}
    platforms = safe_get(plan, "platforms", default=None) or ["抖音"]

    ctx = {
        "title": drama.get("title", "未命名短剧"),
        "genre": drama.get("genre", "都市情感"),
        "persona": drama.get("persona", "主角"),
        "hook_dna": drama.get("hook_dna", "逆袭反转"),
        "episode": drama.get("episode", 1),
    }

    out = {
        "skill": "aladin-drama-traffic",
        "stage": "plan",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "drama": ctx,
        "platforms": platforms,
        "advice": build_advice(platforms, ctx),
        "comment_sop": build_comment_sop(),
        "kol_advice": build_kol_advice(platforms, ctx),
        "feedback": build_feedback(plan, metrics, ctx),
    }

    if args.playbook and os.path.exists(args.playbook):
        try:
            pb = json.load(open(args.playbook, "r", encoding="utf-8"))
            if pb.get("global", {}).get("n", 0) > 0:
                rec = recommend_from_playbook(pb)
                out["playbook_recommend"] = rec
                out["playbook_boosted"] = True
                tips = []
                if "ad_tier" in rec:
                    tips.append(f"优先用「{rec['ad_tier']['best']}」梯度（验证涨粉率最高）")
                if "comment_tactic" in rec:
                    tips.append(f"评论区主打「{rec['comment_tactic']['best']}」打法（互动最高）")
                out["playbook_note"] = "；".join(tips)
                print(f"[traffic_plan] 验证库反哺已启用：{out['playbook_note']}")
        except Exception as e:
            print(f"[traffic_plan] 验证库读取失败，按默认方案生成：{e}")

    os.makedirs(args.out, exist_ok=True)
    out_path = os.path.join(args.out, "_traffic_plan.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"[traffic_plan] 已生成 {out_path}")
    print(f"[traffic_plan] 投放梯度={len(out['advice']['budget_tiers'])} 评论区SOP/KOL/feedback 完成")


if __name__ == "__main__":
    main()
