#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""traffic_hook.py —— 钩子文案 + 跨平台分发矩阵生成器。

阿拉丁·AI短剧引流工坊（aladin-drama-traffic）第 1 脚本。
输入：publish 工坊的 _publish_plan.json
输出：hooks.json（每平台钩子四件套 + 跨平台分发矩阵）
零依赖：仅 Python 标准库。
"""
import argparse
import json
import os
from datetime import datetime, timezone

# ---- 平台画像（驱动钩子文案与分发策略，纯本地规则） ----
PLATFORM_PROFILES = {
    "抖音": {
        "tone": "快节奏·强冲突·前3秒砸悬念",
        "hook_style": "反常识/强冲突开场，直接把最炸的瞬间甩脸上",
        "pinned_style": "置顶一句'后续在专辑'，引导看完+关注",
        "follow_style": "用'追更不迷路'强引导关注",
        "debate_style": "抛一个两难选择题，引评论站队",
        "slice_strategy": "主平台精发正片，切片取'最高潮 15 秒'做悬念卡点",
    },
    "快手": {
        "tone": "老铁接地气·真实感·福利感",
        "hook_style": "用'老铁们'开场，像朋友唠嗑抛悬念",
        "pinned_style": "置顶'双击关注不迷路，更新第一时间看'",
        "follow_style": "用'双击+关注'硬引导，社区感强",
        "debate_style": "抛生活化两难，引老铁吐槽站队",
        "slice_strategy": "主平台精发，切片偏'真实感/共情'片段，配方言更香",
    },
    "视频号": {
        "tone": "社交裂变·熟人信任·轻说教",
        "hook_style": "用'你身边是不是也这样'引发代入",
        "pinned_style": "置顶'转发给在乎的人看'，借社交链扩散",
        "follow_style": "用'点个在看+关注，别让好内容沉了'引导",
        "debate_style": "抛家庭/职场共鸣题，引转发讨论",
        "slice_strategy": "主平台精发，切片偏'共鸣/价值'向，利于转发",
    },
    "小红书": {
        "tone": "精致·情绪·氛围感·种草感",
        "hook_style": "用'谁懂啊/破防了'情绪词开场抓女粉",
        "pinned_style": "置顶'收藏这篇，追剧不踩雷'",
        "follow_style": "用'关注我，追剧不迷路'软引导",
        "debate_style": "抛'你会怎么选'情感两难，引姐妹讨论",
        "slice_strategy": "主平台偏'氛围感切片+图文笔记'联动，封面要美",
    },
    "B站": {
        "tone": "玩梗·考据·二创友好·长铺垫",
        "hook_style": "用'本期信息量爆炸'或玩梗开场抓 UP 主受众",
        "pinned_style": "置顶'一键三连，下期更快更肝'",
        "follow_style": "用'关注+一键三连'硬核引导",
        "debate_style": "抛设定/剧情脑洞题，引考据党讨论",
        "slice_strategy": "主平台精发，切片可做'名场面合集'利于二创",
    },
}

DEFAULT_PROFILE = {
    "tone": "强钩子·留人优先",
    "hook_style": "前3秒抛最强悬念",
    "pinned_style": "置顶引导看完+关注",
    "follow_style": "强引导关注",
    "debate_style": "抛两难题引互动",
    "slice_strategy": "主平台精发，切片取高潮段",
}


def load_plan(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def safe_get(plan, *keys, default=None):
    cur = plan
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return default
    return cur


def build_hook_for_platform(platform, ctx):
    """为单平台生成钩子四件套，纯模板拼接，可复算。"""
    prof = PLATFORM_PROFILES.get(platform, DEFAULT_PROFILE)
    title = ctx["title"]
    genre = ctx["genre"]
    persona = ctx["persona"]
    hook_dna = ctx["hook_dna"]
    ep = ctx["episode"]

    hook_3s = (
        f"【{platform}】{prof['hook_style']}。"
        f"《{title}》第{ep}集：{hook_dna}——这一下，{persona}直接破防。"
    )
    pinned = (
        f"【{platform}置顶】{prof['pinned_style']}。"
        f"《{title}》{genre}向，后续高燃名场面都在专辑里，点关注别错过。"
    )
    follow_cta = (
        f"【{platform}关注引导】{prof['follow_style']}。"
        f"追《{title}》不迷路，每天更新不迷路。"
    )
    debate = (
        f"【{platform}互动提问】{prof['debate_style']}。"
        f"如果是你，{persona}这步该硬刚还是忍？评论区站队，我抽 3 条神评下集回应。"
    )
    return {
        "platform": platform,
        "tone": prof["tone"],
        "hook_3s": hook_3s,
        "pinned_comment": pinned,
        "follow_cta": follow_cta,
        "debate_question": debate,
        "compliant_note": "争议性提问仅设两难选择题，不引战、不涉敏感、不人身攻击，合规可控。",
    }


def build_distribution_matrix(platforms, ctx):
    """主平台精发 + 多平台切片改编映射。"""
    if not platforms:
        platforms = ["抖音"]
    main = platforms[0]
    matrix = {
        "main_platform": main,
        "main_publish": {
            "platform": main,
            "format": "正片精发（完整钩子+高潮+悬念结尾）",
            "caption": f"《{ctx['title']}》第{ctx['episode']}集｜{ctx['genre']}｜{ctx['hook_dna']}",
            "note": "主阵地做完整叙事与粉丝沉淀。",
        },
        "slices": [],
    }
    for p in platforms[1:]:
        prof = PLATFORM_PROFILES.get(p, DEFAULT_PROFILE)
        matrix["slices"].append({
            "platform": p,
            "adapt_strategy": prof["slice_strategy"],
            "title_twist": f"《{ctx['title']}》切片｜{prof['tone']}",
            "cover_hint": f"封面突出'{ctx['hook_dna']}'，配{p}风文案",
            "duration_hint": "15-45 秒高潮切片，结尾挂'看全集关注主页'",
        })
    # 主平台自身也补一条切片说明，保证闭环完整
    matrix["slices"].append({
        "platform": main,
        "adapt_strategy": PLATFORM_PROFILES.get(main, DEFAULT_PROFILE)["slice_strategy"],
        "title_twist": f"《{ctx['title']}》名场面｜{PLATFORM_PROFILES.get(main, DEFAULT_PROFILE)['tone']}",
        "cover_hint": f"封面突出'{ctx['hook_dna']}'",
        "duration_hint": "同平台二传可做'高光合集'补量",
    })
    return matrix


def reorder_by_playbook(platforms, pb):
    """按历史验证的涨粉表现权重，把最值得发的平台排到主平台位。"""
    weights = pb.get("by_platform", {})
    if not weights:
        return platforms
    return sorted(platforms, key=lambda p: weights.get(p, {}).get("weight", 1.0), reverse=True)


def main():
    ap = argparse.ArgumentParser(description="生成钩子文案与跨平台分发矩阵")
    ap.add_argument("--publish", required=True, help="publish 工坊 _publish_plan.json 路径")
    ap.add_argument("--out", required=True, help="产物输出目录")
    ap.add_argument("--playbook", default=None, help="可选：traffic_playbook.json 验证库路径，按历史验证重排分发矩阵")
    args = ap.parse_args()

    plan = load_plan(args.publish)
    drama = safe_get(plan, "drama", default={}) or {}
    platforms = safe_get(plan, "platforms", default=None) or safe_get(plan, "drama", "platforms", default=None) or ["抖音"]

    boosted = False
    verified_top_platform = None
    if args.playbook and os.path.exists(args.playbook):
        try:
            pb = json.load(open(args.playbook, "r", encoding="utf-8"))
            reordered = reorder_by_playbook(platforms, pb)
            if reordered != platforms:
                platforms = reordered
                boosted = True
                verified_top_platform = platforms[0]
        except Exception as e:
            print(f"[traffic_hook] 验证库读取失败，按原顺序生成：{e}")

    ctx = {
        "title": drama.get("title", "未命名短剧"),
        "genre": drama.get("genre", "都市情感"),
        "persona": drama.get("persona", "主角"),
        "hook_dna": drama.get("hook_dna", "逆袭反转"),
        "episode": drama.get("episode", 1),
    }

    hooks = [build_hook_for_platform(p, ctx) for p in platforms]
    matrix = build_distribution_matrix(platforms, ctx)

    out = {
        "skill": "aladin-drama-traffic",
        "stage": "hook",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "drama": ctx,
        "platforms": platforms,
        "hook_copy": hooks,
        "distribution_matrix": matrix,
    }
    if boosted:
        out["playbook_boosted"] = True
        out["verified_top_platform"] = verified_top_platform
        out["playbook_note"] = f"已按你历史验证把涨粉最优平台「{verified_top_platform}」排到主平台位，正片精发给它、其余切片改编。"

    os.makedirs(args.out, exist_ok=True)
    out_path = os.path.join(args.out, "hooks.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"[traffic_hook] 已生成 {out_path}")
    print(f"[traffic_hook] 平台数={len(platforms)} 钩子四件套+分发矩阵完成"
          + (f" | 验证库反哺：主平台→{verified_top_platform}" if boosted else ""))


if __name__ == "__main__":
    main()
