# 阿拉丁·AI短剧引流工坊 · 数据反哺选题模型（feedback-loop）

> 配套 `aladin-drama-traffic`。本文件定义"数据 → 决策 → feedback 字段 → 回灌 topic"的闭环模型。本款是 AI 短剧创作环第 8 环（引流收口），`feedback` 字段即下一轮 `aladin-drama-topic` 工坊的输入。

## 一、闭环定位

```
topic → script → gen/subtitle/dub → edit → publish → traffic ──(feedback)──▶ topic
                                        ↑________ 第 8 环：引流收口 ________│
```

- `traffic` 吃 `publish` 的 `_publish_plan.json`。
- `traffic` 出 `_traffic_plan.json`，其 `feedback.next_brief` 回灌 `topic` 的 `--brief` 或趋势输入。
- 形成"选题→…→引流→(反哺)→选题"自驱环。

## 二、metrics 输入 schema（可选，真实数据）

```json
{
  "views": 1200000,
  "follows": 36000,
  "completion_rate": 0.28,
  "per_platform": { "抖音": {"views": 600000, "follows": 22000} },
  "top_hook": "隐忍反击",
  "weak_episode": 3
}
```

| 字段 | 含义 | 驱动决策 |
|------|------|----------|
| views / follows | 播放 / 涨粉 | 算涨粉率 follow_rate |
| completion_rate | 完播率 | <0.3 → 钩子迭代建议 |
| per_platform | 分平台表现 | 取涨粉最优平台 → 追投 |
| top_hook | 最佳钩子题材 | 放大该题材 |
| weak_episode | 低效集 | 砍该集式铺垫 |

## 三、决策规则（纯函数，可复算）

1. **涨粉率 follow_rate = follows / views**
   - ≥ 0.02 → `add_genres` 加"高黏性续作"，`cut_genres` 清空。
   - < 0.02 → `add_genres` 保留基础题材，`cut_genres` 加"低完播支线"。
2. **完播率 completion_rate**
   - 存在且 < 0.3 → `hook_iteration` 建议强化强冲突开场。
   - 否则复用当前 hook_dna 并加新变量。
3. **分平台 per_platform**
   - 取涨粉最高平台 → `chase_hotspots` 加"主投该平台并复制其范式"。
4. **weak_episode**
   - 存在 → `cut_genres` 加"压缩该集式铺垫"。
5. **top_hook**
   - 存在 → `add_genres` 加"放大该题材"。
6. **无 metrics（默认策略）**
   - `add_genres` = 基础题材 + "系列化续作"
   - `cut_genres` = "未验证新题材（先小样测再上）"
   - `chase_hotspots` = "盯同赛道周榜热点做借势切片"
   - `hook_iteration` = "默认复用 hook_dna，上线后按 metrics 校准"

## 四、feedback 字段 schema（输出，topic 工坊可解析）

```json
{
  "has_metrics": true,
  "add_genres": ["都市逆袭", "高黏性续作", "放大'隐忍反击'题材"],
  "cut_genres": ["低完播支线", "压缩第3集式铺垫"],
  "chase_hotspots": ["主投抖音（涨粉最优），复制其钩子范式"],
  "hook_iteration": "完播率仅 28%，前3秒钩子偏弱，下期强化'隐忍反击'式强冲突开场",
  "next_brief": "基于本期反馈：加【…】；砍【…】；追【…】；钩子迭代：…",
  "note": "next_brief 可直接作为 aladin-drama-topic 工坊的 --brief 或趋势输入，闭合创作环。"
}
```

## 五、闭环触发规则

- **触发**：每当 `traffic_plan.py` 产出 `_traffic_plan.json`，即触发回灌。
- **传递**：取 `feedback.next_brief` 整段作为 topic 工坊 `--brief`。
- **不引入陌生字段**：`feedback` 全部字段为 topic 工坊可解析的纯文本/数组，不塞 topic 无法消费的复杂结构（重要约束·与闭环关系）。
- **可复算**：同输入同输出，便于回归审计（重要约束·可复算）。
