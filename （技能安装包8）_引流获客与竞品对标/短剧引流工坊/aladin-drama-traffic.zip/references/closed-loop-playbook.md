# 阿拉丁·AI短剧引流工坊 · 复盘反哺闭环操作手册（closed-loop）

> 配套 `aladin-drama-traffic`。本文件定义"引流策略 → 真实表现 → 复盘沉淀 → 下次越做越准"的验证库闭环，是 AI 短剧创作环第 8 环（引流收口）自带的学习回路，与上游 `feedback → topic` 反哺互补、各管一段。

## 一、为什么需要它

没有复盘反哺时，每发一条短剧都要重新想"钩子怎么写、分发怎么排、投多少"。有了 `traffic_playbook.json` 验证库，本技能会记住**你自己的账号**哪套引流策略真跑量，下次自动加权复用——越用越准，这是"只出一段文案"类工具做不到的。

闭环位置：

```
引流(traffic) → 真实表现(涨粉/完播/互动) → traffic_retro 沉淀 → traffic_playbook.json
   ↑                                                                      │
   └── 下次 hook/plan/report 接 --playbook 自动加权复用 ←──────────────────┘
（与上游 feedback → topic 反哺并行：feedback 管"选题"，playbook 管"引流打法"）
```

## 二、traffic_retro 四子命令

### 1. add —— 沉淀一条引流部署

输入一条 JSON 记录（字段见第四节 schema），写入验证库并即时重算权重：

```bash
"$PY" "$SKILL/scripts/traffic_retro.py" add --record ./build/metrics_record.json --out ./build
```

- `follow_rate` 优先取显式字段；缺失时按 `follows / views` 自动推算，便于直接复用发布后台的原始数据。
- 每条记录按 钩子DNA / 分发策略 / 投放梯度 / 评论区打法 / 平台 五个维度分别入桶累计。

### 2. summary —— 看最值得复用的引流组合

```bash
"$PY" "$SKILL/scripts/traffic_retro.py" summary --out ./build --top 3
```

按表现权重输出每组 Top N：哪类钩子DNA、哪种分发策略、哪个投放梯度、哪种评论区打法、哪个平台最值得复用。

### 3. benchmark —— 对方案做历史验证对标

```bash
"$PY" "$SKILL/scripts/traffic_retro.py" benchmark --plan ./build/_traffic_plan.json --out ./build
```

给出预测跑量分（1.0=历史均值，越高越值得优先投）与基于你验证库的推荐组合。

### 4. seed —— 写入示例验证库

```bash
"$PY" "$SKILL/scripts/traffic_retro.py" seed --out ./build
```

写入 4 条示例部署，上手即见效果（上线后建议用真实数据 `add` 覆盖）。

## 三、与 hook / plan / report 的衔接

| 脚本 | `--playbook` 行为 |
|------|-------------------|
| `traffic_hook.py` | 按历史验证的涨粉权重，把最优平台排到主平台位（正片精发给它、其余切片改编），产物标 `playbook_boosted` |
| `traffic_plan.py` | 按历史验证推荐最优投放梯度 / 评论区打法，附 `playbook_recommend` |
| `traffic_report.py` | 看板/清单追加「基于你历史验证的引流建议」一节，列出优先复用的平台/钩子/梯度/打法 |

## 四、记录 schema（add 输入）

```json
{
  "title": "《逆袭归来》第3集",
  "platform": "抖音",
  "hook_dna": "隐忍反击",
  "slice_strategy": "切片改编",
  "ad_tier": "试投",
  "comment_tactic": "神评预埋",
  "views": 1200000,
  "follows": 42000,
  "completion_rate": 0.34,
  "interaction_rate": 0.07
}
```

| 字段 | 含义 | 落入验证库维度 |
|------|------|----------------|
| platform | 主投平台 | by_platform |
| hook_dna | 钩子 DNA（题材钩子） | by_hook_dna |
| slice_strategy | 分发策略（主平台精发/切片改编/同平台二传补量） | by_slice_strategy |
| ad_tier | 投放梯度（试投/放量/爆发） | by_ad_tier |
| comment_tactic | 评论区打法（神评预埋/置顶引导/高赞回复） | by_comment_tactic |
| views / follows | 播放 / 涨粉 | 算涨粉率 follow_rate（主信号） |
| completion_rate | 完播率 | 辅助信号 |
| interaction_rate | 互动率（点赞+评论/播放） | 辅助信号 |

## 五、权重规则（纯函数，可复算）

- 单条表现分 `score = follow_rate × 1.0 + interaction_rate × 0.5`。
- 全局基准 `base = Σscore / n`；每桶权重 `w = 本桶平均 score / base`，clamp 到 **0.7~1.6**。
- `w > 1` 表示该策略优于你历史平均，下次优先复用；`w < 1` 表示逊于平均，需谨慎。

## 六、与上游 feedback 闭环的边界

- **playbook（本文件）**：管"引流打法"——钩子/分发/投放/评论哪种组合在你的账号跑得动。
- **feedback（feedback-loop.md）**：管"选题"——题材加减/热点追投/钩子迭代，回灌 `aladin-drama-topic`。
- 两者并行不冲突：同一份真实数据既可以 `add` 进 playbook（沉淀引流打法），也可以通过 `traffic_plan.py --metrics` 产出 `feedback`（反哺选题）。

## 七、重要约束

- **纯本地、零依赖、不联网**：验证库 `traffic_playbook.json` 仅落在本机 `--out` 目录，数据不出本机（→ Trust）。
- **可复算**：同输入同输出，便于回归与审计（→ Reliability）。
- **不编造数据**：权重严格基于你 `add` 进来的真实记录；库为空时 `benchmark`/`--playbook` 自动退化为默认策略，不杜撰（→ Trust）。
