# 阿拉丁·AI短剧引流工坊 · 使用样例（usage-examples）

> 配套 `aladin-drama-traffic` 技能。以下 4 个场景均基于 publish 工坊的 `_publish_plan.json`，演示从"发布方案"到"可执行引流包 + 反哺闭环"的完整链路。

## 场景 1：新剧冷启动（无真实数据）

**输入**：`sample_publish.json`（5 平台，无 metrics）

```bash
PY="C:/Users/adam/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SKILL="<本技能目录>"
"$PY" "$SKILL/scripts/traffic_hook.py" --publish "$SKILL/assets/sample_publish.json" --out ./build
"$PY" "$SKILL/scripts/traffic_plan.py" --publish "$SKILL/assets/sample_publish.json" --out ./build
"$PY" "$SKILL/scripts/traffic_report.py" --hooks ./build/hooks.json --plan ./build/_traffic_plan.json --out ./build
```

**产出**：`hooks.json`（每平台钩子四件套 + 分发矩阵）、`_traffic_plan.json`（默认反哺策略）、`traffic_board.html`、`traffic_notes.md`。
**闭环**：把 `_traffic_plan.json` 的 `feedback.next_brief` 作为 `aladin-drama-topic` 的 `--brief`，进入下一轮选题。

## 场景 2：跨平台分发矩阵精修

针对"主平台精发 + 多平台切片改编"，可在 `publish_plan.platforms` 里把表现最好的平台放第一位作为 `main_platform`；脚本自动生成：主平台正片精发、其余平台切片改编（标题/封面/时长差异化）。

**要点**：抖音/快手吃"强冲突"，小红书吃"情绪氛围"，视频号吃"共鸣转发"，B站吃"玩梗二创"——切片策略各不同，见 `playbook.md`。

## 场景 3：带真实数据反哺（精准闭环）

**输入**：额外准备 `metrics.json`

```json
{ "views": 1200000, "follows": 36000, "completion_rate": 0.28,
  "per_platform": { "抖音": {"views": 600000, "follows": 22000}, "快手": {"views": 300000, "follows": 6000} },
  "top_hook": "隐忍反击", "weak_episode": 3 }
```

```bash
"$PY" "$SKILL/scripts/traffic_plan.py" --publish "$SKILL/assets/sample_publish.json" --metrics ./build/metrics.json --out ./build
```

**效果**：完播率 0.28<0.3 → `hook_iteration` 自动建议强化强冲突开场；抖音涨粉最优 → `chase_hotspots` 建议主投抖音并复制其范式；第 3 集铺垫长 → `cut_genres` 加"压缩第3集式铺垫"。反哺比无数据版精准得多。

## 场景 4：批量多剧引流

对 N 部剧的 `_publish_plan.json` 循环调用三脚本即可，单剧失败不影响整批（脚本只读写 `--out` 下各自文件）。建议每剧一个子目录，便于回灌各自 topic 工坊。

## 场景 5：复盘反哺闭环（让引流越做越准）

发布后把每套引流策略的真实跑量沉淀进本地验证库，下次自动加权复用：

```bash
# 1) 准备一条引流部署记录（可直接用发布后台的 views/follows 原始数）
"$PY" "$SKILL/scripts/traffic_retro.py" add --record ./build/metrics_record.json --out ./build
# 2) 看最值得复用的引流组合画像
"$PY" "$SKILL/scripts/traffic_retro.py" summary --out ./build --top 3
# 3) 下次生成时接 --playbook，钩子排序/分发矩阵/投放梯度自动按验证库加权
"$PY" "$SKILL/scripts/traffic_hook.py" --publish "$SKILL/assets/sample_publish.json" --out ./build --playbook ./build/traffic_playbook.json
"$PY" "$SKILL/scripts/traffic_plan.py"  --publish "$SKILL/assets/sample_publish.json" --out ./build --playbook ./build/traffic_playbook.json
```

`metrics_record.json` 至少含 `platform / hook_dna / slice_strategy / ad_tier / comment_tactic / views / follows`；缺 `follow_rate` 时脚本按 `follows/views` 自动推算。`seed` 子命令可先写入 4 条示例上手即见效果。验证库纯本地、不联网、数据不出本机。

## 最佳实践

1. **先 hook 再 plan 再 report**：三脚本串联，顺序不可乱（report 依赖前两者产物）。
2. **真实数据优先**：有 `--metrics` 必带，反哺质量天差地别。
3. **主平台放第一**：`platforms[0]` 即 `distribution_matrix.main_platform`。
4. **feedback 直接回灌**：`next_brief` 是给 topic 工坊的现成输入，勿手改字段名。

## FAQ

**Q：能直接帮我投广告吗？** 不能。脚本只出"预算梯度/人群定向提示"，不连任何广告 API（重要约束）。
**Q：没有真实数据能用吗？** 能，走默认反哺策略（基于选题基因），但建议上线后补 metrics 校准。
**Q：和 omni-engage 什么关系？** 本款引流获客，engage 互动承接，互补不重叠。
**Q：feedback 字段 topic 工坊能直接吃吗？** 能，`next_brief` 是纯文本 brief，topic 工坊按 `--brief` 解析即可。
**Q：复盘验证库（traffic_playbook.json）安全吗？** 安全。它只落在本机 `--out` 目录，纯本地、不联网、数据不出本机；库为空时 `--playbook` 自动退化为默认策略，绝不编造数据。
**Q：--playbook 会影响原有 feedback 反哺吗？** 不会。playbook 管"引流打法"加权，feedback 管"选题"反哺，两者并行各管一段，互不干扰。
