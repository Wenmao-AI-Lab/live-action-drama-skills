---

name: aladin-drama-traffic
slug: "aladin-drama-traffic"
version: 1.0.0
displayName: 阿拉丁·AI短剧引流工坊｜钩子文案·评论区运营·跨平台分发·投放建议·数据反哺选题
summary: 阿拉丁出品的 AI 短剧引流工坊：把发布方案变成"可执行引流包"——平台钩子文案、评论区运营话术、跨平台分发矩阵、轻量投放建议、数据反哺选题，纯本地零依赖。比  飙升的"视频号爆款文案/短视频脚本"(只出一段文案，无分发/无投放/无数据反哺) 多出 全链路引流 + 跨平台矩阵 + 投放建议 + 闭环反哺；比自家 omni-growth(看自己数据复盘) 多出 主动引流动作 + 反哺创作；与 omni-engage(互动运营) 互补(本款引流获客，engage 互动承接)，是"AI 短剧创作闭环"第 8 环(引流收口)。
description: 阿拉丁·AI短剧引流工坊把「发布完就等播放、不会主动引流、不会做分发矩阵、不会反哺选题」升级成一条纯本地零依赖工具链：平台钩子文案(前3秒留人/评论区置顶/引导关注/争议性合规提问)、评论区运营 SOP、跨平台分发矩阵(主平台精发+多平台切片改编)、轻量投放建议(预算梯度/人群定向不调API)、数据反哺选题(feedback 回灌 topic 闭环)。比  飙升的视频号爆款文案(仅出一段文案)多出 全链路引流 + 跨平台矩阵 + 投放建议 + 闭环反哺；比 omni-growth(数据复盘)多出 主动引流动作+反哺创作；与 omni-engage 互补(引流获客 vs 互动承接)，是 AI 短剧创作闭环第 8 环。触发词：AI短剧引流、短剧涨粉、短剧分发、跨平台分发、钩子文案、评论区运营、短视频投放、投放建议、数据反哺选题、引流闭环、traffic growth、short drama traffic、AI drama growth、阿拉丁短剧、aladin drama、SEO 短剧、短剧获客、短剧矩阵。
category: content-creation
platforms:
  - AI助手
  - QClaw
  - ima
company: 阿拉丁
tags:
  - 阿拉丁
  - aladin
  - AI短剧
  - 引流
  - 涨粉
  - 分发
  - 投放
  - 评论区运营
  - traffic
  - growth
  - 数据反哺
  - 钩子文案
  - 跨平台矩阵
  - 短视频投放
  - SEO
  - 短剧获客
  - 内容运营
  - AI短剧闭环
  - short drama
  - content growth
  - drama marketing
  - topic feedback
---




# 阿拉丁·AI短剧引流工坊（aladin-drama-traffic）

> 阿拉丁出品。你用 aladin-drama-topic 出了选题、aladin-drama-script 写了剧本、aladin-drama-gen / subtitle / dub 生成了画面与声音、aladin-drama-edit 剪好了片、aladin-drama-publish 排好了发布——但**发布完就等播放**是绝大多数短剧团队的死穴：不会主动引流、不会做分发矩阵、不会反哺下一期选题。 上的"视频号爆款文案 / 短视频脚本"（系）正在飙升，可它们**只出一段文案**——没有分发、没有投放、没有数据反哺。这个技能把"发布 → 引流 → 反哺"收口成一套**纯本地、零依赖**的工具：你给 publish 工坊的 `_publish_plan.json`（加可选真实数据），它产出钩子文案、评论区 SOP、跨平台矩阵、投放梯度、以及回灌 topic 工坊的 `feedback` 字段，闭合整个 AI 短剧创作环。

## 它解决什么痛点

团队做完片只会"发完等爆"，缺的是**主动引流 + 闭环反哺**：

| 现有飙升/常见技能 | 只做 | 不做 |
|------------------|------|------|
| ·视频号爆款文案（文案类目头部） | 出**一段**爆款文案 | 不分发、不投放、不评论区运营、不数据反哺 |
| ·短视频脚本生成 | 出**单条**脚本 | 无矩阵、无投放梯度、无闭环 |
| omni-growth（自家） | **看自己数据复盘** | 不主动引流、不反哺创作 |
| omni-engage（自家） | **互动运营/承接** | 不负责获客引流与选题反哺 |

**本技能 = AI 短剧引流全链路 + 闭环反哺**，脚本零依赖（仅 Python 标准库）、纯本地、离线可用，且比上述多出 **跨平台分发矩阵 + 轻量投放建议 + 数据反哺选题**；与 omni-engage 互补（本款引流获客，engage 互动承接）。

## 与  现有技能 + 自家 aladin 系列的差异化

| 能力 | 视频号爆款文案/短视频脚本 | omni-growth | **阿拉丁·AI短剧引流工坊(本款)** |
|------|--------------------------|-------------|-------------------------------|
| 平台钩子文案(留人/置顶/关注/提问) | 仅一段文案 | ✗ | ✓ 按平台差异化 |
| 评论区运营 SOP + 话术 | ✗ | 部分复盘 | ✓ 完整 SOP |
| 跨平台分发矩阵 | ✗ | ✗ | ✓ 主平台精发+多平台切片改编 |
| 轻量投放建议(预算/人群,不调API) | ✗ | ✗ | ✓ 梯度方案 |
| KOL/合拍建议 | ✗ | ✗ | ✓ |
| 数据反哺选题(feedback 闭环) | ✗ | 仅复盘 | ✓ 回灌 topic 工坊 |
| 零依赖 / 离线 | 平台相关 | 平台相关 | ✓ 纯标准库 |

## 完整闭环图（AI 短剧创作环，本款是第 8 环·引流收口）

```
   ┌──────────────────────────────────────────────────────────────────┐
   │                       AI 短剧创作闭环（aladin）                      │
   │                                                                    │
   │   ① topic  ──选题/趋势──▶ ② script ──剧本──▶ ③ gen/subtitle/dub    │
   │      ▲                          (画面/字幕/配音)                      │
   │      │                              │                               │
   │      │                              ▼                               │
   │      │                       ④ edit ──成片──▶ ⑤ publish             │
   │      │                          (发布方案)            │              │
   │      │                                               ▼              │
   │      │                        ⑧ traffic ◀── _publish_plan.json ──┘  │
   │      │                         (引流包 + feedback 回灌)              │
   │      └──────────── feedback 字段 = 下一轮 topic 的 --brief/趋势 ─────┘ │
   └──────────────────────────────────────────────────────────────────┘
```

**衔接约定：**
- 输入来自 `aladin-drama-publish` 的 `_publish_plan.json`（含 剧名 / 平台 / 发布参数 / 选题基因）。
- 本款产出 `_traffic_plan.json`，其中 `feedback` 字段（题材加减 / 热点追投 / 钩子迭代）**就是下一轮 `aladin-drama-topic` 工坊的 `--brief` 或趋势输入**，形成闭环。
- 与 `omni-engage` 互补：本款负责"把人引过来"（获客），engage 负责"把人留下来"（互动承接）。

## 何时触发

- "短剧发布后怎么引流 / 怎么涨粉 / 怎么获客"
- "给这份发布方案配钩子文案 / 评论区话术 / 置顶评论"
- "做跨平台分发矩阵 / 多平台切片改编 / 抖音快手视频号小红书怎么发"
- "给短剧出投放建议 / 预算梯度 / 人群定向"
- "这期数据出来了，下期选题怎么调 / 数据反哺选题"
- 用户给出 `aladin-drama-publish` 的 `_publish_plan.json`，想落地成"可执行引流包"
- 用户要闭合 AI 短剧创作环（traffic 工坊收口 + 反哺 topic）

## 何时不触发

- 用户要**写剧本 / 出选题 / 做剪辑 / 配音字幕 / 发布排期**——分别走 aladin-drama-script / topic / edit / dub / publish，本款只做引流与反哺
- 用户要**真正投放广告、调广告平台 API、充值/出价**——本款只给"轻量投放建议"（预算梯度/人群定向提示），不连任何广告 API
- 用户要**互动承接/客服/社群运营**——用 omni-engage，本款只做引流获客
- 用户要**看自己历史数据复盘**（不反哺创作）——用 omni-growth
- 用户要**搜索/安装**别人的技能——用 find skill /  install
- 用户要**审计技能安全**——用 aladin-secure-forge / Skill Auditor

## 能力边界

**能做：**
- 钩子文案：为每平台生成前 3 秒留人话术 / 评论区置顶 / 引导关注话术 / 争议性但合规的互动提问
- 跨平台分发矩阵：主平台精发 + 多平台切片改编映射（标题/封面/时长/钩子差异）
- 评论区运营 SOP：黄金 1 小时 / 置顶话术 / 神评互动 / 引导关注节奏
- 轻量投放建议：预算梯度（试投/放量/爆发）、人群定向提示、出价思路（不连 API）
- KOL/合拍建议：筛选维度 + 合作话术模板
- 数据反哺选题：基于真实 `--metrics` 或选题基因，给出下期题材加减、热点追投、钩子迭代（写进 `feedback`）

**不能做：**
- 不能**真实投放广告 / 调广告平台 API / 充值出价**（只给方案，不连任何付费接口）
- 不能**保证播放/涨粉结果**（引流是概率工程，产出是"可执行包"不是承诺）
- 不能**生成片源/字幕/配音**（那是 gen/subtitle/dub/edit 的事）
- 不能**替代互动承接/社群运营**（那是 omni-engage）
- 不能**编造数据**（`feedback` 严格基于传入的 `--metrics` 或选题基因，无数据时不乱猜）

## 输入输出规范

**输入：**
- `--publish`：必填，`aladin-drama-publish` 的 `_publish_plan.json`（剧名 / 平台 / 发布参数 / 选题基因）
- `--metrics`：可选，真实播放/涨粉/完播数据 JSON（用于反哺；无则基于选题基因给默认建议）
- `--out`：必填，产物输出目录

**输出（位于 `--out`）：**
- `hooks.json`：每平台钩子文案 + 跨平台分发矩阵（traffic_hook.py 产）
- `_traffic_plan.json`：投放建议 + 评论区 SOP + KOL 建议 + `feedback` 闭环字段（traffic_plan.py 产）
- `traffic_board.html`：自包含引流看板（钩子卡 + 矩阵 + 投放梯度 + 反哺建议，内联 CSS/JS）
- `traffic_notes.md`：执行清单（traffic_report.py 产）

## 工作流

### Step 1：生成钩子文案 + 跨平台分发矩阵（traffic_hook.py）

```bash
PY="技能目录/.AI助手/binaries/python/versions/3.13.12/python.exe"
SKILL="<本技能目录>"
"$PY" "$SKILL/scripts/traffic_hook.py" --publish "$SKILL/assets/sample_publish.json" --out ./build
```

产出 `hooks.json`（每平台钩子四件套 + 分发矩阵）。

### Step 2：生成引流方案 + 数据反哺（traffic_plan.py）

```bash
# 无真实数据时
"$PY" "$SKILL/scripts/traffic_plan.py" --publish "$SKILL/assets/sample_publish.json" --out ./build
# 带真实数据时（反馈更精准）
"$PY" "$SKILL/scripts/traffic_plan.py" --publish "$SKILL/assets/sample_publish.json" --metrics ./build/metrics.json --out ./build
```

产出 `_traffic_plan.json`（`feedback` 字段即下一轮 topic 工坊输入）。

### Step 3：生成看板 + 执行清单（traffic_report.py）

```bash
"$PY" "$SKILL/scripts/traffic_report.py" --hooks ./build/hooks.json --plan ./build/_traffic_plan.json --out ./build
```

产出 `traffic_board.html`（自包含看板）+ `traffic_notes.md`（执行清单）。

### Step 4：由 Hy3 完成反哺闭环

读取 `_traffic_plan.json` 的 `feedback` 字段，把它作为下一轮 `aladin-drama-topic` 工坊的 `--brief` 或趋势输入，触发选题迭代，闭合创作环。

## 复用资源

| 文件 | 用途 | 加载时机 |
|------|------|----------|
| `references/usage-examples.md` | 4 个完整场景（新剧冷启/跨平台矩阵/投放放量/数据反哺）+ 最佳实践 + FAQ | 用户要具体样例、或落地参考时加载 |
| `references/playbook.md` | 各平台引流打法（抖音/快手/视频号/小红书/B站 差异表 + 钩子范式 + 评论区 SOP） | 写钩子/做分发矩阵/评论区运营时加载 |
| `references/feedback-loop.md` | 数据反哺选题模型（指标→决策→feedback 字段 schema + 闭环触发规则） | 做 `feedback` 反哺、或用户问"怎么反哺选题"时加载 |

## 重要约束

- **零依赖**：三脚本仅用 Python 标准库（json / argparse / datetime 等），离线可跑，不要求 pip 安装（→ Reliability）
- **本地方案不调广告 API**：投放建议只给梯度与人群定向提示，**绝不连任何广告/投放平台接口**（→ Trust）
- **可复算**：所有产物由纯函数从输入派生，同样输入必得同样输出，便于回归与审计（→ Reliability）
- **不编造数据**：`feedback` 严格基于传入 `--metrics` 或选题基因；无数据时不编造假数，只给默认策略（→ Trust）
- **与闭环关系**：本款是引流收口环，`feedback` 字段必须可机械回灌 `aladin-drama-topic`，不引入 topic 工坊无法解析的字段（→ Convention）
- **description 单行**：禁用 YAML 多行语法，保持可发布（→ Convention）

## 与 aladin 短剧系列关系

本技能是 **AI 短剧创作闭环第 8 环（引流收口）**：吃 `aladin-drama-publish` 的 `_publish_plan.json` + 选题/剧本数据，`出 _traffic_plan.json`，其中 `feedback` 字段回灌 `aladin-drama-topic`，使"选题→脚本→生成→剪辑→发布→引流→(反哺)→选题"成环。与 omni-engage（互动承接）互补、与 omni-growth（数据复盘）差异在"主动引流+反哺创作"。上游工坊：topic / script / gen / subtitle / dub / edit / publish；本款承接发布结果，向下游 topic 反哺，是闭环的"收口+启动"双角色。
