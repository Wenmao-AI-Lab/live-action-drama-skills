# 使用示例与 FAQ（阿拉丁·aladin-drama-cover）

## 场景 1：一部剧一键出全套封面方案（最常用）

```bash
python scripts/cover_ingest.py --script _script.json --out _cover_ir.json
python scripts/cover_plan.py --ir _cover_ir.json --out _cover.json --platform 抖音
python scripts/cover_report.py --plan _cover.json --out-html cover_board.html --out-md _cover_plan.md --out-csv cover_prompts.csv
```

产出：系列主封面 2 版 + 每集 A/B 双版，HTML 看板 + 方案书 + 批量生图清单。

## 场景 2：接角色一致性工坊，封面脸和正片一致

```bash
python scripts/cover_ingest.py --script _script.json --cast cast_cards.json --out _cover_ir.json
```

角色卡的 anchor_zh/anchor_en 自动注入封面提示词，避免"封面一个脸、正片另一个脸"。

## 场景 3：多平台矩阵分发

```bash
for p in 红果 抖音 视频号; do
  python scripts/cover_plan.py --ir _cover_ir.json --out _cover_$p.json --platform $p
done
```

同一 IR 按平台限长/比例/角标各出一套，标题会按平台限长重新截断打分。

## 场景 4：与 Hy3 协作补弱封面

1. 跑完方案后看 `_cover.json → feedback.weak_cover_eps`（CTR 信号 < 3.0 的集）；
2. 把该集的 `hook_end/turn/peak_shot` 交给 Hy3：
   「按短剧封面标题风格重写 3 个 12 字以内的爆款标题，保留悬念，带身份/反转词」；
3. 人工选定后回填 `_cover.json` 对应封面的 `main_title`，重跑 cover_report 即可。

**人机分工**：脚本管「构图选哪式、标题谁得分高、落位在哪、seed 是多少」（结构与规则），
Hy3 管「标题怎么改得更炸、副标题文案润色」（语义与文采）。

## 场景 5：生图清单怎么用

`cover_prompts.csv` 每行一张封面：把 `prompt_zh`（即梦/可灵）或 `prompt_en`（海外模型）
连同 `neg_prompt` 与 `seed` 填入生图工具即可批量出图；同 seed 重跑结果稳定。

## FAQ

**Q：没有 _script.json，只有大纲文本？**
先用剧本创作环节生成 `_script.json`（本系列契约入口），或手工整理成契约结构
（episodes[].scenes[].shots[] 或 episodes[].shots[] 均可）。

**Q：CTR 信号分能当点击率预估吗？**
不能。它是确定性结构信号，用于同剧内排序与找短板；真实点击请以 A/B 投放数据为准。

**Q：为什么第 7 集这类"日常过渡集"总是弱封面？**
过渡集天然缺钩子。两个办法：标题借下一集的悬念（"下集他身份藏不住了"），
或封面直接用系列主封面变体，减少过渡集的独立封面投入。

**Q：封面会真的画出来吗？**
不会。本技能产出**方案与生图清单**（构图/标题/提示词/seed），生图交给你选择的
文生图工具；这样零付费、可换模型、可复算。
