#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿拉丁·AI短剧封面海报工坊 - 第2步：封面方案设计
读 _cover_ir.json → 系列主封面 + 每集封面 A/B 双版：
构图模板（按峰值情绪确定性选择）+ 主标题打分优选 + 副标题/角标
+ 文生图提示词(中英双语·角色锚注入·派生seed·负向词) + 点击信号评分
→ _cover.json（含 feedback 回灌契约）
纯标准库，确定性可复算。
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

# 六平台封面规格
PLATFORM = {
    "红果":  {"ratio": "3:4",  "size": "1080x1440", "title_max": 12, "badge": "会员免费", "note": "剧场卡片流，标题大字居中，正红底色系点击率高"},
    "抖音":  {"ratio": "9:16", "size": "1080x1920", "title_max": 14, "badge": "更新至{ep}集", "note": "全屏封面，标题上1/3安全区，避开右侧互动栏"},
    "快手":  {"ratio": "9:16", "size": "1080x1920", "title_max": 14, "badge": "独家", "note": "偏乡土浓烈配色，人物表情夸张更抓点击"},
    "视频号": {"ratio": "6:7",  "size": "1080x1260", "title_max": 12, "badge": "朋友都在看", "note": "社交信任流，封面干净+真人出镜转化更好"},
    "B站":   {"ratio": "16:10", "size": "1146x717", "title_max": 20, "badge": "第{ep}话", "note": "横版封面，弹幕人群吃梗，标题可玩反差"},
    "通用":  {"ratio": "3:4",  "size": "1080x1440", "title_max": 14, "badge": "第{ep}集", "note": "竖版通用规格，兼容多数短剧平台"},
}

# 构图模板：按峰值镜头情绪确定性映射
COMPOSITION = {
    "对峙冲突": {"moods": ["冲突", "愤怒", "危机"], "layout": "双人对峙·对角线构图·冷暖撞色", "zone": "标题置顶部横贯", "en": "two characters confronting, diagonal composition, warm-cold color clash"},
    "身份反差": {"moods": ["反转", "震惊", "打脸"], "layout": "主角特写+身后身份符号(豪车/西装人墙)·前后景反差", "zone": "标题居中大字", "en": "close-up of protagonist with hidden-identity symbols behind, foreground-background contrast"},
    "高能爆发": {"moods": ["燃"], "layout": "主角低角度仰拍·逆光剪影·气场全开", "zone": "标题置底部", "en": "low-angle hero shot, backlit silhouette, powerful aura"},
    "情感暴击": {"moods": ["绝望", "悬疑"], "layout": "单人特写·含泪/凝视镜头·暗调留白", "zone": "标题置底部压暗区", "en": "single close-up, teary or intense gaze, dark tone with negative space"},
    "甜宠氛围": {"moods": ["甜宠", "暧昧", "温馨", "治愈"], "layout": "双人亲密同框·柔光暖调·浅景深", "zone": "标题置顶部留白区", "en": "romantic couple frame, soft warm light, shallow depth of field"},
    "喜剧夸张": {"moods": ["搞笑"], "layout": "夸张表情特写·高饱和撞色·漫画感", "zone": "标题斜置", "en": "exaggerated comedic expression close-up, high saturation, comic style"},
}
DEFAULT_COMP = "身份反差"

# 标题信号词打分
ID_WORDS = ["总裁", "首富", "千金", "少爷", "董事长", "大小姐", "继承人", "隐藏", "马甲", "豪门"]
TWIST_WORDS = ["竟", "居然", "没想到", "原来", "反转", "揭穿", "曝光", "真相"]
CONFLICT_WORDS = ["退婚", "打脸", "羞辱", "逆袭", "复仇", "离婚", "跪", "耳光", "骗局"]
NEG_PROMPT = ("blurry, deformed face, extra fingers, bad anatomy, watermark, "
              "text artifacts, low quality, inconsistent face, different person")


def title_score(text, limit):
    """标题点击信号打分（确定性）"""
    s = 0.0
    if "？" in text or "?" in text:
        s += 2.0
    s += sum(2.0 for w in ID_WORDS if w in text)
    s += sum(1.5 for w in TWIST_WORDS if w in text)
    s += sum(1.5 for w in CONFLICT_WORDS if w in text)
    if re.search(r"[0-9一二三五七八十百千万亿]{1,4}[年天秒集次亿万]", text):
        s += 1.0
    over = max(0, len(text) - limit)
    s -= over * 0.8  # 超长惩罚
    return round(s, 2)


def derive_seed(*parts):
    """md5 派生确定性 seed（与闭环系列同法）"""
    h = hashlib.md5("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()
    return int(h[:8], 16) % 2147483647


def clip_title(text, limit):
    """截断到平台限长（保守按句读切）"""
    text = re.sub(r"[。！!]$", "", text.strip())
    if len(text) <= limit:
        return text
    for sep in ["，", "：", "、", ",", " "]:
        if sep in text:
            head = text.split(sep)[0]
            if 4 <= len(head) <= limit:
                return head
    return text[:limit]


def pick_composition(mood):
    for name, c in COMPOSITION.items():
        if mood in c["moods"]:
            return name
    return DEFAULT_COMP


def char_anchor(ir, name):
    for c in ir.get("main_characters", []):
        if c.get("name") == name:
            return c
    return {}


def build_prompt(ir, comp, ep_ir, platform_conf, variant):
    """文生图提示词：构图 + 角色锚 + 风格 + 比例"""
    c = COMPOSITION[comp]
    peak = ep_ir.get("peak_shot") or {}
    who = peak.get("character", "")
    anchor = char_anchor(ir, who)
    zh_parts = []
    en_parts = []
    if anchor.get("anchor_zh"):
        zh_parts.append(anchor["anchor_zh"])
    elif who:
        zh_parts.append(f"角色「{who}」")
    if anchor.get("anchor_en"):
        en_parts.append(anchor["anchor_en"])
    zh_parts.append(c["layout"])
    en_parts.append(c["en"])
    if variant == "B":
        zh_parts.append("大面积文字排版留白，海报感强")
        en_parts.append("bold typographic layout with negative space, poster style")
    scene = peak.get("scene") or ""
    if scene:
        zh_parts.append(f"场景：{scene}")
    style = ir.get("style") or ir.get("genre") or "都市短剧"
    zh_parts.append(f"{style}风格，电影质感，竖版短剧封面，{platform_conf['ratio']}构图，8K细节")
    en_parts.append(f"cinematic short-drama cover poster, {platform_conf['ratio']} aspect, ultra detail")
    return "，".join(zh_parts), ", ".join(en_parts)


def main():
    ap = argparse.ArgumentParser(description="短剧封面方案设计")
    ap.add_argument("--ir", required=True, help="_cover_ir.json")
    ap.add_argument("--out", default="_cover.json")
    ap.add_argument("--platform", default="通用", choices=list(PLATFORM.keys()))
    args = ap.parse_args()

    ir = json.loads(Path(args.ir).read_text(encoding="utf-8-sig"))
    pf = PLATFORM[args.platform]
    title = ir.get("title", "未命名短剧")
    covers = []

    # ---- 系列主封面（A/B 双版） ----
    all_peaks = [e.get("peak_shot") for e in ir.get("episodes", []) if e.get("peak_shot")]
    series_peak = max(all_peaks, key=lambda s: s["hotness"]) if all_peaks else {}
    series_mood = series_peak.get("mood", "")
    comp_main = pick_composition(series_mood)
    # 主标题候选：剧名 / premise 短句 / 最强 hook
    cands = [title]
    if ir.get("premise"):
        first = re.split(r"[，。,]", ir["premise"])[0]
        if first:
            cands.append(first)
    best_hook = ""
    best_hs = -1
    for e in ir.get("episodes", []):
        clipped = clip_title(e.get("hook_end", ""), pf["title_max"])
        hs = title_score(clipped, pf["title_max"])
        if clipped and hs > best_hs:
            best_hs, best_hook = hs, clipped
    if best_hook:
        cands.append(best_hook)
    # 先按平台限长截断、再打分，避免长钩子被超长惩罚误杀
    scored = sorted({(title_score(clip_title(c, pf["title_max"]), pf["title_max"]),
                      clip_title(c, pf["title_max"])) for c in cands}, reverse=True)
    main_title = scored[0][1]
    for variant in ("A", "B"):
        pz, pe = build_prompt(ir, comp_main, {"peak_shot": series_peak}, pf, variant)
        covers.append({
            "id": f"S-{variant}", "scope": "series", "ep": None, "variant": variant,
            "composition": comp_main,
            "layout": COMPOSITION[comp_main]["layout"],
            "title_zone": COMPOSITION[comp_main]["zone"],
            "main_title": main_title if variant == "A" else clip_title(title, pf["title_max"]),
            "subtitle": ir.get("tone", ""),
            "badge": pf["badge"].replace("{ep}", str(len(ir.get("episodes", [])))),
            "prompt_zh": pz, "prompt_en": pe, "neg_prompt": NEG_PROMPT,
            "seed": derive_seed(title, "series", variant),
            "ctr_score": round(scored[0][0] + (1.0 if variant == "A" else 0.5), 2),
        })

    # ---- 每集封面（A/B 双版） ----
    for e in ir.get("episodes", []):
        peak = e.get("peak_shot") or {}
        comp = pick_composition(peak.get("mood", ""))
        cands = [x for x in (e.get("hook_end", ""), e.get("turn", ""),
                             peak.get("dialogue", "")) if x]
        if not cands:
            cands = [f"{title} 第{e.get('ep')}集"]
        # 先截断再打分（同系列主封面逻辑），并列时保输入顺序稳定
        clipped = []
        seen = set()
        for c in cands:
            cc = clip_title(c, pf["title_max"])
            if cc and cc not in seen:
                seen.add(cc)
                clipped.append(cc)
        sc = sorted(((title_score(c, pf["title_max"]), -i, c)
                     for i, c in enumerate(clipped)), reverse=True)
        sc = [(s, c) for s, _, c in sc]
        ep_title = sc[0][1]
        for variant in ("A", "B"):
            pick = sc[0][1] if variant == "A" else (sc[1][1] if len(sc) > 1 else sc[0][1])
            pz, pe = build_prompt(ir, comp, e, pf, variant)
            covers.append({
                "id": f"E{e.get('ep')}-{variant}", "scope": "episode",
                "ep": e.get("ep"), "variant": variant,
                "composition": comp,
                "layout": COMPOSITION[comp]["layout"],
                "title_zone": COMPOSITION[comp]["zone"],
                "main_title": pick if variant == "B" else ep_title,
                "subtitle": e.get("goal", ""),
                "badge": pf["badge"].replace("{ep}", str(e.get("ep"))),
                "prompt_zh": pz, "prompt_en": pe, "neg_prompt": NEG_PROMPT,
                "seed": derive_seed(title, e.get("ep"), variant),
                "ctr_score": round(sc[0][0] + peak.get("hotness", 0) * 0.3, 2),
            })

    ranked = sorted((c for c in covers if c["scope"] == "episode"),
                    key=lambda c: -c["ctr_score"])
    weak = sorted({c["ep"] for c in ranked if c["ctr_score"] < 3.0})
    plan = {
        "meta": {"tool": "aladin-drama-cover", "step": "plan",
                 "platform": args.platform, "spec": pf},
        "title": title,
        "covers": covers,
        "feedback": {  # 回灌契约：供 publish 排期引用 / insight 投后验证
            "top_cover": ranked[0]["id"] if ranked else None,
            "weak_cover_eps": weak,
            "to_publish": [c["id"] for c in covers],
            "note": "top_cover 建议作为首发主推封面；weak_cover_eps 建议人工/Hy3 重写标题后再生图",
        },
    }
    Path(args.out).write_text(
        json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] 封面方案: {args.platform} {pf['size']} ｜系列主封面 2 版 + "
          f"分集 {len(covers) - 2} 版 ｜最强 {plan['feedback']['top_cover']} "
          f"｜弱封面集 {weak or '无'} → {args.out}")


if __name__ == "__main__":
    main()
