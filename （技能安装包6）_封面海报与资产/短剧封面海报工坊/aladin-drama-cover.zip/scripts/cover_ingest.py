#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿拉丁·AI短剧封面海报工坊 - 第1步：素材归一
读取 _script.json（兼容双契约）+ 可选 cast_cards.json（角色锚），
提取 剧名/题材/每集钩子/峰值镜头/主角出场频次/关键台词 → _cover_ir.json
纯标准库，零依赖，确定性可复算。
"""
import argparse
import json
import sys
from pathlib import Path

# 情绪基线分（与闭环系列一致的确定性打分）
MOOD_SCORE = {
    "反转": 5.0, "打脸": 5.0, "震惊": 4.5, "燃": 4.5, "危机": 4.0,
    "绝望": 4.0, "冲突": 3.5, "悬疑": 3.5, "愤怒": 3.0, "甜宠": 2.5,
    "暧昧": 2.5, "温馨": 2.0, "治愈": 2.0, "搞笑": 2.5, "日常": 1.0,
}
DEFAULT_MOOD = 1.5

# 爽点关键词（命中一次 +1.2）
PAYOFF_KW = [
    "反转", "打脸", "逆袭", "退婚", "身份", "总裁", "首富", "继承",
    "真相", "曝光", "揭穿", "跪", "耳光", "离婚", "复仇", "马甲",
    "千金", "少爷", "董事长", "隐藏", "秘密", "车祸", "私生",
]
# 悬念信号词（封面副标题/角标素材）
HOOK_KW = ["竟", "居然", "没想到", "原来", "真相", "秘密", "？", "?", "隐瞒", "骗局"]


def load_json(path):
    p = Path(path)
    if not p.exists():
        print(f"[ERR] 文件不存在: {path}", file=sys.stderr)
        sys.exit(2)
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except Exception as e:
        print(f"[ERR] JSON 解析失败 {path}: {e}", file=sys.stderr)
        sys.exit(2)


def norm_project(data):
    """project 双契约：字符串 或 {title, style}"""
    proj = data.get("project", "")
    if isinstance(proj, dict):
        title = proj.get("title") or proj.get("name") or "未命名短剧"
        style = proj.get("style") or data.get("genre") or ""
    else:
        title = str(proj) if proj else "未命名短剧"
        style = data.get("genre") or ""
    return title, style


def iter_shots(ep):
    """镜头双契约：episodes[].scenes[].shots[] 或 episodes[].shots[]"""
    if isinstance(ep.get("scenes"), list):
        for sc in ep["scenes"]:
            for sh in sc.get("shots", []) or []:
                yield sh, sc.get("scene", "")
    for sh in ep.get("shots", []) or []:
        yield sh, ep.get("scene", "")


def shot_hotness(shot):
    """镜头高能度 = 情绪基线 + 爽点词命中"""
    score = MOOD_SCORE.get(str(shot.get("mood", "")), DEFAULT_MOOD)
    text = f"{shot.get('action', '')}{shot.get('dialogue', '')}"
    for kw in PAYOFF_KW:
        if kw in text:
            score += 1.2
    return round(score, 2)


def main():
    ap = argparse.ArgumentParser(description="短剧封面素材归一")
    ap.add_argument("--script", required=True, help="_script.json 路径")
    ap.add_argument("--cast", default=None, help="可选：cast_cards.json 角色卡（注入外貌锚）")
    ap.add_argument("--out", default="_cover_ir.json")
    args = ap.parse_args()

    data = load_json(args.script)
    title, style = norm_project(data)

    # 可选角色锚（来自角色一致性工坊的角色卡，双结构兼容 list / {cards: []}）
    anchors = {}
    if args.cast:
        cast = load_json(args.cast)
        cards = cast.get("cards") if isinstance(cast, dict) else cast
        for c in cards or []:
            if isinstance(c, dict) and c.get("name"):
                anchors[c["name"]] = {
                    "anchor_zh": c.get("anchor_zh", ""),
                    "anchor_en": c.get("anchor_en", ""),
                    "seed": c.get("seed"),
                }

    char_freq = {}
    episodes_ir = []
    for ep in data.get("episodes", []) or []:
        shots = []
        for sh, scene in iter_shots(ep):
            if not isinstance(sh, dict):
                continue
            hot = shot_hotness(sh)
            shots.append({
                "shot_no": sh.get("shot_no"),
                "scene": scene,
                "shot_type": sh.get("shot_type", ""),
                "action": sh.get("action", ""),
                "dialogue": sh.get("dialogue", ""),
                "character": sh.get("character", ""),
                "mood": sh.get("mood", ""),
                "hotness": hot,
            })
            ch = sh.get("character", "")
            if ch:
                char_freq[ch] = char_freq.get(ch, 0) + 1

        peak = max(shots, key=lambda s: s["hotness"]) if shots else None
        hook_end = str(ep.get("hook_end", "") or "")
        hook_signals = [kw for kw in HOOK_KW if kw in hook_end]
        episodes_ir.append({
            "ep": ep.get("ep"),
            "goal": ep.get("goal", ""),
            "turn": ep.get("turn", ""),
            "hook_end": hook_end,
            "hook_signals": hook_signals,
            "peak_shot": peak,
            "shot_count": len(shots),
        })

    mains = sorted(char_freq.items(), key=lambda kv: (-kv[1], kv[0]))[:4]
    ir = {
        "meta": {"tool": "aladin-drama-cover", "step": "ingest", "source": args.script},
        "title": title,
        "style": style,
        "genre": data.get("genre", ""),
        "tone": data.get("tone", ""),
        "premise": data.get("premise", ""),
        "main_characters": [
            {"name": n, "appearances": c, **anchors.get(n, {})} for n, c in mains
        ],
        "episodes": episodes_ir,
    }
    Path(args.out).write_text(
        json.dumps(ir, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] 归一完成: 剧名《{title}》 {len(episodes_ir)} 集 "
          f"主角 {len(mains)} 人 → {args.out}")


if __name__ == "__main__":
    main()
