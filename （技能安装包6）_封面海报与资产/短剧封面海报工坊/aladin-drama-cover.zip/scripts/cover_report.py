#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
阿拉丁·AI短剧封面海报工坊 - 第3步：看板 + 方案书 + 生图清单
读 _cover.json → cover_board.html（SVG 封面构图小样墙 + 排行 + A/B 对比）
+ _cover_plan.md（封面方案书）+ cover_prompts.csv（批量生图清单，RFC4180 转义）
纯标准库，自包含 HTML（零外链）。
"""
import argparse
import json
from pathlib import Path

MOOD_COLOR = {
    "反转": "#e74c3c", "打脸": "#e74c3c", "震惊": "#e67e22", "燃": "#f39c12",
    "危机": "#8e44ad", "绝望": "#34495e", "冲突": "#c0392b", "悬疑": "#2c3e50",
    "愤怒": "#d35400", "甜宠": "#e91e8c", "暧昧": "#e91e8c", "温馨": "#27ae60",
    "治愈": "#27ae60", "搞笑": "#16a085",
}
COMP_COLOR = {
    "对峙冲突": "#c0392b", "身份反差": "#8e44ad", "高能爆发": "#f39c12",
    "情感暴击": "#34495e", "甜宠氛围": "#e91e8c", "喜剧夸张": "#16a085",
}


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _csv_field(s):
    """RFC4180：整体双引号包裹 + 内部双引号翻倍"""
    s = str(s if s is not None else "")
    return '"' + s.replace('"', '""') + '"'


def svg_cover(c, x, y, w=132, h=176):
    """单张封面构图小样（竖版矩形 + 标题区 + 角标 + 评分）"""
    col = COMP_COLOR.get(c["composition"], "#7f8c8d")
    zone = c.get("title_zone", "")
    ty = y + 26 if ("顶部" in zone) else (y + h - 22 if "底部" in zone else y + h // 2)
    t = c.get("main_title", "")
    t_show = t if len(t) <= 9 else t[:8] + "…"
    parts = [
        f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{col}" opacity="0.16" stroke="{col}" stroke-width="1.5"/>',
        f'<rect x="{x}" y="{y}" width="{w}" height="26" rx="8" fill="{col}" opacity="0.85"/>',
        f'<text x="{x + w / 2}" y="{y + 17}" text-anchor="middle" font-size="11" fill="#ffffff">{esc(c["id"])} · {esc(c["composition"])}</text>',
        f'<text x="{x + w / 2}" y="{ty}" text-anchor="middle" font-size="12" font-weight="bold" fill="#2c3e50">{esc(t_show)}</text>',
        f'<rect x="{x + 4}" y="{y + h - 20}" width="{min(w - 8, 10 + 11 * len(str(c.get("badge", ""))))}" height="16" rx="3" fill="#e74c3c" opacity="0.9"/>',
        f'<text x="{x + 9}" y="{y + h - 8}" font-size="10" fill="#ffffff">{esc(c.get("badge", ""))}</text>',
        f'<text x="{x + w - 6}" y="{y + h + 14}" text-anchor="end" font-size="11" fill="#7f8c8d">CTR信号 {c.get("ctr_score", 0)}</text>',
    ]
    return "".join(parts)


def build_html(plan):
    covers = plan["covers"]
    spec = plan["meta"]["spec"]
    per_row = 6
    rows = (len(covers) + per_row - 1) // per_row
    cell_w, cell_h = 152, 216
    svg_w, svg_h = per_row * cell_w + 20, rows * cell_h + 20
    tiles = []
    for i, c in enumerate(covers):
        x = 12 + (i % per_row) * cell_w
        y = 12 + (i // per_row) * cell_h
        tiles.append(svg_cover(c, x, y))
    ranked = sorted((c for c in covers if c["scope"] == "episode"),
                    key=lambda c: -c["ctr_score"])
    rank_rows = "".join(
        f'<tr><td>{i + 1}</td><td>{esc(c["id"])}</td><td>{esc(c["composition"])}</td>'
        f'<td>{esc(c["main_title"])}</td><td>{c["ctr_score"]}</td></tr>'
        for i, c in enumerate(ranked[:10]))
    fb = plan.get("feedback", {})
    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>{esc(plan["title"])} · 封面看板 · 阿拉丁</title>
<style>
body{{font-family:"Microsoft YaHei",sans-serif;background:#f6f7fb;color:#2c3e50;margin:0;padding:24px}}
.card{{background:#fff;border-radius:12px;padding:20px;margin-bottom:20px;box-shadow:0 2px 8px rgba(0,0,0,.06)}}
h1{{font-size:22px;margin:0 0 6px}} h2{{font-size:16px;border-left:4px solid #e74c3c;padding-left:8px}}
table{{border-collapse:collapse;width:100%;font-size:13px}}
th,td{{border:1px solid #e5e8ef;padding:6px 10px;text-align:left}}
th{{background:#f0f2f8}}
.kpi{{display:inline-block;background:#f0f2f8;border-radius:8px;padding:8px 16px;margin-right:12px;font-size:13px}}
.kpi b{{font-size:18px;color:#e74c3c}}
</style></head><body>
<div class="card"><h1>《{esc(plan["title"])}》封面海报方案看板</h1>
<div>阿拉丁·AI短剧封面海报工坊 ｜ 平台：{esc(plan["meta"]["platform"])} ｜ 规格：{esc(spec["size"])}（{esc(spec["ratio"])}）｜ 标题限长 {spec["title_max"]} 字</div>
<div style="margin-top:10px">
<span class="kpi">封面总数 <b>{len(covers)}</b></span>
<span class="kpi">最强封面 <b>{esc(fb.get("top_cover") or "-")}</b></span>
<span class="kpi">待加强集 <b>{esc(",".join(map(str, fb.get("weak_cover_eps", []))) or "无")}</b></span>
</div></div>
<div class="card"><h2>封面构图小样墙（A=人物向 / B=文字海报向）</h2>
<svg viewBox="0 0 {svg_w} {svg_h}" width="100%" xmlns="http://www.w3.org/2000/svg">{"".join(tiles)}</svg>
<div style="font-size:12px;color:#7f8c8d">小样仅示意构图分区与标题落位；实际画面由生图清单 cover_prompts.csv 中的提示词 + seed 生成。</div></div>
<div class="card"><h2>分集封面点击信号排行 TOP10</h2>
<table><tr><th>#</th><th>封面</th><th>构图</th><th>主标题</th><th>CTR信号</th></tr>{rank_rows}</table></div>
<div class="card"><h2>回灌建议</h2><div style="font-size:13px">{esc(fb.get("note", ""))}</div></div>
<div style="text-align:center;color:#95a5a6;font-size:12px;padding:8px">阿拉丁·AI短剧创作闭环 · aladin-drama-cover</div>
</body></html>"""
    return html


def build_md(plan):
    spec = plan["meta"]["spec"]
    fb = plan.get("feedback", {})
    lines = [
        f"# 《{plan['title']}》封面海报方案书",
        "",
        f"- 出品工具：阿拉丁·AI短剧封面海报工坊（aladin-drama-cover）",
        f"- 目标平台：{plan['meta']['platform']} ｜ 规格 {spec['size']}（{spec['ratio']}）｜ 标题限长 {spec['title_max']} 字",
        f"- 平台要点：{spec['note']}",
        f"- 最强封面：{fb.get('top_cover') or '-'} ｜ 待加强集：{fb.get('weak_cover_eps') or '无'}",
        "",
    ]
    for c in plan["covers"]:
        scope = "系列主封面" if c["scope"] == "series" else f"第 {c['ep']} 集"
        lines += [
            f"## {c['id']}｜{scope}｜{c['variant']} 版（{c['composition']}）",
            "",
            f"- **主标题**：{c['main_title']}",
            f"- 副标题：{c.get('subtitle') or '-'} ｜ 角标：{c.get('badge') or '-'}",
            f"- 构图：{c['layout']} ｜ 标题落位：{c['title_zone']}",
            f"- CTR 信号：{c['ctr_score']} ｜ seed：{c['seed']}",
            f"- 生图提示词（中）：{c['prompt_zh']}",
            f"- 生图提示词（英）：{c['prompt_en']}",
            f"- 负向词：{c['neg_prompt']}",
            "",
        ]
    return "\n".join(lines)


def build_csv(plan):
    spec = plan["meta"]["spec"]
    head = ["id", "scope", "ep", "variant", "platform", "size", "main_title",
            "subtitle", "badge", "composition", "prompt_zh", "prompt_en",
            "neg_prompt", "seed", "ctr_score"]
    rows = [",".join(head)]
    for c in plan["covers"]:
        rows.append(",".join(_csv_field(v) for v in [
            c["id"], c["scope"], c.get("ep") or "", c["variant"],
            plan["meta"]["platform"], spec["size"], c["main_title"],
            c.get("subtitle", ""), c.get("badge", ""), c["composition"],
            c["prompt_zh"], c["prompt_en"], c["neg_prompt"],
            c["seed"], c["ctr_score"]]))
    return "\r\n".join(rows) + "\r\n"


def main():
    ap = argparse.ArgumentParser(description="短剧封面看板与生图清单")
    ap.add_argument("--plan", required=True, help="_cover.json")
    ap.add_argument("--out-html", default="cover_board.html")
    ap.add_argument("--out-md", default="_cover_plan.md")
    ap.add_argument("--out-csv", default="cover_prompts.csv")
    args = ap.parse_args()

    plan = json.loads(Path(args.plan).read_text(encoding="utf-8-sig"))
    Path(args.out_html).write_text(build_html(plan), encoding="utf-8")
    Path(args.out_md).write_text(build_md(plan), encoding="utf-8")
    # newline="" 防止 Windows 把 \r\n 二次翻译成 \r\r\n 产生空行
    with open(args.out_csv, "w", encoding="utf-8-sig", newline="") as f:
        f.write(build_csv(plan))
    print(f"[OK] 看板 {args.out_html} ｜方案书 {args.out_md} ｜生图清单 {args.out_csv}"
          f"（{len(plan['covers'])} 张封面）")


if __name__ == "__main__":
    main()
