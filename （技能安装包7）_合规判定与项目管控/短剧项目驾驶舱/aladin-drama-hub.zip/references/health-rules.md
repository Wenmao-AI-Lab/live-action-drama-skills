# K1-K5 健康体检规则细则

全部为**确定性规则**：同一输入必得同一结果，可复算、可追溯。

## 严重级别与评分模型

| 级别 | 含义 | 扣分 |
|------|------|------|
| P0 | 阻断：继续推进会直接失败或产生上架风险 | -25 |
| P1 | 风险：产物不可信/不可追溯/已过期 | -10 |
| P2 | 建议：最佳实践缺口 | -3 |

健康分 = max(0, 100 - Σ扣分)。等级：A ≥ 90，B ≥ 75，C ≥ 60，否则 D。
门禁：存在 P0 → `BLOCK`；仅 P1/P2 → `REVIEW`；无问题 → `READY`。

## K1 契约体检

| 代码 | 级别 | 触发条件 |
|------|------|----------|
| K1-JSON-BROKEN | P0 | 任一 `.json` 产物无法解析（语法损坏/编码错误） |
| K1-SCRIPT-LEGACY | P1 | `_script.json` 为旧契约：`project` 是字符串（下游视频生成环节期望对象 `{title, style}`），或 `shot.character` 是字符串（期望列表）。直串下游会报 `'str' object has no attribute 'get'` |

**--fix 行为（唯一写动作）**：对 K1-SCRIPT-LEGACY 生成 `_script_genready.json`：
- `project: "剧名"` → `project: {title: "剧名", style: genre 或 tone 或默认}`
- `character: "甲、乙"` → `character: ["甲", "乙"]`（顿号/逗号分隔）
- 深拷贝转换，**原文件不改动**；不臆造任何新内容。

## K2 断链体检（P1）

环节已 `done` 但任一上游环节的 core 产物缺失 → `K2-BROKEN-CHAIN`。
含义：该产物来源不可追溯、无法复算（例如没有剧本却有了发行计划）。

## K3 时序体检（P1）

下游 core 产物的 mtime **早于** 上游 core 产物 → `K3-STALE`。
含义：上游改过了、下游没重跑，下游产物可能基于旧版本（例如剧本改了第 3 版，字幕还是按第 1 版切的）。

## K4 跨产物一致性

| 代码 | 级别 | 触发条件 |
|------|------|----------|
| K4-EP-MISMATCH | P1 | dub/bgm/money/i18n 产物声明的集数（`episodes` 数组长度或 `episode_total` 字段）≠ 剧本实际集数 |
| K4-PAYWALL-RANGE | P0 | 付费墙集数（`paywall_episode`）超出剧本集数范围，上架会配置失败 |
| K4-GATE-BLOCK | P0 | 合规产物 `verdict/gate` 含 BLOCK，但发行计划已生成——带病上架有下架/限流风险 |
| K4-NO-CAST | P2 | 已生成分镜提示词但未建角色一致性锚——多镜头/多集易变脸 |
| K4-NO-COMPLY | P1 | 发行计划已生成但未做合规预检 |

一致性核对**仅在字段可读时进行**：字段缺失或结构不同则跳过，不猜测、不误报。

## K5 下一步导航

对所有非 `done` 环节，按闭环拓扑顺序输出行动项：
- `ready = true`：全部上游已 done，可立即执行（排前）。
- `ready = false`：标注还在等哪些上游。
- 每项附该环节的推荐脚本命令（见 `hub_check.py` 的 `NEXT_CMD`）。

`_hub_health.json.feedback` 回灌契约：`{completion_pct, blocking_stages, next_stage}`，供闭环内其他环节联动。
