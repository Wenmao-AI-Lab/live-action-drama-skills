# 使用示例与最佳实践

## 场景 1：接手别人的短剧项目，先盘家底

**背景**：团队交接了一个做到一半的短剧项目目录，里面十几个 `_*.json` 文件，不知道进行到哪一步。

```bash
python scripts/hub_scan.py D:/drama/zhaimen --out _hub_ir.json
python scripts/hub_check.py _hub_ir.json --out _hub_health.json
python scripts/hub_report.py _hub_ir.json _hub_health.json
```

**产出**：`hub_board.html` 打开即见——15 环节地图上 6 绿 2 黄 7 灰，完成度 46.7%，健康分 80（B 级），下一步导航第一条是"剪辑合成（上游已就绪，可立即执行）"。交接会直接投屏这一页。

## 场景 2：剧本喂视频生成环节报错，定位契约问题

**背景**：`_script.json` 喂给分镜提示词脚本报 `'str' object has no attribute 'get'`。

```bash
python scripts/hub_scan.py . --out _hub_ir.json
python scripts/hub_check.py _hub_ir.json --fix --out _hub_health.json
```

**产出**：问题清单出现 `K1-SCRIPT-LEGACY`（project 为字符串/character 为字符串），并已自动生成 `_script_genready.json`（原文件未动）。把下游输入换成该文件即可继续，无需手改 JSON。

## 场景 3：上架前最后一道总检

**背景**：全链路产物都齐了，明天排期上架，想再过一遍有没有隐患。

```bash
python scripts/hub_scan.py . --out _hub_ir.json
python scripts/hub_check.py _hub_ir.json --out _hub_health.json
python scripts/hub_report.py _hub_ir.json _hub_health.json --out-md _hub_plan.md
```

**产出**：体检发现 `K3-STALE`（剧本 mtime 晚于字幕——剧本第 3 版改了台词，字幕没重跑）和 `K4-GATE-BLOCK`（合规门禁 BLOCK 但发行计划已生成）→ 门禁 BLOCK，0 分警示。按行动清单先重跑字幕、整改合规复检 READY 后再上架，避免了带病发行。

## 最佳实践

1. **产物集中放**：把各环节产物统一放在项目根目录（或 build/ 子目录），驾驶舱识别率最高。
2. **每完成一个环节跑一次**：`scan + check` 只要一两秒，随手体检，问题在最便宜的时候暴露。
3. **--fix 只在需要时加**：日常盘点不加 --fix，保持纯只读；遇到契约报错再加。
4. **把 hub_board.html 当日报**：自包含零外链，直接发群里/投屏，比口头同步进度可靠。
5. **CI 化**：把三条命令挂到定时任务，门禁 BLOCK 时通知负责人。

## FAQ

**Q：不是用阿拉丁系列环节技能生成的产物，能盘点吗？**
A：能。驾驶舱只认契约文件名（如 `_script.json`），不管产物是谁生成的；字段读不出来时一致性核对自动跳过，不误报。

**Q：为什么某环节明明跑过了却显示 todo？**
A：检查产物文件名是否与注册表一致（见 `stage-registry.md`），或产物是否放在了扫描范围之外的深层子目录。

**Q：--fix 会改坏我的剧本吗？**
A：不会。--fix 只**新增** `_script_genready.json`，原 `_script.json` 一个字节都不动；转换是确定性的字段形态适配，不生成任何新内容。

**Q：健康分和门禁的关系？**
A：健康分是量化参考（扣分制），门禁是行动指令——BLOCK 表示存在 P0 必须先整改；REVIEW 表示有风险项建议处理；READY 表示可以推进。

**Q：能自动帮我把缺的环节跑了吗？**
A：不能，也不应该。驾驶舱只给导航（该跑什么、用什么命令），执行由你决定——各环节有创作决策，不适合黑箱自动化。
