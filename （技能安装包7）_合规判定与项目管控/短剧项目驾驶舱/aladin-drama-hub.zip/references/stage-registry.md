# 15 环节注册表（契约文件名 + 依赖拓扑）

驾驶舱按下表识别项目目录中的产物。**core** 命中 → 环节 `done`；仅 **extra** 命中 → `partial`；均未命中 → `todo`。扫描范围：项目目录一层 + `build/`、`out/`、`dist/`、`artifacts/` 子目录。

| # | 环节 id | 名称 | core 产物 | extra 产物 | 上游依赖 |
|---|---------|------|-----------|-----------|----------|
| 1 | topic | 选题策划 | `_topics.json` | `_research.json` | - |
| 2 | script | 剧本创作 | `_script.json` | `_shots.json` | topic |
| 3 | gen | AI视频生成 | `_prompts.json` / `*_prompts_raw.json` | `_plan.json` | script |
| 4 | cast | 角色一致性 | `_cast.json` | `_prompts_anchored.json`、`_cast_issues.json` | script |
| 5 | dub | 配音规划 | `_dub.json` | - | script |
| 6 | bgm | 配乐音效 | `_bgm.json` | `bgm_cue.csv` | script |
| 7 | subtitle | 字幕生成 | `_subs.srt` / `_subtitle.json` | - | script |
| 8 | edit | 剪辑合成 | `_timeline.json` | `_manifest.csv` | gen、dub、bgm、subtitle |
| 9 | money | 变现节奏 | `_monetize.json` | `_pace.json` | script |
| 10 | comply | 合规预检 | `_comply.json` | `_comply_ir.json` | script |
| 11 | clip | 切片引流 | `_clip_plan.json` | `_clip_ir.json`、`clip_cut.csv` | script |
| 12 | publish | 上架发行 | `_publish_plan.json` | `_calendar.csv` | edit、comply |
| 13 | traffic | 引流投放 | `_traffic_plan.json` | - | publish |
| 14 | i18n | 出海本地化 | `_i18n_kit.json` | `_i18n_check.json` | script |
| 15 | insight | 数据复盘 | `_insight.json` | `_stats.json`、`_metrics.json` | publish |

## 状态判定规则

- `done`：任一 core 模式命中且文件存在。
- `partial`：core 未命中但 extra 命中（环节跑了一半）。
- `todo`：均未命中。
- `core_mtime`：命中的 core 产物中最新的修改时间，用于 K3 时序体检。
- 完成度 = (done + 0.5 × partial) / 15 × 100%。

## 扩展自定义环节

修改 `scripts/hub_scan.py` 顶部的 `STAGES` 注册表即可增删环节；`hub_check.py` 的 `NEXT_CMD` 与 `ORDER` 需同步维护。字段说明：

- `core` / `extra`：glob 模式列表，支持 `*` 前缀通配（如 `*_prompts_raw.json`）。
- `upstream`：上游环节 id 列表，用于断链（K2）与时序（K3）体检。
