#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""hub_report.py — 阿拉丁·AI短剧项目驾驶舱：生成自包含 HTML 驾驶舱 + Markdown 行动清单。

用法：
    python hub_report.py _hub_ir.json _hub_health.json [--out-html hub_board.html] [--out-md _hub_plan.md]

产出：
    hub_board.html  自包含驾驶舱（流水线地图 SVG + 完成度环 + 问题清单 + 下一步导航）
    _hub_plan.md    可直接贴给团队的行动清单
纯标准库、零依赖，HTML 不引用任何外链资源。
"""
import argparse
import html
import json
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

COLOR = {"done": "#22c55e", "partial": "#f59e0b", "todo": "#94a3b8"}
SEV_COLOR = {"P0": "#dc2626", "P1": "#f59e0b", "P2": "#3b82f6"}
ROWS = [  # 流水线地图布局：4 行（创作→制作→商业化→发行复盘）
    ["topic", "script", "gen", "cast"],
    ["dub", "bgm", "subtitle", "edit"],
    ["money", "comply", "clip"],
    ["publish", "traffic", "i18n", "insight"],
]


def esc(s):
    return html.escape(str(s if s is not None else ""))


def svg_pipeline(ir, health):
    sm = {s["id"]: s for s in ir["stages"]}
    bad = {i["stage"] for i in health["issues"] if i["sev"] in ("P0", "P1")}
    W, NH, NW, GX, GY = 860, 64, 190, 20, 26
    rows_h = len(ROWS) * (NH + GY) + 20
    parts = [f'<svg viewBox="0 0 {W} {rows_h}" xmlns="http://www.w3.org/2000/svg" '
             f'style="width:100%;max-width:{W}px">']
    for r, row in enumerate(ROWS):
        x0 = (W - len(row) * NW - (len(row) - 1) * GX) / 2
        y = 10 + r * (NH + GY)
        for c, sid in enumerate(row):
            s = sm[sid]
            x = x0 + c * (NW + GX)
            fill = COLOR[s["status"]]
            stroke = "#dc2626" if sid in bad else "#e2e8f0"
            sw = 3 if sid in bad else 1
            parts.append(
                f'<rect x="{x}" y="{y}" rx="10" width="{NW}" height="{NH}" '
                f'fill="{fill}18" stroke="{stroke}" stroke-width="{sw}"/>')
            parts.append(
                f'<circle cx="{x + 18}" cy="{y + 22}" r="7" fill="{fill}"/>')
            parts.append(
                f'<text x="{x + 32}" y="{y + 27}" font-size="15" font-weight="700" '
                f'fill="#0f172a">{esc(s["name"])}</text>')
            label = {"done": "已完成", "partial": "部分产出", "todo": "待办"}[s["status"]]
            n_art = len(s["artifacts"])
            parts.append(
                f'<text x="{x + 14}" y="{y + 50}" font-size="12" fill="#64748b">'
                f'{label} · 产物 {n_art} 个</text>')
            # 行内箭头
            if c < len(row) - 1:
                ax = x + NW
                parts.append(
                    f'<path d="M{ax + 3},{y + NH / 2} L{ax + GX - 3},{y + NH / 2}" '
                    f'stroke="#cbd5e1" stroke-width="2" marker-end="url(#arr)"/>')
        # 行间箭头（行尾折到下一行首）
        if r < len(ROWS) - 1:
            ymid = y + NH + GY / 2
            parts.append(
                f'<path d="M{W / 2},{y + NH + 2} L{W / 2},{ymid + GY / 2 - 2}" '
                f'stroke="#cbd5e1" stroke-width="2" stroke-dasharray="4 3" '
                f'marker-end="url(#arr)"/>')
    parts.insert(1, '<defs><marker id="arr" markerWidth="8" markerHeight="8" '
                    'refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 Z" '
                    'fill="#cbd5e1"/></marker></defs>')
    parts.append("</svg>")
    return "".join(parts)


def donut(pct, score, grade):
    r, cx = 52, 62
    circ = 2 * 3.14159 * r
    dash = circ * pct / 100.0
    color = "#22c55e" if pct >= 80 else "#f59e0b" if pct >= 40 else "#dc2626"
    return (f'<svg viewBox="0 0 124 124" width="124" height="124">'
            f'<circle cx="{cx}" cy="{cx}" r="{r}" fill="none" stroke="#e2e8f0" stroke-width="12"/>'
            f'<circle cx="{cx}" cy="{cx}" r="{r}" fill="none" stroke="{color}" stroke-width="12" '
            f'stroke-linecap="round" stroke-dasharray="{dash:.1f} {circ:.1f}" '
            f'transform="rotate(-90 {cx} {cx})"/>'
            f'<text x="{cx}" y="56" text-anchor="middle" font-size="26" font-weight="800" '
            f'fill="#0f172a">{pct:.0f}%</text>'
            f'<text x="{cx}" y="78" text-anchor="middle" font-size="13" '
            f'fill="#64748b">健康 {score} · {grade}</text></svg>')


def build_html(ir, health):
    v_color = {"READY": "#22c55e", "REVIEW": "#f59e0b", "BLOCK": "#dc2626"}[health["verdict"]]
    issue_rows = "".join(
        f'<tr><td><span class="sev" style="background:{SEV_COLOR[i["sev"]]}">{i["sev"]}</span></td>'
        f'<td>{esc(i["code"])}</td><td>{esc(i["msg"])}</td><td>{esc(i["advice"])}</td></tr>'
        for i in health["issues"]) or \
        '<tr><td colspan="4" style="color:#22c55e;font-weight:700">全链路无异常，闭环健康</td></tr>'
    act_rows = "".join(
        f'<li class="{"rdy" if a["ready"] else "wait"}"><b>{esc(a["name"])}</b>'
        f'<span class="tag">{"可执行" if a["ready"] else "等上游"}</span>'
        f'<div class="cmd">{esc(a["cmd"])}</div>'
        f'<div class="note">{esc(a["note"])}</div></li>'
        for a in health["next_actions"][:8]) or \
        '<li class="rdy"><b>15 环节全部完成</b><div class="note">项目已闭环，可进入下一部剧</div></li>'
    fixed = "".join(f'<div class="fixed">已自动适配：{esc(f)}</div>'
                    for f in health.get("fixed_files", []))
    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>阿拉丁·AI短剧项目驾驶舱</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:"Microsoft YaHei",system-ui,sans-serif;background:#f1f5f9;color:#0f172a;padding:24px}}
.wrap{{max-width:960px;margin:0 auto}}
h1{{font-size:22px;margin-bottom:4px}}
.sub{{color:#64748b;font-size:13px;margin-bottom:18px}}
.card{{background:#fff;border-radius:14px;padding:20px;margin-bottom:16px;box-shadow:0 1px 3px rgba(15,23,42,.08)}}
.top{{display:flex;gap:20px;align-items:center;flex-wrap:wrap}}
.kpis{{display:flex;gap:14px;flex-wrap:wrap;flex:1}}
.kpi{{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:10px 16px;min-width:110px}}
.kpi .v{{font-size:22px;font-weight:800}}
.kpi .k{{font-size:12px;color:#64748b}}
.verdict{{font-size:15px;font-weight:800;color:#fff;background:{v_color};border-radius:999px;padding:6px 18px}}
h2{{font-size:16px;margin-bottom:12px;border-left:4px solid #6366f1;padding-left:8px}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th,td{{padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:left;vertical-align:top}}
th{{background:#f8fafc;color:#475569}}
.sev{{color:#fff;font-weight:700;border-radius:6px;padding:2px 8px;font-size:12px}}
ul.acts{{list-style:none}}
ul.acts li{{border:1px solid #e2e8f0;border-radius:10px;padding:10px 14px;margin-bottom:8px}}
ul.acts li.rdy{{border-left:5px solid #22c55e}}
ul.acts li.wait{{border-left:5px solid #cbd5e1;opacity:.75}}
.tag{{font-size:11px;background:#eef2ff;color:#4338ca;border-radius:6px;padding:2px 8px;margin-left:8px}}
.cmd{{font-family:Consolas,monospace;font-size:12px;color:#334155;background:#f8fafc;border-radius:6px;padding:4px 8px;margin-top:6px}}
.note{{font-size:12px;color:#64748b;margin-top:4px}}
.fixed{{font-size:12px;color:#166534;background:#f0fdf4;border-radius:8px;padding:6px 10px;margin-top:8px}}
.legend{{font-size:12px;color:#64748b;margin-top:8px}}
.dot{{display:inline-block;width:10px;height:10px;border-radius:50%;margin:0 4px 0 12px}}
.foot{{text-align:center;color:#94a3b8;font-size:12px;margin-top:8px}}
</style></head><body><div class="wrap">
<h1>阿拉丁 · AI短剧项目驾驶舱</h1>
<div class="sub">项目：{esc(health["project_dir"])} ｜ 扫描时间：{esc(ir["scanned_at"])} ｜ 纯本地生成，数据不出本机</div>
<div class="card top">
  {donut(health["completion_pct"], health["health_score"], health["grade"])}
  <div class="kpis">
    <div class="kpi"><div class="v">{health["stage_done"]}/{health["stage_total"]}</div><div class="k">环节完成</div></div>
    <div class="kpi"><div class="v" style="color:#dc2626">{health["issue_p0"]}</div><div class="k">P0 阻断</div></div>
    <div class="kpi"><div class="v" style="color:#f59e0b">{health["issue_p1"]}</div><div class="k">P1 风险</div></div>
    <div class="kpi"><div class="v" style="color:#3b82f6">{health["issue_p2"]}</div><div class="k">P2 建议</div></div>
  </div>
  <div class="verdict">{esc(health["verdict"])}</div>
</div>
<div class="card"><h2>闭环流水线地图（15 环节）</h2>{svg_pipeline(ir, health)}
<div class="legend">状态：<span class="dot" style="background:#22c55e"></span>已完成
<span class="dot" style="background:#f59e0b"></span>部分产出
<span class="dot" style="background:#94a3b8"></span>待办
<span class="dot" style="background:#fff;border:2px solid #dc2626"></span>有 P0/P1 问题</div></div>
<div class="card"><h2>健康体检问题清单</h2>
<table><tr><th>级别</th><th>规则</th><th>问题</th><th>整改建议</th></tr>{issue_rows}</table>{fixed}</div>
<div class="card"><h2>下一步行动导航</h2><ul class="acts">{act_rows}</ul></div>
<div class="foot">阿拉丁 · AI 短剧创作闭环驾驶舱 ｜ 生成于 {esc(time.strftime("%Y-%m-%d %H:%M:%S"))}</div>
</div></body></html>"""


def build_md(ir, health):
    lines = ["# AI 短剧项目行动清单（阿拉丁·驾驶舱）", ""]
    lines.append(f"- 项目：`{health['project_dir']}`")
    lines.append(f"- 完成度：**{health['completion_pct']}%**"
                 f"（{health['stage_done']}/{health['stage_total']} 环节）")
    lines.append(f"- 健康分：**{health['health_score']}（{health['grade']} 级）** ｜ "
                 f"门禁：**{health['verdict']}**")
    lines.append("")
    lines.append("## 环节状态")
    lines.append("")
    lines.append("| 环节 | 状态 | 产物 |")
    lines.append("|------|------|------|")
    label = {"done": "✅ 已完成", "partial": "🟡 部分产出", "todo": "⬜ 待办"}
    for s in ir["stages"]:
        arts = "、".join(a["name"] for a in s["artifacts"]) or "-"
        lines.append(f"| {s['name']} | {label[s['status']]} | {arts} |")
    lines.append("")
    lines.append("## 问题清单")
    lines.append("")
    if health["issues"]:
        for i in health["issues"]:
            lines.append(f"- **[{i['sev']}] {i['code']}**（{i['stage']}）：{i['msg']}")
            lines.append(f"  - 整改：{i['advice']}")
    else:
        lines.append("- 全链路无异常，闭环健康。")
    lines.append("")
    lines.append("## 下一步行动（按闭环顺序）")
    lines.append("")
    for n, a in enumerate(health["next_actions"], 1):
        mark = "🟢 可执行" if a["ready"] else "⏸ 等上游"
        lines.append(f"{n}. {mark} **{a['name']}** — {a['cmd']}")
        if not a["ready"]:
            lines.append(f"   - {a['note']}")
    if not health["next_actions"]:
        lines.append("1. 🎉 15 环节全部完成，项目已闭环，可开新剧。")
    lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="生成 AI 短剧项目驾驶舱看板")
    ap.add_argument("ir", help="_hub_ir.json")
    ap.add_argument("health", help="_hub_health.json")
    ap.add_argument("--out-html", default="hub_board.html")
    ap.add_argument("--out-md", default="_hub_plan.md")
    args = ap.parse_args()

    ir = json.loads(Path(args.ir).read_text(encoding="utf-8-sig"))
    health = json.loads(Path(args.health).read_text(encoding="utf-8-sig"))

    Path(args.out_html).write_text(build_html(ir, health), encoding="utf-8")
    Path(args.out_md).write_text(build_md(ir, health), encoding="utf-8")
    print(f"[OK] 驾驶舱看板：{args.out_html}")
    print(f"[OK] 行动清单：{args.out_md}")


if __name__ == "__main__":
    main()
