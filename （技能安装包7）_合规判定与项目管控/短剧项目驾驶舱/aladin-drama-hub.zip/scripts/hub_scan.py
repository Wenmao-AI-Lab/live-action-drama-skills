#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""hub_scan.py — 阿拉丁·AI短剧项目驾驶舱：扫描项目目录，盘点全链路 15 环节产物契约。

用法：
    python hub_scan.py <项目目录> [--out _hub_ir.json]

输出 _hub_ir.json：每个环节的 状态(done/partial/todo)、命中产物、mtime、大小、JSON 可解析性。
纯标准库、零依赖、只读扫描（不修改任何项目文件）。
"""
import argparse
import json
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ---------------------------------------------------------------------------
# 环节注册表：阿拉丁 AI 短剧创作闭环 15 环节
# core = 判定该环节 done 的核心产物；extra = 加分产物（命中记 partial 起步）
# upstream = 上游环节 id（用于断链/时序体检）
# ---------------------------------------------------------------------------
STAGES = [
    {"id": "topic",    "name": "选题策划",   "skill": "aladin-drama-topic",
     "core": ["_topics.json"], "extra": ["_research.json"], "upstream": []},
    {"id": "script",   "name": "剧本创作",   "skill": "aladin-drama-script",
     "core": ["_script.json"], "extra": ["_shots.json"], "upstream": ["topic"]},
    {"id": "gen",      "name": "AI视频生成", "skill": "aladin-drama-gen",
     "core": ["_prompts.json", "*_prompts_raw.json"], "extra": ["_plan.json"],
     "upstream": ["script"]},
    {"id": "cast",     "name": "角色一致性", "skill": "aladin-drama-cast",
     "core": ["_cast.json"], "extra": ["_prompts_anchored.json", "_cast_issues.json"],
     "upstream": ["script"]},
    {"id": "dub",      "name": "配音规划",   "skill": "aladin-drama-dub",
     "core": ["_dub.json"], "extra": [], "upstream": ["script"]},
    {"id": "bgm",      "name": "配乐音效",   "skill": "aladin-drama-bgm",
     "core": ["_bgm.json"], "extra": ["bgm_cue.csv"], "upstream": ["script"]},
    {"id": "subtitle", "name": "字幕生成",   "skill": "aladin-drama-subtitle",
     "core": ["_subs.srt", "_subtitle.json"], "extra": [], "upstream": ["script"]},
    {"id": "edit",     "name": "剪辑合成",   "skill": "aladin-drama-edit",
     "core": ["_timeline.json"], "extra": ["_manifest.csv"],
     "upstream": ["gen", "dub", "bgm", "subtitle"]},
    {"id": "money",    "name": "变现节奏",   "skill": "aladin-drama-money",
     "core": ["_monetize.json"], "extra": ["_pace.json"], "upstream": ["script"]},
    {"id": "comply",   "name": "合规预检",   "skill": "aladin-drama-comply",
     "core": ["_comply.json"], "extra": ["_comply_ir.json"], "upstream": ["script"]},
    {"id": "clip",     "name": "切片引流",   "skill": "aladin-drama-clip",
     "core": ["_clip_plan.json"], "extra": ["_clip_ir.json", "clip_cut.csv"],
     "upstream": ["script"]},
    {"id": "publish",  "name": "上架发行",   "skill": "aladin-drama-publish",
     "core": ["_publish_plan.json"], "extra": ["_calendar.csv"],
     "upstream": ["edit", "comply"]},
    {"id": "traffic",  "name": "引流投放",   "skill": "aladin-drama-traffic",
     "core": ["_traffic_plan.json"], "extra": [], "upstream": ["publish"]},
    {"id": "i18n",     "name": "出海本地化", "skill": "aladin-drama-i18n",
     "core": ["_i18n_kit.json"], "extra": ["_i18n_check.json"], "upstream": ["script"]},
    {"id": "insight",  "name": "数据复盘",   "skill": "aladin-drama-insight",
     "core": ["_insight.json"], "extra": ["_stats.json", "_metrics.json"],
     "upstream": ["publish"]},
]


def find_artifacts(root: Path, patterns):
    """按模式在项目目录(仅一层+常见子目录)找产物，返回 [(pattern, Path)]。"""
    hits = []
    search_dirs = [root]
    for sub in ("build", "out", "dist", "artifacts"):
        d = root / sub
        if d.is_dir():
            search_dirs.append(d)
    for pat in patterns:
        for d in search_dirs:
            for p in sorted(d.glob(pat)):
                if p.is_file():
                    hits.append((pat, p))
    return hits


def probe_file(p: Path):
    """探测单个产物：大小/mtime/JSON 可解析性。"""
    info = {
        "path": str(p),
        "name": p.name,
        "size": p.stat().st_size,
        "mtime": int(p.stat().st_mtime),
        "mtime_str": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(p.stat().st_mtime)),
        "json_ok": None,
    }
    if p.suffix.lower() == ".json":
        try:
            json.loads(p.read_text(encoding="utf-8-sig"))
            info["json_ok"] = True
        except Exception as e:
            info["json_ok"] = False
            info["json_error"] = str(e)[:200]
    return info


def scan(root: Path):
    stages_out = []
    for st in STAGES:
        core_hits = find_artifacts(root, st["core"])
        extra_hits = find_artifacts(root, st["extra"])
        artifacts = [probe_file(p) for _, p in core_hits] + \
                    [probe_file(p) for _, p in extra_hits]
        # 去重（同一文件可能被多个模式命中）
        seen, uniq = set(), []
        for a in artifacts:
            if a["path"] not in seen:
                seen.add(a["path"])
                uniq.append(a)
        if core_hits:
            status = "done"
        elif extra_hits:
            status = "partial"
        else:
            status = "todo"
        core_mtime = max((probe_file(p)["mtime"] for _, p in core_hits), default=None)
        stages_out.append({
            "id": st["id"], "name": st["name"], "skill": st["skill"],
            "upstream": st["upstream"], "status": status,
            "core_patterns": st["core"], "core_mtime": core_mtime,
            "artifacts": uniq,
        })
    done = sum(1 for s in stages_out if s["status"] == "done")
    partial = sum(1 for s in stages_out if s["status"] == "partial")
    return {
        "hub_version": "1.0.0",
        "scanned_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "project_dir": str(root),
        "stage_total": len(stages_out),
        "stage_done": done,
        "stage_partial": partial,
        "stage_todo": len(stages_out) - done - partial,
        "completion_pct": round(100.0 * (done + 0.5 * partial) / len(stages_out), 1),
        "stages": stages_out,
    }


def main():
    ap = argparse.ArgumentParser(description="扫描 AI 短剧项目目录，盘点 15 环节产物")
    ap.add_argument("project", help="项目目录（存放 _script.json 等契约产物）")
    ap.add_argument("--out", default="_hub_ir.json", help="输出盘点 IR 路径")
    args = ap.parse_args()

    root = Path(args.project)
    if not root.is_dir():
        print(f"[ERR] 项目目录不存在：{root}")
        sys.exit(1)

    ir = scan(root)
    Path(args.out).write_text(
        json.dumps(ir, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] 扫描完成：{ir['stage_done']} done / {ir['stage_partial']} partial / "
          f"{ir['stage_todo']} todo，完成度 {ir['completion_pct']}%")
    print(f"[OK] 盘点 IR 已写出：{args.out}")


if __name__ == "__main__":
    main()
