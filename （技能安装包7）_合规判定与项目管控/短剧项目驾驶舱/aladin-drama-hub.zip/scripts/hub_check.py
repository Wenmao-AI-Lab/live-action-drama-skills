#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""hub_check.py — 阿拉丁·AI短剧项目驾驶舱：全链路健康体检 + 契约适配修复。

用法：
    python hub_check.py _hub_ir.json [--fix] [--out _hub_health.json]

五类确定性体检（可复算）：
    K1 契约体检  产物 JSON 损坏 / _script.json 新旧契约识别（旧契约直串 gen 会 crash）
    K2 断链体检  下游环节已产出但上游核心产物缺失
    K3 时序体检  下游产物比上游更旧（上游改了、下游没重跑）
    K4 一致性    集数跨产物对齐 / 付费墙越界 / 合规 BLOCK 却已出发行计划 / 角色未建卡
    K5 导航      上游就绪、本环节待办 → 生成下一步行动清单（按闭环顺序）

--fix 仅做一件确定性修复：旧契约 _script.json → 另存 _script_genready.json
（project 字符串→对象、characters 字符串→列表；不改动原文件）。
纯标准库、零依赖。
"""
import argparse
import json
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

SEV_SCORE = {"P0": 25, "P1": 10, "P2": 3}

# 各环节推荐的下一步命令（导航用）
NEXT_CMD = {
    "topic":    "aladin-drama-topic：topic_research.py → topic_generate.py 产出 _topics.json",
    "script":   "aladin-drama-script：script_outline.py → script_shots.py 产出 _script.json",
    "gen":      "aladin-drama-gen：gen_plan.py → gen_prompts.py 产出分镜提示词 _prompts*.json",
    "cast":     "aladin-drama-cast：cast_build.py 建角色卡 → cast_anchor.py 锚定提示词防变脸",
    "dub":      "aladin-drama-dub：dub_cast.py → dub_plan.py 产出 _dub.json 配音方案",
    "bgm":      "aladin-drama-bgm：bgm_plan.py 产出 _bgm.json 配乐音效方案",
    "subtitle": "aladin-drama-subtitle：sub_gen.py 产出 _subs.srt 字幕",
    "edit":     "aladin-drama-edit：edit_timeline.py → edit_ffmpeg.py 产出 _timeline.json 剪辑时间线",
    "money":    "aladin-drama-money：money_ingest.py → money_plan.py 产出 _monetize.json 付费卡点",
    "comply":   "aladin-drama-comply：comply_ingest.py → comply_scan.py 产出 _comply.json 合规门禁",
    "clip":     "aladin-drama-clip：clip_ingest.py → clip_plan.py 产出 _clip_plan.json 切片方案",
    "publish":  "aladin-drama-publish：pub_plan.py 产出 _publish_plan.json 上架计划",
    "traffic":  "aladin-drama-traffic：traffic_plan.py 产出 _traffic_plan.json 引流方案",
    "i18n":     "aladin-drama-i18n：i18n_extract.py 产出 _i18n_kit.json 出海工单",
    "insight":  "aladin-drama-insight：insight_ingest.py → insight_analyze.py 复盘回灌选题",
}

ORDER = ["topic", "script", "gen", "cast", "dub", "bgm", "subtitle", "edit",
         "money", "comply", "clip", "publish", "traffic", "i18n", "insight"]


def load_json_safe(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except Exception:
        return None


def stage_map(ir):
    return {s["id"]: s for s in ir["stages"]}


def core_file(stage):
    """取环节命中的第一个核心产物路径。"""
    pats = stage["core_patterns"]
    for a in stage["artifacts"]:
        for pat in pats:
            if pat.startswith("*"):
                if a["name"].endswith(pat[1:]):
                    return a
            elif a["name"] == pat:
                return a
    return None


# ---------------------------------------------------------------------------
# K1 契约体检
# ---------------------------------------------------------------------------
def check_contracts(ir, issues, fix, out_dir):
    fixed = []
    for s in ir["stages"]:
        for a in s["artifacts"]:
            if a.get("json_ok") is False:
                issues.append({
                    "code": "K1-JSON-BROKEN", "sev": "P0", "stage": s["id"],
                    "msg": f"{a['name']} JSON 损坏无法解析：{a.get('json_error', '')}",
                    "advice": f"重跑 {s['skill']} 重新生成该产物",
                })
    # _script.json 新旧契约识别（旧契约: project 为字符串 → 直串 drama-gen 会 crash）
    sm = stage_map(ir)
    sc = core_file(sm["script"]) if sm["script"]["status"] == "done" else None
    if sc:
        data = load_json_safe(sc["path"])
        if isinstance(data, dict):
            legacy = []
            if isinstance(data.get("project"), str):
                legacy.append("project 为字符串（gen 期望对象 {title,style}）")
            eps = data.get("episodes") or []
            for ep in eps if isinstance(eps, list) else []:
                for sc_ in (ep.get("scenes") or []) if isinstance(ep, dict) else []:
                    for sh in (sc_.get("shots") or []) if isinstance(sc_, dict) else []:
                        if isinstance(sh, dict) and isinstance(sh.get("character"), str):
                            legacy.append("shot.character 为字符串（gen 期望列表）")
                            break
                    else:
                        continue
                    break
                else:
                    continue
                break
            if legacy:
                issue = {
                    "code": "K1-SCRIPT-LEGACY", "sev": "P1", "stage": "script",
                    "msg": "旧契约 _script.json：" + "；".join(legacy) +
                           "。直接输入 aladin-drama-gen 会报 'str' object has no attribute 'get'",
                    "advice": "用 --fix 生成 _script_genready.json 后再喂 gen",
                }
                if fix:
                    outp = Path(out_dir) / "_script_genready.json"
                    adapted = adapt_script(data)
                    outp.write_text(json.dumps(adapted, ensure_ascii=False, indent=2),
                                    encoding="utf-8")
                    issue["fixed"] = str(outp)
                    issue["advice"] = f"已自动适配 → {outp.name}（原文件未改动），gen 请改用该文件"
                    fixed.append(str(outp))
                issues.append(issue)
    return fixed


def adapt_script(data):
    """旧契约 → gen 可用契约（确定性转换，不臆造内容）。"""
    out = json.loads(json.dumps(data, ensure_ascii=False))  # 深拷贝
    if isinstance(out.get("project"), str):
        out["project"] = {
            "title": out["project"],
            "style": out.get("genre") or out.get("tone") or "现代都市短剧",
        }
    for ep in out.get("episodes") or []:
        if not isinstance(ep, dict):
            continue
        for sc_ in ep.get("scenes") or []:
            if not isinstance(sc_, dict):
                continue
            for sh in sc_.get("shots") or []:
                if isinstance(sh, dict) and isinstance(sh.get("character"), str):
                    sh["character"] = [c.strip() for c in
                                       sh["character"].replace("、", ",").split(",")
                                       if c.strip()]
    return out


# ---------------------------------------------------------------------------
# K2 断链 + K3 时序
# ---------------------------------------------------------------------------
def check_chain(ir, issues):
    sm = stage_map(ir)
    for s in ir["stages"]:
        if s["status"] != "done":
            continue
        for up in s["upstream"]:
            u = sm[up]
            if u["status"] != "done":
                issues.append({
                    "code": "K2-BROKEN-CHAIN", "sev": "P1", "stage": s["id"],
                    "msg": f"「{s['name']}」已产出，但上游「{u['name']}」核心产物缺失，"
                           f"产物来源不可追溯、无法复算",
                    "advice": f"补跑 {u['skill']}（{NEXT_CMD[up]}）",
                })
            elif s["core_mtime"] and u["core_mtime"] and s["core_mtime"] < u["core_mtime"]:
                issues.append({
                    "code": "K3-STALE", "sev": "P1", "stage": s["id"],
                    "msg": f"「{u['name']}」产物比「{s['name']}」更新——上游改了、下游没重跑，"
                           f"产物可能已过期",
                    "advice": f"重跑 {s['skill']} 刷新产物",
                })


# ---------------------------------------------------------------------------
# K4 一致性（跨产物字段级）
# ---------------------------------------------------------------------------
def _episode_count(data):
    if isinstance(data, dict):
        eps = data.get("episodes")
        if isinstance(eps, list) and eps:
            return len(eps)
    return None


def check_consistency(ir, issues):
    sm = stage_map(ir)

    def core_data(sid):
        s = sm[sid]
        a = core_file(s)
        return load_json_safe(a["path"]) if a else None

    script = core_data("script")
    n_script = _episode_count(script)

    # 集数对齐：dub / bgm / monetize / i18n 若声明集数应与剧本一致
    if n_script:
        for sid in ("dub", "bgm", "money", "i18n"):
            d = core_data(sid)
            n = _episode_count(d)
            if n is None and isinstance(d, dict):
                n = d.get("episode_total") or d.get("total_episodes")
            if isinstance(n, int) and n != n_script:
                issues.append({
                    "code": "K4-EP-MISMATCH", "sev": "P1", "stage": sid,
                    "msg": f"「{sm[sid]['name']}」按 {n} 集产出，剧本实际 {n_script} 集，"
                           f"集数不对齐",
                    "advice": f"以 _script.json 为准重跑 {sm[sid]['skill']}",
                })

    # 付费墙越界
    money = core_data("money")
    if isinstance(money, dict) and n_script:
        pw = money.get("paywall_episode") or (money.get("paywall") or {}).get("episode") \
            if isinstance(money.get("paywall"), dict) else money.get("paywall_episode")
        if isinstance(pw, int) and not (1 <= pw <= n_script):
            issues.append({
                "code": "K4-PAYWALL-RANGE", "sev": "P0", "stage": "money",
                "msg": f"付费墙设在第 {pw} 集，但剧本只有 {n_script} 集，上架会配置失败",
                "advice": "重跑 aladin-drama-money 重新定位付费墙",
            })

    # 合规门禁 BLOCK 却已出发行计划
    comply = core_data("comply")
    if isinstance(comply, dict):
        verdict = str(comply.get("verdict") or comply.get("gate") or
                      (comply.get("summary") or {}).get("verdict") or "").upper()
        if "BLOCK" in verdict and sm["publish"]["status"] == "done":
            issues.append({
                "code": "K4-GATE-BLOCK", "sev": "P0", "stage": "publish",
                "msg": "合规预检门禁为 BLOCK，但发行计划已生成——带病上架有下架/限流风险",
                "advice": "先按 _comply_fix.md 整改并复检为 READY，再重跑 publish",
            })

    # 已出分镜提示词但未建角色卡（跨镜头变脸风险）
    if sm["gen"]["status"] == "done" and sm["cast"]["status"] == "todo":
        issues.append({
            "code": "K4-NO-CAST", "sev": "P2", "stage": "cast",
            "msg": "已生成分镜提示词但未建角色一致性锚——多镜头/多集易变脸",
            "advice": "跑 aladin-drama-cast 建角色卡并锚定提示词",
        })

    # 已上架但未做合规预检
    if sm["publish"]["status"] == "done" and sm["comply"]["status"] == "todo":
        issues.append({
            "code": "K4-NO-COMPLY", "sev": "P1", "stage": "comply",
            "msg": "发行计划已生成但未做合规预检——违禁词/AIGC标识/备案未把关",
            "advice": "补跑 aladin-drama-comply 过一遍门禁",
        })


# ---------------------------------------------------------------------------
# K5 导航
# ---------------------------------------------------------------------------
def next_actions(ir):
    sm = stage_map(ir)
    acts = []
    for sid in ORDER:
        s = sm[sid]
        if s["status"] == "done":
            continue
        ready = all(sm[u]["status"] == "done" for u in s["upstream"])
        acts.append({
            "stage": sid, "name": s["name"], "skill": s["skill"],
            "ready": ready,
            "cmd": NEXT_CMD[sid],
            "note": "上游已就绪，可立即执行" if ready else
                    "等待上游：" + "、".join(sm[u]["name"] for u in s["upstream"]
                                              if sm[u]["status"] != "done"),
        })
    # 就绪的排前面，保持闭环顺序
    return sorted(acts, key=lambda a: (not a["ready"], ORDER.index(a["stage"])))


def main():
    ap = argparse.ArgumentParser(description="AI 短剧项目全链路健康体检")
    ap.add_argument("ir", help="hub_scan.py 产出的 _hub_ir.json")
    ap.add_argument("--fix", action="store_true",
                    help="对旧契约 _script.json 自动生成 _script_genready.json")
    ap.add_argument("--out", default="_hub_health.json")
    args = ap.parse_args()

    ir = load_json_safe(args.ir)
    if not ir:
        print(f"[ERR] 无法读取 {args.ir}，请先运行 hub_scan.py")
        sys.exit(1)

    issues = []
    fixed = check_contracts(ir, issues, args.fix, ir["project_dir"])
    check_chain(ir, issues)
    check_consistency(ir, issues)
    acts = next_actions(ir)

    score = 100
    for i in issues:
        score -= SEV_SCORE.get(i["sev"], 0)
    score = max(0, score)
    grade = "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D"
    p0 = sum(1 for i in issues if i["sev"] == "P0")
    verdict = "BLOCK" if p0 else ("REVIEW" if issues else "READY")

    health = {
        "hub_version": "1.0.0",
        "project_dir": ir["project_dir"],
        "completion_pct": ir["completion_pct"],
        "stage_done": ir["stage_done"], "stage_total": ir["stage_total"],
        "health_score": score, "grade": grade, "verdict": verdict,
        "issue_total": len(issues),
        "issue_p0": p0,
        "issue_p1": sum(1 for i in issues if i["sev"] == "P1"),
        "issue_p2": sum(1 for i in issues if i["sev"] == "P2"),
        "issues": issues,
        "fixed_files": fixed,
        "next_actions": acts,
        "feedback": {  # 回灌契约：可喂 topic/insight 联动
            "completion_pct": ir["completion_pct"],
            "blocking_stages": [i["stage"] for i in issues if i["sev"] == "P0"],
            "next_stage": acts[0]["stage"] if acts else None,
        },
    }
    Path(args.out).write_text(json.dumps(health, ensure_ascii=False, indent=2),
                              encoding="utf-8")
    print(f"[OK] 体检完成：{score} 分（{grade} 级 / {verdict}），"
          f"问题 P0={health['issue_p0']} P1={health['issue_p1']} P2={health['issue_p2']}")
    if fixed:
        print(f"[FIX] 已生成契约适配文件：{', '.join(fixed)}")
    if acts:
        head = acts[0]
        print(f"[NEXT] 下一步：{head['name']} → {head['cmd']}")
    print(f"[OK] 健康报告已写出：{args.out}")


if __name__ == "__main__":
    main()
