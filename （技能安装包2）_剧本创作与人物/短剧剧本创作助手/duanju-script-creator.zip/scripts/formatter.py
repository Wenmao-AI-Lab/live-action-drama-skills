# -*- coding: utf-8 -*-
"""格式化与导出：把 state + output 下的剧本渲染为多格式交付包。

支持的导出格式（cli: export --format <fmt>）：
  full       交付总包（总览+人物表+故事核+大纲+正文+场景/道具清单）
  script_only/plain  纯文字剧本（平台备案/投稿，去掉镜头指示）
  storyboard 分镜脚本表格（导演/拍摄用）
  actor      角色分词本（演员用）
  aivideo    AI 视频生成 Prompt 化描述
  episodes   按集拆成独立文件
"""
import json
import os
import re
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(ROOT, "output")


# ── 基础 IO ─────────────────────────────────────────────
def _read_episode(ep):
    p = os.path.join(OUTPUT_DIR, "episode_%s.txt" % ep)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return f.read()
    return ""


def _all_episodes(state):
    """直接扫描 output/ 下的 episode_*.txt（不依赖 state 的 keys，回退后更鲁棒）。"""
    texts = {}
    if not os.path.exists(OUTPUT_DIR):
        return texts
    for fn in sorted(os.listdir(OUTPUT_DIR)):
        if fn.startswith("episode_") and fn.endswith(".txt"):
            ep = fn[len("episode_"):-len(".txt")]
            try:
                int(ep)
            except ValueError:
                continue
            t = _read_episode(ep)
            if t:
                texts[ep] = t
    return texts


# ── 文档块：项目总览 / 人物设定表 ───────────────────────
def build_overview(state):
    meta = state.get("meta", {})
    cfg = state.get("config", {})
    brief = state.get("user_brief") or state.get("trend_brief") or {}
    lines = ["# 项目总览（Project Overview）", ""]
    lines.append("- 项目名称：%s" % meta.get("project_name", "未命名项目"))
    lines.append("- 赛道：%s" % cfg.get("genre", ""))
    lines.append("- 平台：%s" % cfg.get("platform", ""))
    lines.append("- 总集数：%s" % cfg.get("episodes", ""))
    lines.append("- 单集时长：约 %s 秒" % cfg.get("duration", ""))
    lines.append("- 基调：%s" % cfg.get("tone", ""))
    lines.append("- 创建时间：%s" % meta.get("created", ""))
    if brief:
        lines.append("")
        lines.append("## 爆款热点依据")
        lines.append("- 热门话题：%s" % brief.get("hot_topics", "（无）"))
        lines.append("- 推荐钩子：%s" % brief.get("recommended_hooks", "（无）"))
        vs = brief.get("viral_structures")
        if vs:
            lines.append("- 爆款结构：%s" % vs)
    return "\n".join(lines)


def build_character_bible(state):
    core = state.get("story_core") or {}
    chars = core.get("characters", [])
    lines = ["# 人物设定表（Character Bible）", ""]
    if not chars:
        lines.append("（未定义人物）")
        return "\n".join(lines)
    for c in chars:
        if not isinstance(c, dict):
            continue
        lines.append("## %s" % c.get("name", "?"))
        lines.append("- 年龄：%s" % c.get("age", ""))
        lines.append("- 身份：%s" % c.get("identity", ""))
        pers = c.get("personality", "")
        if isinstance(pers, list):
            pers = "、".join(pers)
        lines.append("- 性格：%s" % pers)
        lines.append("- 欲望：%s" % c.get("desire", ""))
        lines.append("- 弱点：%s" % c.get("flaw", ""))
        lines.append("- 弧光：%s" % c.get("arc", ""))
        lines.append("- 语言风格：%s" % c.get("speech_style", ""))
        rel = c.get("relationships", {})
        if rel:
            lines.append("- 关系：")
            for k, v in rel.items():
                lines.append("  - %s：%s" % (k, v))
        lines.append("")
    return "\n".join(lines)


# ── 表格解析与聚合（场景清单 / 道具服装清单） ───────────
def _extract_section(text, header):
    m = re.search(r"【%s】\s*\n(.*?)(?=\n【|$)" % re.escape(header), text, re.S)
    return m.group(1) if m else ""


def _parse_table(block):
    rows = []
    lines = [l.strip() for l in block.strip().splitlines() if l.strip().startswith("|")]
    if not lines:
        return rows

    def split_row(l):
        return [p.strip() for p in l.strip().strip("|").split("|")]

    header = split_row(lines[0])
    for l in lines[1:]:
        cells = split_row(l)
        if set("".join(cells)) <= set("-: "):  # 分隔行
            continue
        rows.append({header[i]: (cells[i] if i < len(cells) else "") for i in range(len(header))})
    return rows


def aggregate_scene_list(state, episodes):
    out = []
    for ep, text in episodes.items():
        for r in _parse_table(_extract_section(text, "场景清单")):
            r = dict(r)
            r["集数"] = ep
            out.append(r)
    return out


def aggregate_prop_list(state, episodes):
    out = []
    for ep, text in episodes.items():
        for r in _parse_table(_extract_section(text, "道具服装清单")):
            r = dict(r)
            r["集数"] = ep
            out.append(r)
    return out


def _render_table(rows, cols):
    if not rows:
        return "（无数据）"
    out = ["| " + " | ".join(cols) + " |",
           "| " + " | ".join("---" for _ in cols) + " |"]
    for r in rows:
        out.append("| " + " | ".join(str(r.get(c, "")) for c in cols) + " |")
    return "\n".join(out)


def _is_table_row(line):
    return line.strip().startswith("|")


# ── 各格式构建器 ───────────────────────────────────────
def build_full(state):
    name = state.get("meta", {}).get("project_name", "未命名项目")
    lines = ["# 《%s》剧本交付总包\n" % name]
    lines.append(build_overview(state) + "\n")
    lines.append("## 一、人物设定表\n" + build_character_bible(state) + "\n")
    if state.get("story_core"):
        lines.append("## 二、故事核\n```json\n" +
                     json.dumps(state["story_core"], ensure_ascii=False, indent=2) + "\n```\n")
    if state.get("outline"):
        lines.append("## 三、分集大纲\n```json\n" +
                     json.dumps(state["outline"], ensure_ascii=False, indent=2) + "\n```\n")
    eps = _all_episodes(state)
    if eps:
        lines.append("## 四、剧本正文\n")
        for ep in sorted(eps.keys(), key=lambda x: int(x)):
            lines.append("\n---\n\n" + eps[ep])
    lines.append("\n## 五、附录：场景清单\n" +
                 _render_table(aggregate_scene_list(state, eps),
                               ["集数", "场景号", "内/外", "地点", "时间", "出场人物", "预估时长", "备注"]) + "\n")
    lines.append("\n## 六、附录：道具/服装清单\n" +
                 _render_table(aggregate_prop_list(state, eps),
                               ["集数", "物品", "所属场景", "说明"]) + "\n")
    return "\n".join(lines)


_MARKER_RE = re.compile(r"^【(镜头|BGM|音效|字幕|特效|转场)】")


def _strip_markers(text):
    """平台备案/投稿纯文字：去掉镜头/音效/字幕等指示与附录表，保留场景+对白。"""
    out, skip = [], False
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("【场景清单】") or s.startswith("【道具服装清单】"):
            skip = True
            continue
        if skip:
            if s.startswith("|") or s == "":
                continue
            skip = False  # 表格后的首行结束跳过区
        if _MARKER_RE.match(s):
            continue
        out.append(line)
    return "\n".join(out)


def build_script_only(state):
    name = state.get("meta", {}).get("project_name", "未命名项目")
    lines = ["# 《%s》纯文字剧本（平台备案/投稿版）\n" % name]
    eps = _all_episodes(state)
    for ep in sorted(eps.keys(), key=lambda x: int(x)):
        lines.append("\n---\n\n" + _strip_markers(eps[ep]))
    return "\n".join(lines)


_SCENE_RE = re.compile(r"^【场景(\d+)】(.*)$")
_DIALOGUE_RE = re.compile(r"^(.+?)[(（].*?[)）]\s*[：:](.+)$")


def build_storyboard(state):
    name = state.get("meta", {}).get("project_name", "未命名项目")
    lines = ["# 《%s》分镜脚本（导演/拍摄用）\n" % name,
             "| 镜号 | 景别 | 运镜 | 画面内容 | 台词/音效 | 时长 |",
             "| --- | --- | --- | --- | --- | --- |"]
    shot = 0
    for ep, text in sorted(_all_episodes(state).items(), key=lambda x: int(x[0])):
        cur = ""
        for line in text.splitlines():
            s = line.strip()
            m = _SCENE_RE.match(s)
            if m:
                cur = "场景%s %s" % (m.group(1), m.group(2))
                continue
            if s.startswith("【镜头】"):
                shot += 1
                lines.append("| %d | %s | - | %s | | |" % (shot, s[4:].strip(), cur))
            elif s.startswith("【转场】"):
                shot += 1
                lines.append("| %d | - | - | %s | 转场：%s | |" % (shot, cur, s[4:].strip()))
            elif s.startswith("【") and _MARKER_RE.match(s):
                shot += 1
                kind = s.split("】")[0].strip("【")
                content = s.split("】", 1)[1].strip()
                lines.append("| %d | - | - | %s | %s：%s | |" % (shot, cur, kind, content))
            elif s.startswith("△"):
                shot += 1
                lines.append("| %d | - | - | %s | | |" % (shot, s[1:].strip()))
            elif _DIALOGUE_RE.match(s):
                shot += 1
                d = _DIALOGUE_RE.match(s)
                lines.append("| %d | - | - | %s | %s：%s | |" %
                             (shot, cur, d.group(1).strip(), d.group(2).strip()))
    return "\n".join(lines)


def build_actor(state):
    name = state.get("meta", {}).get("project_name", "未命名项目")
    core = state.get("story_core") or {}
    chars = [c.get("name") for c in core.get("characters", []) if isinstance(c, dict)]
    lines = ["# 《%s》角色分词本（演员用）\n" % name]
    if not chars:
        lines.append("（未定义人物）")
        return "\n".join(lines)
    eps = _all_episodes(state)
    for ch in chars:
        lines.append("\n## %s\n" % ch)
        pat = re.compile(r"^%s(\s*[(（][^)）]*[)）])*\s*[：:]" % re.escape(ch))
        for ep in sorted(eps.keys(), key=lambda x: int(x)):
            collected = [s for s in eps[ep].splitlines() if pat.match(s.strip())]
            if collected:
                lines.append("### 第%s集" % ep)
                lines.extend(collected)
                lines.append("")
    return "\n".join(lines)


def build_aivideo(state):
    name = state.get("meta", {}).get("project_name", "未命名项目")
    lines = ["# 《%s》AI 视频生成 Prompt（每镜头画面描述）\n" % name]
    shot = 0
    for ep, text in sorted(_all_episodes(state).items(), key=lambda x: int(x[0])):
        cur = ""
        for line in text.splitlines():
            s = line.strip()
            m = _SCENE_RE.match(s)
            if m:
                cur = "场景%s %s" % (m.group(1), m.group(2))
                continue
            if s.startswith("△"):
                shot += 1
                lines.append("**镜头 %d（第%s集 · %s）**" % (shot, ep, cur))
                lines.append("画面提示词：%s，短剧写实风格，电影感打光，竖屏 9:16。" % s[1:].strip())
                lines.append("")
            elif s.startswith("【镜头】"):
                if lines and lines[-1].startswith("画面提示词"):
                    lines[-1] += " 镜头运动：%s。" % s[4:].strip()
    return "\n".join(lines)


def _export_episodes(state):
    eps = _all_episodes(state)
    paths = []
    for ep in sorted(eps.keys(), key=lambda x: int(x)):
        title = "第%s集" % ep
        m = re.search(r'^第%s集[：: ]*《?([^》\n]*)\s*$' % ep, eps[ep], re.M)
        if m and m.group(1).strip():
            title = "第%s集_%s" % (ep, m.group(1).strip())
        p = os.path.join(OUTPUT_DIR, "%s.md" % title)
        with open(p, "w", encoding="utf-8") as f:
            f.write(eps[ep])
        paths.append(p)
    return "; ".join(paths)


# ── 零依赖 .docx 生成（标准库 zipfile + OOXML） ────────
def _xml_escape(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def _docx_para(text, heading=0):
    ppr = ('<w:pPr><w:pStyle w:val="Heading%d"/></w:pPr>' % heading) if heading else ""
    return '<w:p>%s<w:r><w:t xml:space="preserve">%s</w:t></w:r></w:p>' % (
        ppr, _xml_escape(text))


def _docx_table_xml(rows):
    borders = "<w:tblBorders>" + "".join(
        '<w:%s w:val="single" w:sz="4" w:space="0" w:color="auto"/>' % e
        for e in ["top", "left", "bottom", "right", "insideH", "insideV"]
    ) + "</w:tblBorders>"
    out = []
    for r in rows:
        tcs = "".join(
            '<w:tc><w:p><w:r><w:t xml:space="preserve">%s</w:t></w:r></w:p></w:tc>'
            % _xml_escape(c) for c in r)
        out.append("<w:tr>%s</w:tr>" % tcs)
    return "<w:tbl><w:tblPr>%s</w:tblPr>%s</w:tbl>" % (borders, "".join(out))


def markdown_to_docx(path, md):
    """把轻量 markdown（# 标题 / | 表格 | / 普通段落）写为 .docx，零第三方依赖。"""
    lines = md.splitlines()
    body, i, n = [], 0, len(lines)
    while i < n:
        line = lines[i]
        s = line.strip()
        if s.startswith("═") or s.startswith("━") or s in ("", "```", "```json"):
            i += 1
            continue
        if _is_table_row(line):
            tlines = []
            while i < n and _is_table_row(lines[i]):
                tlines.append(lines[i])
                i += 1
            rows = []
            for tl in tlines:
                cells = [c.strip() for c in tl.strip().strip("|").split("|")]
                if set("".join(cells)) <= set("-: "):
                    continue
                rows.append(cells)
            if rows:
                body.append(_docx_table_xml(rows))
            continue
        m = re.match(r"^(#{1,3})\s+(.*)$", line)
        if m:
            body.append(_docx_para(m.group(2), heading=len(m.group(1))))
            i += 1
            continue
        body.append(_docx_para(line))
        i += 1
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body>%s'
        '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>'
        '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
        'w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>'
        '</w:body></w:document>' % "".join(body)
    )
    _write_docx_package(path, document)


def _write_docx_package(path, document_xml):
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="word/document.xml"/></Relationships>'
    )
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document_xml)


def _export_episodes_docx(state):
    eps = _all_episodes(state)
    paths = []
    for ep in sorted(eps.keys(), key=lambda x: int(x)):
        title = "第%s集" % ep
        m = re.search(r'^第%s集[：: ]*《?([^》\n]*)\s*$' % ep, eps[ep], re.M)
        if m and m.group(1).strip():
            title = "第%s集_%s" % (ep, m.group(1).strip())
        p = os.path.join(OUTPUT_DIR, "%s.docx" % title)
        markdown_to_docx(p, eps[ep])
        paths.append(p)
    return "; ".join(paths)


def _export_full_docx(state):
    p = os.path.join(OUTPUT_DIR, "EXPORT_full.docx")
    markdown_to_docx(p, build_full(state))
    return p


# ── 导出入口 ───────────────────────────────────────────
def export(state, fmt):
    if fmt == "episodes":
        return _export_episodes(state)
    if fmt == "episodes_docx":
        return _export_episodes_docx(state)
    if fmt == "docx":
        return _export_full_docx(state)
    builders = {
        "full": build_full,
        "script_only": build_script_only,
        "plain": build_script_only,
        "storyboard": build_storyboard,
        "actor": build_actor,
        "aivideo": build_aivideo,
    }
    content = builders.get(fmt, build_full)(state)
    out_path = os.path.join(OUTPUT_DIR, "EXPORT_%s.md" % fmt)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)
    return out_path
