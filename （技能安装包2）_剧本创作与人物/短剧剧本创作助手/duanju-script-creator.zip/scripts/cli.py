# -*- coding: utf-8 -*-
"""短剧剧本创作 Skill 统一入口。
LLM 负责创作，脚本负责状态机 / IO / 确定性校验 / 格式化。
用法：python cli.py <command> [args]
"""
import argparse
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_DIR = os.path.join(ROOT, "state")
STATE_FILE = os.path.join(STATE_DIR, "story_state.json")
OUTPUT_DIR = os.path.join(ROOT, "output")
PROMPTS_DIR = os.path.join(ROOT, "prompts")
GENRES_FILE = os.path.join(ROOT, "config", "genres.json")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from state_manager import (read_state, write_state, advance, rollback,  # noqa: E402
                            active_brief, state_lock)
from formatter import export as export_pack, _all_episodes  # noqa: E402
from trend_fetcher import build_trend_prompt, parse_brief  # noqa: E402
from knowledge_base import lookup as kb_lookup  # noqa: E402


def _read_prompt(name):
    with open(os.path.join(PROMPTS_DIR, name), "r", encoding="utf-8") as f:
        return f.read()


def _fill(tpl, **vars):
    """单次正则替换，避免变量值内若含 {其他变量} 被二次展开。"""
    if not vars:
        return tpl
    pattern = re.compile(r"\{(" + "|".join(re.escape(k) for k in vars) + r")\}")
    return pattern.sub(lambda m: str(vars[m.group(1)]), tpl)


def _json_str(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2)


def _brief_val(brief, key, default="（未提供）"):
    """从 brief 取字段，空值统一兜底，避免 prompt 出现字面 [] / {}。"""
    v = brief.get(key) if isinstance(brief, dict) else None
    if not v:
        return default
    if isinstance(v, list):
        return "、".join(str(x) for x in v) if v else default
    if isinstance(v, dict):
        return "、".join("%s：%s" % (k, val) for k, val in v.items()) if v else default
    return str(v)


def _load_genres():
    if os.path.exists(GENRES_FILE):
        try:
            with open(GENRES_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _speech_style(state):
    chars = (state.get("story_core") or {}).get("characters", [])
    lines = []
    for c in chars:
        if isinstance(c, dict):
            lines.append("- %s：%s" % (c.get("name", "?"), c.get("speech_style", "")))
    return "\n".join(lines) if lines else "（未定义）"


def _get_beats(state, ep):
    outline = state.get("outline") or {}
    eps = outline.get("episodes", [])
    if 1 <= ep <= len(eps):
        return _json_str(eps[ep - 1].get("beats", []))
    return "（无节拍数据）"


def _get_prev_summary(state, ep):
    if ep <= 1:
        return "（开篇第一集，无前情）"
    p = os.path.join(OUTPUT_DIR, "episode_%d.txt" % (ep - 1))
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            head = "".join(f.readlines()[:12])
        return "上一集片段：\n" + head
    return "（上一集未生成）"


def _make_brief(text):
    """把用户自由文本转成与 trend_brief 同构的 creative brief（字段对齐）。"""
    return {
        "hot_topics": [text],
        "viral_tropes": [],
        "emotion_peaks": [],
        "platform_bias": {},
        "viral_structures": [],
        "recommended_hooks": [],
        "note": text,
        "source": "user",
    }


# ── 命令实现 ──────────────────────────────────────────────
def cmd_init(args):
    with state_lock():
        os.makedirs(STATE_DIR, exist_ok=True)
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        gdef = _load_genres().get(args.genre, {})
        episodes = args.episodes if args.episodes is not None else gdef.get("episodes", 12)
        duration = args.duration if args.duration is not None else gdef.get("duration", 90)
        tone = args.tone if args.tone is not None else gdef.get("tone", "爽感")
        state = {
            "meta": {"project_name": args.name, "created": _now(), "updated": _now()},
            "config": {
                "genre": args.genre, "episodes": episodes,
                "duration": duration, "platform": args.platform,
                "tone": tone,
            },
            "stage": "story_pending",
            "trend_brief": None,
            "user_brief": None,
            "story_core": None,
            "outline": None,
            "episodes": {},
            "current_episode": 0,
            "history": [{"ts": _now(), "action": "init"}],
        }
        if args.brief:
            state["user_brief"] = _make_brief(args.brief)
        write_state(state)
        if state.get("user_brief"):
            print(json.dumps({"ok": True, "stage": "story_pending",
                              "msg": "项目已初始化，已载入你的自定义创作方向，可直接 `compose --stage story`（无需 fetch-trend）。",
                              "brief": state["user_brief"]}, ensure_ascii=False))
        else:
            print(json.dumps({"ok": True, "stage": "story_pending",
                              "msg": "项目已初始化。建议先 `fetch-trend` 采爆款热点，再 `compose --stage story`；"
                                     "若已有明确方向，可用 `save-brief` 或 `init --brief` 直接起步。",
                              "genre_default": {"episodes": episodes, "duration": duration, "tone": tone}},
                             ensure_ascii=False))


def cmd_fetch_trend(args):
    prompt = build_trend_prompt(args.genre, args.platform)
    print(json.dumps({"ok": True, "prompt": prompt,
                      "next": "按上方 prompt 调 web_search 采热点，生成 trend_brief.json 后执行 save-trend --file <路径>"},
                     ensure_ascii=False))


def cmd_save_trend(args):
    with state_lock():
        state = read_state()
        if state is None:
            print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
            return
        with open(args.file, "r", encoding="utf-8") as f:
            brief = parse_brief(f.read())
        state["trend_brief"] = brief
        state["history"].append({"ts": _now(), "action": "save_trend"})
        write_state(state)
        print(json.dumps({"ok": True, "msg": "trend_brief 已保存，可 compose story", "brief": brief},
                         ensure_ascii=False))


def cmd_save_brief(args):
    with state_lock():
        state = read_state()
        if state is None:
            print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
            return
        if args.file:
            # 统一走容错解析（兼容 ``` 包裹 / 裸 JSON）
            with open(args.file, "r", encoding="utf-8") as f:
                try:
                    brief = parse_brief(f.read())
                except Exception:
                    print(json.dumps({"ok": False, "msg": "brief 文件须为合法 JSON"}, ensure_ascii=False))
                    return
            if not isinstance(brief, dict):
                brief = {"hot_topics": [str(brief)], "note": str(brief)}
            brief.setdefault("source", "user")
        elif args.text:
            brief = _make_brief(args.text)
        else:
            print(json.dumps({"ok": False, "msg": "需提供 --file <brief.json> 或 --text <创作方向>"}, ensure_ascii=False))
            return
        state["user_brief"] = brief
        state["history"].append({"ts": _now(), "action": "save_brief"})
        write_state(state)
        print(json.dumps({"ok": True, "msg": "已保存自定义创作方向，可直接 `compose --stage story`（无需 fetch-trend）。",
                          "brief": brief}, ensure_ascii=False))


def cmd_lookup(args):
    data = kb_lookup(args.genre, args.top)
    if data is None:
        print(json.dumps({"ok": False, "msg": "无该赛道拆解库，可人工补充 knowledge/viral_structures/%s.json" % args.genre},
                         ensure_ascii=False))
        return
    print(json.dumps({"ok": True, "data": data}, ensure_ascii=False))


def cmd_compose(args):
    state = read_state()
    if state is None:
        print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
        return
    stage = args.stage
    cfg = state["config"]
    brief = active_brief(state)

    if stage == "story":
        kb = kb_lookup(cfg["genre"], 3) or {}
        kb_structures = "、".join(kb.get("structures", [])) if (kb and kb.get("structures")) else "（无）"
        prompt = _fill(_read_prompt("story_engine.md"),
                       genre=cfg["genre"], tone=cfg["tone"], platform=cfg["platform"],
                       episodes=cfg["episodes"], duration=cfg["duration"],
                       hot_topics=_brief_val(brief, "hot_topics"),
                       viral_structures=_brief_val(brief, "viral_structures"),
                       recommended_hooks=_brief_val(brief, "recommended_hooks"),
                       kb_structures=kb_structures)

    elif stage == "structure":
        if not state.get("story_core"):
            print(json.dumps({"ok": False, "msg": "请先完成 story"}, ensure_ascii=False))
            return
        prompt = _fill(_read_prompt("structure_planner.md"),
                       premise=state["story_core"].get("premise", ""),
                       characters=_json_str(state["story_core"].get("characters", [])),
                       episodes=cfg["episodes"], duration=cfg["duration"],
                       hot_topics=_brief_val(brief, "hot_topics"))

    elif stage == "script":
        ep = args.episode
        prompt = _fill(_read_prompt("script_writer.md"),
                       premise=state["story_core"].get("premise", ""),
                       characters=_json_str(state["story_core"].get("characters", [])),
                       episode=ep, total=cfg["episodes"],
                       beats=_get_beats(state, ep), prev_summary=_get_prev_summary(state, ep),
                       platform=cfg["platform"], duration=cfg["duration"],
                       speech=_speech_style(state))

    elif stage == "review":
        ep = args.episode
        p = os.path.join(OUTPUT_DIR, "episode_%d.txt" % ep)
        if not os.path.exists(p):
            print(json.dumps({"ok": False, "msg": "episode_%d.txt 不存在" % ep}, ensure_ascii=False))
            return
        with open(p, "r", encoding="utf-8") as f:
            script = f.read()
        prompt = _fill(_read_prompt("quality_judge.md"),
                       episode=ep, script=script, characters=_speech_style(state))
    else:
        print(json.dumps({"ok": False, "msg": "未知 stage"}, ensure_ascii=False))
        return

    print(json.dumps({"ok": True, "stage": stage, "prompt": prompt}, ensure_ascii=False))


def cmd_save(args):
    with state_lock():
        state = read_state()
        if state is None:
            print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
            return
        stage = args.stage
        with open(args.file, "r", encoding="utf-8") as f:
            content = f.read()

        if stage == "story":
            state["story_core"] = json.loads(content)
            state["stage"] = "story_done"
        elif stage == "structure":
            state["outline"] = json.loads(content)
            state["stage"] = "structure_done"
        elif stage == "script":
            ep = args.episode
            out_path = os.path.join(OUTPUT_DIR, "episode_%d.txt" % ep)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(content)
            res = check_script(content, state)
            state["episodes"][str(ep)] = {"status": "script_done", "check": res, "retry": 0}
            state["current_episode"] = ep
            # 最后一集完成则进入 review 阶段
            if ep >= state["config"]["episodes"]:
                state["stage"] = "review_pending"
            else:
                state["stage"] = "script_pending"
            state["history"].append({"ts": _now(), "action": "save_script", "ep": ep, "check": res})
            write_state(state)
            print(json.dumps({"ok": True, "stage": state["stage"], "check": res}, ensure_ascii=False))
            return
        elif stage == "review":
            ep = args.episode
            res = json.loads(content)
            rec = state["episodes"].setdefault(str(ep), {})
            rec["review"] = res
            rec["status"] = "done" if res.get("score", 0) >= 7 else "review_failed"
            # 全部剧集均已评审且通过 → 自动进入 done 终态
            all_eps = set(state["episodes"].keys())
            reviewed = {k for k, v in state["episodes"].items() if v.get("review") is not None}
            if all_eps and all_eps <= reviewed:
                passed = all((v.get("review") or {}).get("score", 0) >= 7
                             for v in state["episodes"].values())
                if passed:
                    state["stage"] = "done"
        else:
            print(json.dumps({"ok": False, "msg": "未知 stage"}, ensure_ascii=False))
            return

        state["history"].append({"ts": _now(), "action": "save_%s" % stage})
        write_state(state)
        print(json.dumps({"ok": True, "stage": state["stage"]}, ensure_ascii=False))


def cmd_advance(args):
    with state_lock():
        state = read_state()
        if state is None:
            print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
            return
        nxt = advance(state)
        if nxt:
            write_state(state)
            print(json.dumps({"ok": True, "stage": nxt, "msg": "已推进，可 compose 下一阶段"}, ensure_ascii=False))
        else:
            print(json.dumps({"ok": False, "msg": "当前阶段 %s 无法推进（需先 save 对应阶段产出）" % state.get("stage")},
                             ensure_ascii=False))


def cmd_rollback(args):
    with state_lock():
        state = read_state()
        if state is None:
            print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
            return
        nxt = rollback(state, to_stage=args.to, episode=args.episode)
        if nxt:
            write_state(state)
            print(json.dumps({"ok": True, "stage": nxt, "msg": "已回退"}, ensure_ascii=False))
        else:
            print(json.dumps({"ok": False, "msg": "回退失败，参数无效"}, ensure_ascii=False))


def cmd_review(args):
    state = read_state()
    if state is None:
        print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
        return
    ep = args.episode
    p = os.path.join(OUTPUT_DIR, "episode_%d.txt" % ep)
    if not os.path.exists(p):
        print(json.dumps({"ok": False, "msg": "episode_%d.txt 不存在" % ep}, ensure_ascii=False))
        return
    with open(p, "r", encoding="utf-8") as f:
        script = f.read()
    deterministic = check_script(script, state)
    # 创作性评判所需变量交给 LLM
    judge_vars = {
        "episode": ep,
        "script": script,
        "characters": _speech_style(state),
    }
    print(json.dumps({
        "ok": True,
        "deterministic": deterministic,
        "need_judge": judge_vars,
        "next": "用 quality_judge 评估后，执行 save --stage review --episode %d --file <结果json>" % ep
    }, ensure_ascii=False))


def cmd_reset(args):
    if not args.yes:
        print(json.dumps({"ok": False, "msg": "确认重置？加 --yes 将清空 state 与 output，然后请重新 init"},
                         ensure_ascii=False))
        return
    with state_lock():
        if os.path.exists(OUTPUT_DIR):
            for fn in os.listdir(OUTPUT_DIR):
                os.remove(os.path.join(OUTPUT_DIR, fn))
        if os.path.exists(STATE_FILE):
            os.remove(STATE_FILE)
    print(json.dumps({"ok": True, "msg": "已重置，请重新 init"}, ensure_ascii=False))


def cmd_verify(args):
    state = read_state()
    if state is None:
        print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
        return
    eps = _all_episodes(state)
    if not eps:
        print(json.dumps({"ok": False, "msg": "尚未生成任何剧集，无可校验内容"}, ensure_ascii=False))
        return
    result = verify_project(state, eps)
    print(json.dumps(result, ensure_ascii=False))


def cmd_export(args):
    state = read_state()
    if state is None:
        print(json.dumps({"ok": False, "msg": "请先 init"}, ensure_ascii=False))
        return
    out = export_pack(state, args.format)
    print(json.dumps({"ok": True, "path": out}, ensure_ascii=False))


def _now():
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ── 参数解析 ──────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="短剧剧本创作 Skill CLI")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("init")
    p.add_argument("--genre", required=True)
    p.add_argument("--episodes", type=int, default=None, help="不填则用 config/genres.json 中该赛道默认值")
    p.add_argument("--duration", type=int, default=None, help="不填则用赛道默认值")
    p.add_argument("--platform", default="抖音")
    p.add_argument("--tone", default=None, help="不填则用赛道默认值")
    p.add_argument("--name", default="未命名项目")
    p.add_argument("--brief", default=None, help="自定义创作方向（一句话即可），设置后跳过搜热点")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("fetch-trend")
    p.add_argument("--genre", required=True)
    p.add_argument("--platform", default="抖音")
    p.set_defaults(func=cmd_fetch_trend)

    p = sub.add_parser("save-trend")
    p.add_argument("--file", required=True)
    p.set_defaults(func=cmd_save_trend)

    p = sub.add_parser("lookup")
    p.add_argument("--genre", required=True)
    p.add_argument("--top", type=int, default=3)
    p.set_defaults(func=cmd_lookup)

    p = sub.add_parser("save-brief")
    p.add_argument("--file", default=None, help="结构化 brief JSON 路径（容错解析，兼容 ``` 包裹）")
    p.add_argument("--text", default=None, help="一句话创作方向，直接作为自定义简报")
    p.set_defaults(func=cmd_save_brief)

    p = sub.add_parser("compose")
    p.add_argument("--stage", required=True, choices=["story", "structure", "script", "review"])
    p.add_argument("--episode", type=int, default=1)
    p.set_defaults(func=cmd_compose)

    p = sub.add_parser("save")
    p.add_argument("--stage", required=True, choices=["story", "structure", "script", "review"])
    p.add_argument("--episode", type=int, default=1)
    p.add_argument("--file", required=True)
    p.set_defaults(func=cmd_save)

    p = sub.add_parser("advance")
    p.set_defaults(func=cmd_advance)

    p = sub.add_parser("rollback")
    p.add_argument("--to", default=None)
    p.add_argument("--episode", type=int, default=None)
    p.set_defaults(func=cmd_rollback)

    p = sub.add_parser("review")
    p.add_argument("--episode", type=int, required=True)
    p.set_defaults(func=cmd_review)

    p = sub.add_parser("reset")
    p.add_argument("--yes", action="store_true", help="确认清空 state 与 output")
    p.set_defaults(func=cmd_reset)

    p = sub.add_parser("verify")
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("export")
    p.add_argument("--format", default="full",
                   choices=["full", "script_only", "plain", "storyboard", "actor", "aivideo",
                            "episodes", "episodes_docx", "docx"])
    p.set_defaults(func=cmd_export)

    args = ap.parse_args()
    if not args.cmd:
        ap.print_help()
        return
    args.func(args)


if __name__ == "__main__":
    main()
