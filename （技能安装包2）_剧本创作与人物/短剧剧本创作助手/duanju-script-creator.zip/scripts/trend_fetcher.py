# -*- coding: utf-8 -*-
"""热点采集：读取 trend_fetch.md 模板并填充变量（实际搜索由 LLM 调用 web_search）。"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMPTS_DIR = os.path.join(ROOT, "prompts")


def build_trend_prompt(genre, platform):
    path = os.path.join(PROMPTS_DIR, "trend_fetch.md")
    with open(path, "r", encoding="utf-8") as f:
        tpl = f.read()
    return tpl.replace("{genre}", genre).replace("{platform}", platform)


def parse_brief(text):
    """把 LLM 返回的 trend_brief JSON 文本解析为 dict。"""
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end != -1:
        return json.loads(text[start:end + 1])
    return json.loads(text)
