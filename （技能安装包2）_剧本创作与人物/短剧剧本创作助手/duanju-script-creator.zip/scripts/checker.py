# -*- coding: utf-8 -*-
"""确定性校验规则引擎：只做代码可判定的检查，创作性评判留给 LLM。
重点包含「防幻觉」确定性规则：角色幻觉、场景清单漂移、前情/出场不一致。
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from state_manager import active_brief  # noqa: E402

# 非角色标记：这些词出现在「角色名」位置不是幻觉
_NARRATION = {"旁白", "画外音", "内心独白", "解说"}

# 非对白行前缀：含冒号但不是角色发言（如「本集钩子：…」）
_NON_DIALOGUE_PREFIX = {"本集钩子", "下集预告", "下集", "前情", "字幕", "转场", "独白", "画外音"}


def _extract_cast(text):
    """从剧本头「出场人物：…」提取本集出场角色名。"""
    m = re.search(r"出场人物[:：]\s*(.+)", text)
    if not m:
        return []
    return [x.strip() for x in re.split(r"[、,，]", m.group(1)) if x.strip()]


def _extract_speaking_roles(text):
    """提取所有「有对白」的角色名（含半角/全角括号与冒号）。"""
    roles = set()
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("【") or s.startswith("△") or s.startswith("#"):
            continue
        if "：" not in s and ":" not in s:
            continue
        role_part = re.split(r"[：:]", s, 1)[0].strip()
        if role_part in _NON_DIALOGUE_PREFIX:
            continue
        role = re.sub(r"[（(].*?[)）]", "", role_part).strip()
        if role and role not in _NARRATION:
            roles.add(role)
    return roles


def _extract_scene_nums(text):
    """剧本正文中出现的【场景N】编号集合。"""
    nums = set()
    for line in text.splitlines():
        m = re.search(r"【场景\s*(\d+)\s*】", line)
        if m:
            nums.add(int(m.group(1)))
    return nums


def _extract_listed_scenes(text):
    """文末【场景清单】表格里列出的场景号集合（解析失败返回空，不误报）。"""
    lines = text.splitlines()
    in_table = False
    nums = set()
    parsed = False
    for line in lines:
        if "场景清单" in line:
            in_table = True
            continue
        if in_table:
            s = line.strip()
            if s.startswith("|"):
                cells = [c.strip() for c in s.strip("|").split("|")]
                if cells and cells[0].isdigit():
                    nums.add(int(cells[0]))
                    parsed = True
            elif s and not s.startswith("|"):
                # 表格段结束
                if parsed:
                    break
    return nums if parsed else set()


def _scene_title_ep(text):
    """剧本大标题里的集号（如「第 5 集」「第05集」），用于跨集钩子对齐。"""
    m = re.search(r"第\s*0*(\d+)\s*集", text)
    return int(m.group(1)) if m else None


def check_script(text, state):
    issues = []
    blockers = []  # 命中即视为幻觉，强制不通过

    chars = (state.get("story_core") or {}).get("characters", [])
    name_map = {c.get("name"): c for c in chars if isinstance(c, dict)}
    known_names = set(name_map.keys())

    # 1. 对白长度：单句 > 15 字警告（与 script_writer / quality_judge 阈值统一）
    for line in text.splitlines():
        s = line.strip()
        if "：" in s and not s.startswith("【") and not s.startswith("△") and not s.startswith("#"):
            parts = s.split("：", 1)
            if len(parts) == 2:
                dialogue = parts[1]
                for sent in re.split(r"[。！？]", dialogue):
                    sent = sent.strip()
                    if len(sent) > 15:
                        issues.append({
                            "rule": "dialogue_length", "level": "warn",
                            "msg": "单句对白过长(>15字): " + sent[:13] + "…"
                        })

    # 2. 命名一致性：仅校验本集「出场人物」中列出者是否出现
    cast = _extract_cast(text)
    if cast:
        for name in cast:
            if name in name_map and name not in text:
                issues.append({
                    "rule": "naming", "level": "warn",
                    "msg": "出场人物「%s」未在剧本正文出现" % name
                })
    elif chars and isinstance(chars[0], dict) and chars[0].get("name"):
        if chars[0]["name"] not in text:
            issues.append({
                "rule": "naming", "level": "warn",
                "msg": "主角「%s」未在剧本中出现" % chars[0]["name"]
            })

    # 3. 热点契合度
    brief = active_brief(state)
    topics = brief.get("hot_topics", [])
    if topics:
        hit = [t for t in topics if t and t in text]
        if not hit:
            issues.append({
                "rule": "hot_topic", "level": "info",
                "msg": "未融入任何热点话题: " + "、".join(str(t) for t in topics)
            })

    # 4. 结尾钩子
    if "本集钩子" not in text and "下集预告" not in text:
        issues.append({
            "rule": "ending_hook", "level": "warn",
            "msg": "缺少结尾钩子（本集钩子 / 下集预告）"
        })

    # 5. 【防幻觉】角色幻觉：有对白的角色不在人物设定 / 出场名单中
    spoken = _extract_speaking_roles(text)
    declared = set(cast)
    hallucinated = spoken - known_names - declared - _NARRATION
    if hallucinated:
        blockers.append({
            "rule": "hallucination_character", "level": "block",
            "msg": "疑似幻觉角色（对白中出现但人物设定与出场名单均无）：" + "、".join(sorted(hallucinated))
        })

    # 6. 【防幻觉】对白角色未列入本集「出场人物」
    drift = spoken - declared
    if drift and known_names:  # 仅在有人物设定时判定，避免误伤
        issues.append({
            "rule": "role_not_in_cast", "level": "warn",
            "msg": "有对白的角色未列入出场人物：" + "、".join(sorted(drift))
        })

    # 7. 【防幻觉】场景清单与正文场景不一致
    body_scenes = _extract_scene_nums(text)
    list_scenes = _extract_listed_scenes(text)
    if list_scenes:
        missing_in_list = body_scenes - list_scenes
        missing_in_body = list_scenes - body_scenes
        if missing_in_list:
            issues.append({
                "rule": "scene_list_mismatch", "level": "warn",
                "msg": "正文有但场景清单缺失：" + "、".join("场景%d" % n for n in sorted(missing_in_list))
            })
        if missing_in_body:
            blockers.append({
                "rule": "scene_list_mismatch", "level": "block",
                "msg": "场景清单列了正文不存在的场景（可能虚构场景）：" + "、".join("场景%d" % n for n in sorted(missing_in_body))
            })

    issues.extend(blockers)
    warns = [i for i in issues if i["level"] in ("warn", "block")]
    score = max(0, 10 - len(warns) * 2)
    return {
        "score": score,
        "issues": issues,
        "blockers": blockers,
        "pass": (score >= 6) and not blockers,
        "note": "含防幻觉确定性检查（角色/场景清单一致性）。创作性维度请用 review 交给 LLM 评判"
    }


def verify_project(state, all_episodes):
    """全项目级防幻觉：跨集扫描，找出人物设定之外的角色与场景清单漂移。"""
    chars = (state.get("story_core") or {}).get("characters", [])
    known_names = {c.get("name") for c in chars if isinstance(c, dict)}
    problems = []
    for ep in sorted(all_episodes.keys(), key=lambda x: int(x)):
        text = all_episodes[ep]
        spoken = _extract_speaking_roles(text) - _NARRATION
        unknown = spoken - known_names
        cast = set(_extract_cast(text))
        unknown = unknown - cast
        if unknown:
            problems.append({
                "episode": int(ep),
                "unknown_characters": sorted(unknown),
                "msg": "第%s集出现人物设定之外的角色" % ep
            })
        list_scenes = _extract_listed_scenes(text)
        body_scenes = _extract_scene_nums(text)
        if list_scenes and (body_scenes - list_scenes or list_scenes - body_scenes):
            problems.append({
                "episode": int(ep),
                "scene_mismatch": {
                    "body": sorted(body_scenes),
                    "listed": sorted(list_scenes)
                },
                "msg": "第%s集场景清单与正文不一致" % ep
            })
    return {
        "ok": True,
        "problems": problems,
        "passed": len(problems) == 0,
        "msg": "无幻觉问题" if not problems else "发现 %d 处潜在幻觉/不一致" % len(problems)
    }
