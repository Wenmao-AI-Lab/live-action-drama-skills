# -*- coding: utf-8 -*-
"""状态机：story_state.json 的唯一读写入口。LLM 不直接碰状态文件。"""
import contextlib
import json
import os
from datetime import datetime

try:
    import fcntl
    _HAVE_FCNTL = True
except ImportError:
    _HAVE_FCNTL = False

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_DIR = os.path.join(ROOT, "state")
STATE_FILE = os.path.join(STATE_DIR, "story_state.json")
OUTPUT_DIR = os.path.join(ROOT, "output")
LOCK_FILE = STATE_FILE + ".lock"


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@contextlib.contextmanager
def state_lock():
    """跨平台建议性文件锁，防止并发读写唯一真相源（Linux/macOS 用 fcntl，Windows 用 msvcrt）。"""
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LOCK_FILE, "w", encoding="utf-8") as lf:
        if _HAVE_FCNTL:
            fcntl.flock(lf, fcntl.LOCK_EX)
        else:
            import msvcrt
            msvcrt.locking(lf.fileno(), msvcrt.LK_LOCK, 1)
        try:
            yield
        finally:
            if _HAVE_FCNTL:
                fcntl.flock(lf, fcntl.LOCK_UN)
            else:
                import msvcrt
                msvcrt.locking(lf.fileno(), msvcrt.LK_UNLCK, 1)


def read_state():
    if not os.path.exists(STATE_FILE):
        return None
    with open(STATE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def write_state(state):
    """原子写：先写临时文件再 os.replace，避免中途崩溃损坏唯一真相源。"""
    os.makedirs(STATE_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    state.setdefault("meta", {})["updated"] = _now()
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STATE_FILE)


def active_brief(state):
    """注入优先级：用户自定义 brief > 搜来的 trend_brief > 空。"""
    return state.get("user_brief") or state.get("trend_brief") or {}


def _clean_output(ep=None):
    """清理 output 下的剧本文件，保持与 state 同步（rollback 时调用）。"""
    if not os.path.exists(OUTPUT_DIR):
        return
    if ep is None:
        for fn in os.listdir(OUTPUT_DIR):
            if fn.startswith("episode_") and fn.endswith(".txt"):
                os.remove(os.path.join(OUTPUT_DIR, fn))
    else:
        p = os.path.join(OUTPUT_DIR, "episode_%s.txt" % ep)
        if os.path.exists(p):
            os.remove(p)


def advance(state):
    """用户在回路确认后，推进到下一阶段。"""
    mapping = {
        "story_done": "structure_pending",
        "structure_done": "script_pending",
        "review_pending": "done",
    }
    cur = state.get("stage")
    if cur in mapping:
        nxt = mapping[cur]
        state["stage"] = nxt
        state["history"].append({"ts": _now(), "action": "advance", "to": nxt})
        return nxt
    return None


def rollback(state, to_stage=None, episode=None):
    """回退：可整体回退到某阶段，或仅重做某一集。"""
    if episode is not None:
        key = str(episode)
        if key in state.get("episodes", {}):
            state["episodes"][key]["status"] = "stale"
            state["current_episode"] = episode
            state["stage"] = "script_pending"
            _clean_output(episode)
            state["history"].append({"ts": _now(), "action": "rollback_episode", "ep": episode})
            return "script_pending"
        return None

    order = ["story", "structure", "script", "review", "done"]
    if to_stage in order:
        idx = order.index(to_stage)
        state["stage"] = to_stage + "_pending"
        # 清空该阶段之后的所有产出
        if idx <= 0:
            state["story_core"] = None
        if idx <= 1:
            state["outline"] = None
        if idx <= 2:
            state["episodes"] = {}
            _clean_output()
        state["history"].append({"ts": _now(), "action": "rollback_to", "to": to_stage})
        return state["stage"]
    return None
