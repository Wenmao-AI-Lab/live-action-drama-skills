# -*- coding: utf-8 -*-
"""爆款结构拆解库：静态查表（人工维护种子库，不自动演化）。"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(ROOT, "knowledge", "viral_structures")


def lookup(genre, top=3):
    path = os.path.join(KB_DIR, genre + ".json")
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    structures = data.get("structures", [])[:top]
    return {
        "genre": genre,
        "structures": structures,
        "hooks": data.get("hooks", []),
        "tropes": data.get("tropes", []),
    }
