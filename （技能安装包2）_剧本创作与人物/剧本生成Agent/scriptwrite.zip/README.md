# 剧本生成 Agent (Scriptwriter Master)

## 这是什么

视频制作流程中的**第一个**Agent —— 把用户的模糊创意，变成一份可读的、文学化的剧本。

确认后再交给下游 [`storyboard-master-agent`](../storyboard-master/) 做分镜规划。

## 在整个流程中的位置

```
用户创意 → [scriptwriter-master] → 用户确认剧本 → [storyboard-master] → 分镜 JSON → 声音/文案/视觉
                  ↑ 你在这里
```

## 解决的核心问题

老流程中，分镜导演同时在做两件事：写故事 + 排镜头。结果是：
- 用户看到的是塞满 JSON 的输出，无法直观判断"这是不是我想要的故事"
- 改个故事方向，整份分镜数据要重做
- 分镜导演被故事打架拖住，没法专心做镜头规划

剧本环节独立出来后：
- 用户先在文字层面达成共识，再进入镜头规划
- 故事修订成本低（只改文字），不动分镜
- 分镜导演拿到的是确认过的剧本，可以全力做专业镜头工作

## 工作流程速览

| Step | 做什么 | 给用户看什么 |
|------|--------|-------------|
| 1. 信息收集 | 缺关键要素时用 AskUserQuestion 追问 | 选项卡片 |
| 2. 剧本生成 | 按模板生成文学化 Markdown 剧本 | 剧本全文 |
| 3. 用户确认 | 等用户说"通过"或"修改" | 确认提示 |
| 4. 静默移交 | 生成 JSON 调用 storyboard-master | 一句"剧本已确认"提示 |

## 输出形态

### 给用户的（Markdown 剧本）

包含：项目设定、故事大纲、情绪曲线、若干场景的文学化叙事、关键画面、对白旁白、整体节奏说明。**没有任何镜头术语、时间码、JSON。**

参见 [examples/script-examples.md](./examples/script-examples.md) 中的完整示例。

### 给下游的（结构化 JSON）

字段命名严格匹配 storyboard-master 的"接收上游 Agent 输入"契约：

- `scenes[].narrative_text` — 文学化场景正文
- `scenes[].key_visual_moments` — 必须呈现的关键画面
- `scenes[].objective` / `emotional_tone`
- `narrative_structure` / `emotional_curve`
- `dialogue_summary`
- `scriptwriter_notes`（含 core_messages、brand_constraints、must_have_visuals 等）

完整结构见 [SKILL.md 输出契约章节](./SKILL.md#输出契约传给-storyboard-master-的-json)。

## 不做的事

- ❌ 不规划景别 / 运镜 / 镜头时长 / 转场（那是 storyboard-master 的活）
- ❌ 不在剧本里写"特写"、"推镜"、"硬切"等术语
- ❌ 不在用户没确认前生成 JSON 或调用下游
- ❌ 不展示 JSON 给用户

## 用法示例

**用户：**
> "为我们的智能手表做一个 60 秒广告，目标年轻都市白领，要现代感和科技感，核心是健康监测功能。"

**Agent 输出：**
- 一份完整的文学化 Markdown 剧本（4 个场景）
- 末尾附确认提示

**用户：**
> "第二场再温暖一点。"

**Agent 输出：**
- 整体重写一版完整剧本，第二场基调调整
- 再次附确认提示

**用户：**
> "可以了。"

**Agent 行为：**
- 简短回复"剧本已确认，正在交给分镜总导演"
- 静默生成 JSON、调用 storyboard-master

## 版本

- v1.0 (2026-05-08) — 初版
- 与 storyboard-master-agent v1.x 接口对齐

## 相关文件

- [SKILL.md](./SKILL.md) — 完整 skill 定义（给 Agent 用）
- [examples/script-examples.md](./examples/script-examples.md) — 剧本输出样例
- [../storyboard-master/](../storyboard-master/) — 下游分镜导演 skill
