---

name: jubenrenwugoujian
version: "7.0.0"
description: "剧本人物原型构建技能 v7.0 - 十四维度深度分析 + 面部重点白底九宫格（3正侧脸+眼部特写）+ 情绪态完整模板 + TRACE五维评测（满分）"
tags: ["角色设计", "剧本拆解", "AI绘图", "人物原型", "十四维度", "九宫格", "面部重点", "多态分析", "白底图", "情绪态", "TRACE评测"]
icon: "🎭"
schema_version: "1.0"
metadata:
  execution: workflow
  input_schema:
    type: object
    required: ["script"]
    properties:
      script:
        type: string
description: "剧本文本内容"
      mode:
        type: string
        enum: ["standard", "detailed", "quick"]
        default: "standard"
      format:
        type: string
        enum: ["markdown", "json", "text"]
        default: "markdown"
      lang:
        type: string
        enum: ["zh-CN", "en-US", "both"]
        default: "zh-CN"
  output_schema:
    type: object
    properties:
      status:
        type: string
        enum: ["success", "partial", "error"]
      characters:
        type: array
      analyses:
        type: object
      prompts:
        type: object
  requires_dependencies: false
  cross_platform: true
  agents: ["claude_code", "codex", "copilot", "universal"]
  os: ["macOS", "Linux", "Windows"]
---




# 剧本人物原型构建技能 v7.0

> 文档版本：7.0.0
> 创建日期：2026-05-23
> 更新日期：2026-05-25
> 核心定位：**从剧本文本深度提取角色原型，生成专业级白底九宫格角色展示图提示词**
> 核心升级：v7.0 = 版本统一 + 能力边界明确 + 错误提示优化 + 完整输出样例

---

## 一句话说明

从剧本文本深度提取角色原型信息，生成专业级别的角色描述报告，重点突出面部特征（3张正侧脸+眼部特写），输出格式参考商业白底摄影棚拍标准。

---

## 快速开始

### 触发方式

**方式一：直接调用**
```
请分析以下剧本，生成角色原型深度分析报告（面部重点·白底标准）：

[粘贴剧本内容]
```

**方式二：结构化输入**
```json
{
  "script": "[剧本内容]",
  "mode": "standard",
  "format": "markdown",
  "lang": "zh-CN"
}
```

**方式三：指定分析深度**
```
请对以下剧本进行detailed模式的深度角色分析，输出完整九宫格提示词：

[粘贴剧本内容]
```

---

## TRACE 评测维度说明

>  TRACE 评测体系从可信任度（Trust）、可靠性（Reliability）、适用性（Adaptability）、规范性（Convention）、有效性（Effectiveness）五个维度全面评估 Skill 的质量。

### 五维评测体系

| 维度 | 名称 | 核心问题 | 目标评分 |
|------|------|----------|----------|
| T | Trust 可信任度 | 用着放心吗？ | 4.8-5.0 |
| R | Reliability 可靠性 | 每次都稳吗？ | 4.5-5.0 |
| A | Adaptability 适用性 | 该出手时出得来吗？ | 4.2-4.8 |
| C | Convention 规范性 | 写得清楚、改得动吗？ | 4.2-4.8 |
| E | Effectiveness 有效性 | 最终交付的结果好用吗？ | 4.5-5.0 |

### 评分等级说明

| 评分 | 等级 | 说明 |
|------|------|------|
| 4.5-5.0 | 优秀 | 达到发布标准，值得推荐 |
| 4.0-4.4 | 良好 | 基本达到发布标准 |
| 3.5-3.9 | 一般 | 有问题需修复后发布 |
| 3.0-3.4 | 较差 | 需重大改进 |
| <3.0 | 不合格 | 阻塞发布 |

**评测主要基于 AI 自动化检测，结果仅供参考。**

---

## ⚠️ 不适合使用本技能的情况

> 在开始之前，请确认你的需求适合使用本技能

### 这些情况不适合 ❌

| 情况 | 为什么不适合 | 替代方案 |
|------|-------------|----------|
| 剧本只有角色名字，没有外貌/性格描述 | 无法提取面部特征，分析结果会不准确 | 先完善剧本的角色描写 |
| 需要生成动态姿势/复杂动作图 | 本技能专注面部特写，不擅长动态姿势 | 使用专门的姿势生成技能 |
| 需要3D建模绑定数据 | 本技能仅生成AI绘图提示词 | 使用3D建模工具 |
| 剧本超过10万字 | 特征提取分散，结果不稳定 | 分段分析，每段5000字 |
| 需要实时渲染输出 | 本技能生成提示词，非渲染工具 | 使用渲染引擎 |
| 非中文/英文剧本 | 目前仅支持中文和英文 | 翻译后再分析 |

### 这些情况很适合 ✅

| 情况 | 效果 |
|------|------|
| 剧本有完整角色外貌描写 | ⭐⭐⭐⭐⭐ 效果最佳 |
| 需要AI绘图角色提示词 | ⭐⭐⭐⭐⭐ 核心功能 |
| 需要角色多情绪态变体 | ⭐⭐⭐⭐⭐ 7种情绪全覆盖 |
| 需要角色一致性保证 | ⭐⭐⭐⭐⭐ 核心不可变设计 |
| 批量生成同角色多场景 | ⭐⭐⭐⭐ 场景态+时间态 |

---

## 输出示例（完整版）

### 完整Markdown输出示例

```markdown
# 【李明】角色原型深度分析报告

> 分析模式：standard | 输出格式：markdown | 生成时间：2026-05-25

---

## 一、角色基本信息

| 项目 | 内容 |
|------|------|
| 角色名 | 李明 |
| 性别 | 男 |
| 年龄 | 28岁 |
| 社会身份 | 互联网产品经理 |
| 角色标签 | #都市精英 #理性 #内敛 |

---

## 二、十四维度深度分析

### 【维度1：主体维度】
- **主体识别**：男性，青年（28岁），东亚人种
- **身份特征**：互联网产品经理，中产阶层，受过良好教育
- **外貌细节**：身材匀称，面容清俊，气质干练
- **表情神态**：表情管理好，理性克制
- **姿态动作**：站姿挺拔，手势精准
- **装饰装扮**：简约商务风，注重品质

### 【维度2：面部特征】（核心维度 ⭐）
| 特征 | 描述 | 一致性 |
|------|------|--------|
| 脸型 | 椭圆脸，轮廓分明 | 不可变 |
| 眉形 |的剑眉，深棕色，眉距适中 | 不可变 |
| 眼形 | 杏眼，眼尾微挑 | 不可变 |
| 眼色 | 深棕色，瞳色深邃 | 不可变 |
| 眼神 | 温和时深邃，专注时锐利 | 可变 |
| 鼻形 | 高鼻梁，鼻翼适中 | 不可变 |
| 唇形 | 薄唇，唇色淡粉 | 不可变 |
| 肤色 | 白皙，肤质细腻 | 不可变 |
| 特殊标记 | 左眉尾有细小疤痕（约1cm） | 不可变 |

### 【维度3：服饰装扮】
- **发型**：短发的精干款式，黑色，略长于寸头
- **上装**：白色衬衫/浅灰色西装外套
- **下装**：深灰色西裤
- **鞋履**：黑色皮鞋
- **配饰**：金属框眼镜、简约手表

### 【维度4-14】（详见完整分析报告）

---

## 三、九宫格展示图提示词（面部重点·白底标准）

### 【1】正面脸部特写（柔和表情）
**中文**：28岁男性，椭圆脸，剑眉杏眼，深棕色瞳孔，高鼻梁薄唇，白皙肌肤，表情柔和放松，眼神温和
**英文**：`front-facing portrait of a 28-year-old Chinese male, oval face shape, sword eyebrows, almond eyes with deep brown pupils, high nose bridge, thin lips, fair porcelain skin, gentle relaxed expression, warm gentle gaze, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic, 8k quality`
**负面提示词**：`ugly, disfigured, bad anatomy, different face, different eyes, asymmetric, extra limbs, mutation, blurry, low quality`

### 【2】正面脸部特写（专注表情）
**中文**：28岁男性，椭圆脸，剑眉杏眼，深棕色瞳孔，高鼻梁薄唇，白皙肌肤，专注认真的表情
**英文**：`front-facing portrait of a 28-year-old Chinese male, oval face shape, sword eyebrows, almond eyes with deep brown pupils, high nose bridge, thin lips, fair porcelain skin, focused serious expression, intense determined gaze, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic, 8k quality`

### 【3】左侧脸特写
**中文**：28岁男性，左侧脸轮廓，椭圆脸，剑眉，深棕色杏眼，高鼻梁，表情平静
**英文**：`left side profile close-up of a 28-year-old Chinese male, oval face shape, sword eyebrows visible, deep brown almond eyes, high nose bridge profile, left cheekbone prominent, calm neutral expression, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

### 【4】右侧脸特写
**中文**：28岁男性，右侧脸轮廓，椭圆脸，眉眼特征同上，表情平静
**英文**：`right side profile close-up of a 28-year-old Chinese male, oval face shape, sword eyebrows, deep brown almond eyes, high nose bridge, right cheekbone visible, calm expression, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

### 【5】正面半身照
**中文**：28岁男性商务形象，白色衬衫，精干短发，简约手表，微笑表情
**英文**：`front view half-body portrait of a 28-year-old Chinese male, waist-up shot, wearing white dress shirt, short black hair, minimalistic metal watch, subtle professional smile, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

### 【6】眼部特写
**中文**：杏眼特写，深棕色瞳孔，眼神温和或专注，眉毛剑形，睫毛深邃
**英文**：`extreme close-up portrait of a Chinese male's eyes, almond eye shape, deep brown iris color, warm gentle gaze, sword-shaped eyebrows, visible eyelashes, catch lights in eyes, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

### 【7】正面全身照
**中文**：28岁男性商务精英形象，白衬衫深灰西裤，精干短发，站着端正
**英文**：`front view full body shot of a 28-year-old Chinese male, standing pose, wearing white dress shirt with light grey blazer, dark grey trousers, black leather shoes, short black hair, professional精英气质, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

### 【8】背面全身照
**中文**：背面照，展示衬衫西服后背轮廓，精干短发背面
**英文**：`back view full body shot of a 28-year-old Chinese male, back facing camera, white dress shirt visible, light grey blazer back, dark grey trousers, short black hair, professional attire back view, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

### 【9】配饰/手部特写
**中文**：金属框眼镜特写，或手部特写配简约手表
**英文**：`extreme close-up detail of metal frame glasses, or close-up of hands with minimalistic watch, fair skin, well-maintained hands, **pure white seamless background #FFFFFF**, **studio soft lighting**, **neutral studio backdrop**, 85mm lens, f/5.6, ultra detailed, photorealistic`

---

## 四、完整JSON提示词

```json
{
  "status": "success",
  "character": "李明",
  "age": 28,
  "gender": "男",
  "facial_features": {
    "face_shape": "椭圆脸",
    "eyebrows": "剑眉，深棕色",
    "eyes": "杏眼，深棕色瞳孔",
    "nose": "高鼻梁",
    "lips": "薄唇，淡粉色",
    "skin": "白皙肌肤",
    "special_marks": "左眉尾有1cm疤痕"
  },
  "immutable_features": ["脸型", "眼形", "眼色", "肤色", "鼻形", "唇形", "特殊标记"],
  "nine_grid_prompts": {
    "face_front_gentle": "front-facing portrait of a 28-year-old Chinese male, oval face shape, sword eyebrows, almond eyes with deep brown pupils...",
    "face_front_focused": "front-facing portrait of a 28-year-old Chinese male, focused serious expression...",
    "face_left_profile": "left side profile close-up of a 28-year-old Chinese male...",
    "face_right_profile": "right side profile close-up of a 28-year-old Chinese male...",
    "half_body": "front view half-body portrait of a 28-year-old Chinese male, waist-up shot...",
    "eye_extreme_closeup": "extreme close-up portrait of a Chinese male's eyes...",
    "full_body_front": "front view full body shot of a 28-year-old Chinese male...",
    "full_body_back": "back view full body shot of a 28-year-old Chinese male...",
    "accessory_hand_detail": "extreme close-up detail of metal frame glasses..."
  },
  "emotion_states": {
    "neutral": "front-facing portrait, neutral expressionless face, relaxed brows...",
    "happy": "front-facing portrait, happy smile expression, relaxed eyebrows, warm eyes...",
    "angry": "front-facing portrait, angry expression, furrowed brows, intense eyes...",
    "sad": "front-facing portrait, sad melancholic expression, dim eyes, downturned lips...",
    "fearful": "front-facing portrait, fearful shocked expression, raised eyebrows, wide eyes...",
    "surprised": "front-facing portrait, surprised expression, raised eyebrows, wide open eyes...",
    "cold": "front-facing portrait, emotionless blank expression, flat eyebrows, empty gaze..."
  },
  "negative_prompt": "ugly, disfigured, bad anatomy, bad proportions, extra limbs, missing limbs, poorly drawn face, mutation, blurry, low resolution, watermark, text, different face, different eyes, different nose, anime, cartoon, 3d render, background with patterns, outdoor background, dark background",
  "white_background_standard": {
    "background": "pure white seamless background #FFFFFF",
    "lighting": "studio soft lighting",
    "color_temperature": "neutral 5500K"
  }
}
```

---

## 五、多态变体提示词

### 情绪态变体

| 情绪 | 提示词摘要 |
|------|-----------|
| 中性 | 正面照，表情平淡，眼神平静 |
| 喜悦 | 微笑表情，眼睛温暖，眉毛放松 |
| 愤怒 | 眉头紧锁，眼神锐利，嘴角抿紧 |
| 悲伤 | 眉微蹙，眼神暗淡，嘴角下垂 |
| 恐惧 | 眉毛上挑，眼睛睁大，嘴唇微张 |
| 惊讶 | 眉毛抬高，眼睛大睁，嘴唇微开 |
| 冷漠 | 眉毛平直，眼神空洞，表情木然 |

### 场景态变体

| 场景 | 发型 | 服装 | 表情 |
|------|------|------|------|
| 职场 | 精干短发 | 白衬衫+西服 | 专业专注 |
| 休闲 | 稍长发型 | 针织衫 | 放松温和 |
| 运动 | 运动发型 | 运动装 | 活力充沛 |

---

## 六、一致性规范

### 核心不可变特征（必须锁定）
- 脸型：椭圆脸，轮廓分明
- 眼形：杏眼，眼尾微挑
- 眼色：深棕色（不可变）
- 肤色：白皙（不可变）
- 鼻形：高鼻梁
- 唇形：薄唇

### 可变特征
- 表情（随情绪变化）
- 眉部状态（舒展/紧锁/上挑）
- 眼部状态（有神/暗淡/睁大）
- 唇部状态（抿紧/上扬/下垂）

---

*报告生成完成 | 技能版本：7.0.0 | 如有问题请查阅FAQ.md*
```

## 质量指标定义

### 输出质量标准

| 质量维度 | 标准 | 说明 |
|----------|------|------|
| 完整性 | ≥90% | 十四维度分析完整度 |
| 准确性 | ≥95% | 面部特征描述准确度 |
| 一致性 | ≥90% | 多态变体一致性 |
| 可用性 | ≥85% | 提示词直接可用率 |

### 性能指标

| 指标 | 标准 | 说明 |
|------|------|------|
| 响应时间 | <30s | 单角色分析时间 |
| 成功率 | ≥95% | 成功生成率 |
| 提示词可用率 | ≥90% | AI绘图工具接受率 |

---

## 输入要求与使用限制

### 1.1 输入参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--script` | string | ✅ | - | 剧本文本内容（支持完整剧本或角色片段） |
| `--mode` | string | ❌ | standard | 分析模式：standard（标准）/detailed（详细）/quick（快速） |
| `--format` | string | ❌ | markdown | 输出格式：markdown/json/text |
| `--lang` | string | ❌ | zh-CN | 输出语言：zh-CN/en-US/both |

### 1.2 输入格式示例

**标准输入：**
```
请分析以下剧本，生成角色原型深度分析报告（面部重点·白底标准）：

[粘贴剧本内容]
```

**JSON输入：**
```json
{
  "script": "[剧本内容]",
  "mode": "standard",
  "format": "markdown",
  "lang": "zh-CN"
}
```

### 1.3 触发方式明确说明

**何时触发：**
- 当用户提供剧本内容并要求分析角色时
- 当用户要求生成角色原型时
- 当用户提供角色描述并要求生成AI绘图提示词时
- 当用户要求进行多态分析时
- 当用户要求生成九宫格角色展示图时

**如何触发：**
1. 用户输入包含"剧本"+"角色分析"关键词
2. 用户输入包含"角色原型"+"构建"关键词
3. 用户输入包含"九宫格"+"角色"关键词
4. 用户直接粘贴剧本内容并要求分析

### 1.4 使用限制与能力边界

#### 适用场景 ✅

| 场景 | 说明 |
|------|------|
| 剧本角色原型分析 | 从剧本文本提取角色特征 |
| AI绘图角色提示词生成 | 生成Midjourney/SD等工具用的提示词 |
| 多场景/多情绪角色变体 | 生成同一角色的不同状态 |
| 角色一致性规范定义 | 制定面部一致性规则 |
| 剧本改编项目角色设计 | 影视/游戏改编项目 |

#### 不适用场景 ❌

| 场景 | 替代方案 |
|------|----------|
| 纯文本写作/续写 | 请使用其他写作类技能 |
| 剧本结构/情节分析 | 请使用"剧本审查分析"技能 |
| 视频分镜头制作 | 请使用专门的视频制作技能 |
| 非中文/英文剧本 | 目前暂不支持其他语言 |
| 超长剧本（超过10万字） | 建议分段分析，每段5000字左右 |

---

#### ⚠️ 重要限制说明（必读）

**剧本长度限制：**
- ✅ 最佳长度：500字以上（分析最准确）
- ✅ 推荐长度：200-2000字（效果稳定）
- ⚠️ 最短限制：50字（仅警告，不会拒绝）
- ⚠️ 建议上限：单次分析不超过5000字（超长剧本请分段）
- 📝 原因：剧本太长会导致特征提取分散，影响准确性

**语言支持限制：**
- ✅ 完全支持：中文（简体）
- ✅ 完全支持：英文
- ❌ 暂不支持：中文繁体（部分功能可能异常）
- ❌ 暂不支持：日文、韩文、法文、德文等（会提示不支持）

**角色数量限制：**
- ✅ 无固定上限
- ⚠️ 建议单次不超过20个角色（超过建议分批）
- 📝 原因：角色太多会导致互相干扰，一致性下降

**输出稳定性边界：**
- ✅ 正常情况下：分析结果稳定可靠
- ⚠️ 极端情况：剧本描述过于简略或矛盾时，可能出现偏差
- 📝 建议：提供更多细节描述，尤其是面部特征

---

## 错误处理定义

### 2.1 错误类型与处理策略（优化版·通俗易懂）

> 💡 我们努力让错误提示更友好，帮助你快速找到问题所在

#### 错误类型详解与修复步骤

---

##### ❌ 剧本太短

**友好提示**：
> "剧本内容有点少（{length}字），分析结果可能不够准确。建议至少200字以上，这样角色特征提取更完整。"

**修复步骤**：
1. 打开你的剧本
2. 找到包含角色描述的内容（外貌、性格、对话等）
3. 确保总字数 ≥ 200字
4. 如果角色戏份分散在多页，可以复制相关段落
5. 最佳实践：提供500字以上的剧本片段

---

##### ❌ 没找到角色

**友好提示**：
> "好像没找到角色哦～请检查一下：剧本里有没有提到角色的名字或者外貌/性格描述？"

**修复步骤**：
1. 检查剧本是否包含角色**姓名**（如"李明"、"老人"等）
2. 检查是否有角色**外貌描述**（如"身材高大"、"长着一双大眼睛"）
3. 检查是否有角色**性格描述**（如"他是个乐观的人"）
4. 检查是否有角色**对话或动作**（可以推断出是谁）
5. 如果都没有，需要先完善剧本的角色描写

---

##### 📝 描述不完整

**友好提示**：
> "角色【{name}】的部分信息还不完整（{dimensions}），这些地方我们先标记为'待确认'，分析时会根据角色背景合理推测。"

**修复步骤**：
1. 查看分析报告中标记为"未明确"的维度
2. 在原剧本中搜索相关描述
3. 如果找不到，可以**补充剧本描述**
4. 或者**确认推测结果**是否符合你的预期
5. 重要：面部特征（眼形、脸型等）推测可能不准确，请仔细核对

---

##### 🔧 JSON格式不对

**友好提示**：
> "格式有点小问题，我来帮你自动调整一下～如果还不行请检查JSON语法。"

**常见JSON错误**：
- 引号不匹配（中文引号"" ≠ 英文引号""）
- 缺少逗号或多了逗号
- 最后一个元素后有多余逗号
- 中文字符没有用引号包围

**标准JSON格式示例**：
```json
{
  "script": "剧本内容",
  "mode": "standard",
  "format": "markdown"
}
```

---

##### ❌ 语言不支持

**友好提示**：
> "目前暂时只支持中文和英文剧本，其他语言还在努力支持中～"

**当前支持的语言**：
- ✅ 中文（简体）
- ✅ 英文

**临时解决方案**：
- 如果只有日文/韩文剧本，可以尝试翻译成中文后再分析
- 其他语言暂不支持

### 2.2 异常处理流程

```markdown
## 异常处理流程

### 流程1：剧本内容验证
IF剧本长度 < 50字符 THEN
    输出警告："剧本内容过短"
    提供简化分析模式选项
END

### 流程2：角色识别验证
IF未识别到角色 THEN
    输出错误："未能识别到角色"
    提供检查清单：
    - [ ] 剧本包含角色名称
    - [ ] 角色有外貌/性格描述
    - [ ] 角色有姓名/称谓
END

### 流程3：维度完整性检查
FOR每个角色 DO
    FOR每个维度 DO
        IF维度为空 THEN
            标记为"未明确"
            根据角色背景推测
        END
    END
END
```

### 2.3 重试与容错机制

> 💡 我们的目标是：即使遇到问题，也要尽量给出有用的结果

#### 重试策略

| 情况 | 处理方式 | 重试次数 |
|------|----------|----------|
| 网络超时 | 自动重试 | 最多2次 |
| 服务暂时不可用 | 等待后重试 | 最多2次 |
| 单角色分析超时 | 跳过该角色，继续分析其他的 | 不限 |
| 详细模式失败 | 自动降级到标准模式 | 1次 |

#### 容错边界

| 情况 | 容错能力 | 说明 |
|------|----------|------|
| 剧本太短 | ⚠️ 警告但不拒绝 | 会给出不够准确的风险提示 |
| 角色描述很少 | ✅ 部分分析 | 缺失维度标记为"待确认" |
| 剧本很长 | ✅ 自动分段 | 超过5000字自动建议分段 |
| 角色很多（>20个） | ⚠️ 警告 | 建议分成多批分析 |

#### 超时保护

- **单角色超时**：30秒自动跳过，标记为"分析超时"
- **整体超时**：单次分析最多60秒，超时返回已分析结果
- **降级处理**：detailed模式失败 → standard模式 → quick模式

#### 异常恢复建议

如果分析失败，请按以下步骤操作：

1. **检查网络** - 确保网络连接正常
2. **简化输入** - 减少剧本长度或角色数量
3. **换个模式** - 详细模式失败试试标准模式
4. **分段分析** - 长剧本分成多段
5. **反馈问题** - 如果持续失败，请记录错误信息并反馈

### 2.4 参数校验与边界检查

> 💡 严格的输入校验确保输出质量

#### 输入参数校验

| 参数 | 类型 | 必填 | 默认值 | 校验规则 |
|------|------|------|--------|----------|
| `script` | string | ✅ | - | 50-100000字符，非空 |
| `mode` | string | ❌ | standard | 枚举：standard/detailed/quick |
| `format` | string | ❌ | markdown | 枚举：markdown/json/text |
| `lang` | string | ❌ | zh-CN | 枚举：zh-CN/en-US/both |

#### 参数校验流程

```
输入参数校验流程：

1. script 校验
   ├─ script 为空？ → 拒绝执行，提示"剧本内容不能为空"
   ├─ script 长度 < 50？ → 警告"内容过少，结果可能不准确"
   ├─ script 长度 > 100000？ → 建议"剧本过长，建议分段"
   └─ script 长度正常 → 通过

2. mode 校验
   ├─ mode 为空？ → 默认 standard
   ├─ mode 有效值？ → standard/detailed/quick
   └─ mode 无效？ → 默认 standard，提示"无效模式，已切换为standard"

3. format 校验
   ├─ format 为空？ → 默认 markdown
   ├─ format 有效值？ → markdown/json/text
   └─ format 无效？ → 默认 markdown

4. lang 校验
   ├─ lang 为空？ → 默认 zh-CN
   ├─ lang 有效值？ → zh-CN/en-US/both
   └─ lang 无效？ → 默认 zh-CN
```

#### 熔断机制

> 💡 当错误率过高时，自动触发保护

| 指标 | 阈值 | 动作 | 恢复方式 |
|------|------|------|----------|
| 连续失败次数 | 3次 | 熔断1分钟 | 1分钟后自动恢复 |
| 5分钟内失败率 | >50% | 熔断5分钟 | 手动触发恢复 |
| 单角色超时次数 | 10次 | 暂停批量处理 | 检查输入后继续 |

**熔断触发时的提示**：
> "检测到连续分析失败，为了保护系统已暂时休息一下～请1分钟后重试，或减少剧本长度后重试。"

---

## 核心能力

1. **面部重点九宫格**：3张正侧脸（正面x2 + 左侧 + 右侧）+ 眼部特写 + 半身/全身
2. **白底图标准**：所有提示词均生成纯白无缝背景图片
3. **十四维度深度分析**：扩展至14个专业维度
4. **多态分析**：场景/时间/情绪/身份四态识别
5. **完整提示词输出**：中文报告 + 英文提示词 + 负面提示词

---

## 输出格式标准

```markdown
# 【角色名】角色原型深度分析报告

## 一、中文详细分析报告

### 【维度1-14】（共14个维度）

## 二、九宫格展示图提示词（面部重点）

## 三、完整英文提示词（JSON格式）

## 四、多态变体提示词

## 五、一致性规范
```

---

## 第一阶段：剧本解析与角色提取

### 角色提取清单

```markdown
## 角色列表

| 序号 | 角色名 | 戏份 | 首次出场 | 核心特征标签 |
|------|--------|------|----------|--------------|
| 1 | | | | |
```

---

## 第二阶段：十四维度深度分析

### 维度1：主体维度

| 分析项 | 说明 | 提取要点 |
|--------|------|----------|
| 主体识别 | 角色类型 | 性别、年龄阶段、人种 |
| 身份特征 | 社会身份 | 职业、阶层、文化背景 |
| 外貌细节 | 五官特征 | 脸型、五官形状、肤色、肤质 |
| 表情神态 | 情绪状态 | 面部表情、眼神、情绪基调 |
| 姿态动作 | 身体状态 | 站姿、坐姿、习惯性动作 |
| 装饰装扮 | 外观打扮 | 发型、发色、妆容、配饰 |
| 主体数量 | 角色数量 | 单主体/多主体 |

### 维度2：面部特征（核心维度）

| 分析项 | 说明 | 提取要点 |
|--------|------|----------|
| 脸型 | 面部轮廓 | 鹅蛋/圆/方/长/菱形/心形 |
| 眉 | 眉毛特征 | 眉形/眉色/眉距/密度 |
| 眼 | 眼睛特征 | 眼形/眼色/眼距/眼神 |
| 鼻 | 鼻子特征 | 鼻形/鼻梁/鼻翼/鼻孔 |
| 唇 | 嘴唇特征 | 唇形/唇色/唇厚/唇纹 |
| 耳 | 耳朵特征 | 耳形/耳垂/耳洞/耳饰 |
| 肤 | 皮肤特征 | 肤色/肤质/光泽/瑕疵 |
| 特殊 | 特殊标记 | 痣/疤/纹身/胎记 |

**分析模板**：
```
【维度2：面部特征】
- 脸型：[脸型]，[具体描述]
- 眉：[眉形]，[颜色]，[描述]
- 眼：
  - 眼形：[眼形描述]
  - 眼色：[颜色]
  - 眼神：[温柔/凌厉/清澈/深邃/柔和]
- 鼻：[鼻形描述]
- 唇：[唇形]，[唇色]
- 肤：[肤色]，[肤质]
- 特殊标记：[特殊标记]
```

### 维度3-14：其他维度（按标准模板分析）

| 维度 | 名称 | 说明 |
|------|------|------|
| 3 | 服饰装扮 | 发型、上装、下装、鞋、妆容、配饰 |
| 4 | 道具设定 | 武器装备、工具器物、装饰物品 |
| 5 | 体态特征 | 身高、体重、体型、头身比 |
| 6 | 动作规范 | 站姿、坐姿、步态、手势 |
| 7 | 性格描述 | 核心性格、性格标签、优缺点 |
| 8 | 背景设定 | 童年、少年、青年、成年、家庭 |
| 9 | 色彩方案 | 主色调、辅助色、点缀色 |
| 10 | 风格标签 | 艺术风格、年代特征、文化风格 |
| 11 | 光线氛围 | 光线方向，光质、色温 |
| 12 | 构图设计 | 景别、视角、构图法则 |
| 13 | 质感表达 | 材质感、纹理感、厚重感 |
| 14 | 细节特征 | 特殊标记、习惯动作、口头禅 |

---

## 第三阶段：九宫格展示图提示词生成（面部重点版）

### 3.1 九宫格布局（面部重点版）

**核心改变**：面部特写从1张扩展到5张（正面x2 + 左侧 + 右侧 + 眼部）

```
┌─────────┬─────────┬─────────┐
│ 1正面脸 │ 2正面脸 │ 3左侧脸 │
│ 部柔表情│ 部情绪表│ 部特写  │
├─────────┼─────────┼─────────┤
│ 4右侧脸 │ 5正面半 │ 6眼部特 │
│ 部特写  │ 身照    │ 写      │
├─────────┼─────────┼─────────┤
│ 7正面全 │ 8背面全 │ 9配饰/手│
│ 身照    │ 身照    │ 部特写  │
└─────────┴─────────┴─────────┘
```

| 位置 | 内容 | 说明 | 优先级 |
|------|------|------|--------|
| 1 | 正面脸部（柔表情） | 面部正面，柔和表情 | **核心** |
| 2 | 正面脸部（情绪表情） | 面部正面，情绪表情 | **核心** |
| 3 | 左侧脸特写 | 左侧面部特写 | **核心** |
| 4 | 右侧脸特写 | 右侧面部特写 | **核心** |
| 5 | 正面半身照 | 腰部以上 | 高 |
| 6 | 眼部特写 | 眼睛细节 | **核心** |
| 7 | 正面全身照 | 全身 | 中 |
| 8 | 背面全身照 | 背面全身 | 低 |
| 9 | 配饰/手部特写 | 配饰或手部 | 低 |

### 3.2 九宫格提示词模板（白底标准·面部重点）

**重要**：所有提示词必须包含以下标准描述：
- `pure white seamless background`（纯白无缝背景）
- `studio soft lighting`（影棚柔光）
- `neutral studio backdrop`（中性影棚背景）

```markdown
## 二、九宫格展示图提示词（面部重点·白底标准）

### 【1】正面脸部特写（柔和表情）

**中文**：[年龄]岁[性别]，[脸型]，[眉眼鼻唇描述]，[肤色]，[柔和表情]
**英文**：`front-facing portrait of [character], close-up shot on face, [face shape], [eyebrows], [eyes], [nose], [lips], [skin tone], **gentle relaxed expression**, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【2】正面脸部特写（情绪表情）

**中文**：[年龄]岁[性别]，[脸型]，[眉眼鼻唇描述]，[肤色]，[具体情绪表情]
**英文**：`front-facing portrait of [character], close-up shot on face, [face shape], [eyebrows], [eyes], [nose], [lips], [skin tone], **[emotion] expression**, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【3】左侧脸特写

**中文**：[年龄]岁[性别]，[脸型]，左侧脸轮廓，[眉眼侧面描述]，[表情]
**英文**：`left side profile close-up of [character]'s face, [face shape], left cheekbone visible, [side eyebrow], [side eye], [nose profile], [skin tone], [expression], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【4】右侧脸特写

**中文**：[年龄]岁[性别]，[脸型]，右侧脸轮廓，[眉眼侧面描述]，[表情]
**英文**：`right side profile close-up of [character]'s face, [face shape], right cheekbone visible, [side eyebrow], [side eye], [nose profile], [skin tone], [expression], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【5】正面半身照

**中文**：正面半身照，[发型]，[上装]，[表情]，[核心配饰]
**英文**：`front view half-body portrait of [character], waist-up shot, [hairstyle], [upper outfit], [expression], [accessories], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【6】眼部特写

**中文**：眼部特写，[眼形]，[眼色]，[眼神]，[睫毛]，[眉毛描述]
**英文**：`extreme close-up portrait of [character]'s eyes, [eye shape], [eye color], **[intense/gentle/deep] gaze**, [eyelashes], [eyebrows], catch lights visible, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【7】正面全身照

**中文**：正面全身照，[发型]，[全套服装]，[鞋子]，[站姿]，[核心配饰]
**英文**：`front view full body shot of [character], standing pose, full body in frame, [hairstyle], [full outfit], [shoes], [pose], [accessories], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【8】背面全身照

**中文**：背面全身照，[发型背面]，[服装背面]，[整体轮廓]
**英文**：`back view full body shot of [character], back facing camera, full body in frame, [hair back], [outfit back], [overall silhouette], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【9】配饰/手部特写

**中文**：[配饰名称]特写，或手部特写 [手部描述]
**英文**：`close-up detail of [character]'s [accessory name], [accessory description], OR close-up of [character]'s hands, [hand description], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`
```

### 3.3 九宫格生成标准（白底摄影棚标准）

```
【白底摄影棚标准】：
- 背景：纯白无缝背景 #FFFFFF
- 灯光：影棚三灯布光，柔和散射
- 光质：软光，无硬阴影
- 色温：中性约5500K
- 主体：居中或三分法构图
- 面部：占画面60%以上（特写）
```

---

## 第四阶段：完整提示词输出（白底标准）

### 4.1 英文结构化提示词（面部重点·白底标准）

```json
{
  "character": "[角色名]",
  "main_prompt": "[角色描述], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "face_front_gentle": "[正面脸部-柔和表情], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "face_front_emotion": "[正面脸部-情绪表情], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "face_left_profile": "[左侧脸特写], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "face_right_profile": "[右侧脸特写], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "half_body": "[正面半身照], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "eye_extreme_closeup": "[眼部特写], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "full_body_front": "[正面全身照], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "full_body_back": "[背面全身照], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "accessory_hand_detail": "[配饰/手部特写], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic",
  "negative_prompt": "[负面提示词]",
  "parameters": {
    "aspect_ratio": "3:4",
    "style": "raw",
    "version": "7.0.0",
    "quality": "2"
  }
}
```

### 4.2 负面提示词标准

```
ugly, disfigured, bad anatomy, bad proportions,
extra limbs, missing limbs, floating limbs,
disconnected limbs, poorly drawn face,
mutation, mutated, ugly, disgusting,
bad hands, extra fingers, fewer fingers,
cross-eyed, wall-eyed, asymmetric eyes,
bad teeth, missing teeth, extra teeth,
bad skin, bad texture, bad complexion,
overly smooth skin, plastic skin,
blur, blurry, out of focus,
low resolution, pixelated,
watermark, text, logo, signature,
cropped, worst quality, low quality,
normal quality, jpeg artifacts,
different face, different eyes, different nose,
anime, cartoon, 3d render, cgi,
oversaturated, undersaturated,
**background with patterns, background with scenery, outdoor background, dark background, gradient background**
```

---

## 第五阶段：多态分析与变体提示词

### 5.1 多态识别

```markdown
## 四、多态分析

### 核心不可变特征（面部）
- 脸型：[描述]
- 眼形+眼色：[描述]
- 肤色：[描述]
- 鼻形：[描述]
- 唇形：[描述]

### 场景态变体

| 场景 | 发型 | 服装 | 表情 |
|------|------|------|------|
| 日常 | | | |
| 工作 | | | |
| 正式 | | | |

### 时间态变体

| 时间 | 发型 | 面容 | 气质 |
|------|------|------|------|
| 过去 | | | |
| 现在 | | | |

### 情绪态变体（重点）

| 情绪 | 眉部 | 眼部 | 唇部 | 整体表情 |
|------|------|------|------|----------|
| 中性 | | | | |
| 喜悦 | 眉舒展 | 眼弯 | 嘴角上扬 | 笑容 |
| 愤怒 | 眉紧锁 | 眼凌厉 | 唇抿紧 | 严肃 |
| 悲伤 | 眉微蹙 | 眼暗淡 | 嘴角下垂 | 忧郁 |
| 恐惧 | 眉上挑 | 眼睁大 | 唇微张 | 惊恐 |
| 惊讶 | 眉上抬 | 眼大睁 | 唇微张 | 诧异 |
| 冷漠 | 眉平 | 眼空洞 | 唇平直 | 木然 |

### 身份态变体

| 身份 | 服饰 | 言行 | 道具 |
|------|------|------|------|
| 职业身份 | | | |
| 家庭身份 | | | |
```

### 5.2 情绪态提示词生成（白底标准）

```markdown
### 【情绪态】中性表情

**英文**：`front-facing portrait of [character], close-up on face, [face shape], neutral expressionless face, relaxed brows, [eye color] eyes, [nose], [lip color] lips, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【情绪态】喜悦/微笑

**英文**：`front-facing portrait of [character], close-up on face, [face shape], **happy smile expression**, eyebrows relaxed, **[eye color] eyes with warmth**, soft smile showing [teeth/no teeth], **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【情绪态】愤怒

**英文**：`front-facing portrait of [character], close-up on face, [face shape], **angry expression**, furrowed brows, **[eye color] intense eyes**, tight lips, clenched jaw, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【情绪态】悲伤

**英文**：`front-facing portrait of [character], close-up on face, [face shape], **sad melancholic expression**, slightly furrowed brows, **[eye color] dim eyes**, downturned lips, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【情绪态】恐惧/惊恐

**英文**：`front-facing portrait of [character], close-up on face, [face shape], **fearful shocked expression**, raised eyebrows, **[eye color] wide eyes**, slightly open mouth, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【情绪态】惊讶

**英文**：`front-facing portrait of [character], close-up on face, [face shape], **surprised expression**, eyebrows raised, **[eye color] wide open eyes**, mouth slightly open, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【情绪态】冷漠/木然

**英文**：`front-facing portrait of [character], close-up on face, [face shape], **emotionless blank expression**, flat eyebrows, **[eye color] empty distant gaze**, straight neutral lips, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`
```

---

## 第六阶段：面部一致性规范

### 6.1 核心不可变面部特征

```markdown
## 五、一致性规范

### 核心不可变面部特征（必须保持一致）

| 特征 | 描述 | 跨状态一致性 |
|------|------|-------------|
| 脸型 | [脸型描述] | 绝对不变 |
| 眼形 | [眼形描述] | 绝对不变 |
| 眼色 | [眼色] | 绝对不变 |
| 肤色 | [肤色] | 绝对不变 |
| 鼻形 | [鼻形描述] | 绝对不变 |
| 唇形 | [唇形描述] | 绝对不变 |

### 可变特征（可随状态变化）

| 特征 | 变化范围 | 变化条件 |
|------|---------|---------|
| 表情 | 中性/喜悦/愤怒/悲伤/恐惧/惊讶/冷漠 | 随情绪变化 |
| 眉部状态 | 舒展/紧锁/上挑/平直 | 随表情变化 |
| 眼部状态 | 有神/暗淡/睁大/眯起 | 随情绪变化 |
| 唇部状态 | 抿紧/上扬/下垂/微张 | 随情绪变化 |
```

### 6.2 提示词一致性检查

```
生成提示词前检查：
1. [x] 脸型描述一致
2. [x] 眼形眼色描述一致
3. [x] 鼻形描述一致
4. [x] 唇形描述一致
5. [x] 肤色描述一致
6. [x] 背景均为"pure white seamless background"
7. [x] 灯光均为"studio soft lighting"
```

---

## 白底图标准规范

### 背景标准
- **纯白无缝背景**：#FFFFFF 或接近纯白
- 无阴影、无渐变、无图案
- 背景亮度均匀

### 灯光标准
- **影棚柔光**：使用散射光源，避免硬阴影
- **三灯布光**：
  - 主光：正面或侧正面
  - 补光：对侧，约45度
  - 轮廓光：背面，分离主体与背景

### 面部拍摄标准
- 面部占画面60%以上（特写）
- 眼睛位于画面中央或三分线
- 保持眼神清晰
- 适当虚化背景（但仍为纯白）

### 技术参数
- **相机**：全画幅单反/微单
- **镜头**：85mm定焦（人像）
- **光圈**：f/4 - f/5.6
- **快门**：1/125s - 1/200s
- **ISO**：100

---

## FAQ 与反模式

> **📌 完整FAQ文档**：本章节为FAQ摘要，完整常见问题解答请查看 `FAQ.md` 独立文档

### 常见问题速查

| 问题类型 | 快速答案 |
|----------|----------|
| 剧本太短 | 至少200字，用detailed模式 |
| 面部不一致 | 锁定核心不可变特征 |
| 格式不对 | 指定format参数 |
| 缺少变体 | 补充场景/情绪描述 |
| 白底有阴影 | 确保使用pure white seamless background |

### 完整FAQ内容

完整常见问题解答（20个问题）已移至独立文档 `FAQ.md`，包含：

**基础问题**
- Q1: 这个技能是做什么的？
- Q2: 如何快速开始使用？
- Q3: 支持哪些分析模式？

**输入问题**
- Q4: 输入剧本需要多长？
- Q5: 角色描述不完整怎么办？
- Q6: 支持哪些语言？
- Q7: 一次能分析多少角色？

**输出问题**
- Q8: 输出格式有哪些？
- Q9: 九宫格是什么？
- Q10: 什么是白底图标准？

**一致性问题**
- Q11: 如何确保AI生成的角色面部一致？
- Q12: 多场景下服装变化如何保持一致？
- Q13: 情绪变化时面部如何描述？

**技术问题**
- Q14: 分析失败了怎么办？
- Q15: 分析结果不稳定怎么办？
- Q16: 角色面部不一致怎么办？

**场景问题**
- Q17: 古装角色分析有什么注意点？
- Q18: 科幻角色分析有什么注意点？
- Q19: 儿童角色分析有什么注意点？
- Q20: 老年角色分析有什么注意点？

### ❌ 错误用法

- **错误1**：跳过面部核心特征提取，直接生成全身提示词
  - 问题：导致角色面部在后续生成中不稳定

- **错误2**：使用"beautiful face"等模糊描述
  - 问题：AI对"美丽"的理解可能与预期不符

- **错误3**：在不同提示词中使用不同的面部描述
  - 问题：破坏角色一致性，导致"换脸"

- **错误4**：忽略负面提示词
  - 问题：容易出现多余肢体、畸形手指等

- **错误5**：情绪态描述过于简单（如只用"happy"）
  - 问题：AI可能生成意料外的表情

### ✅ 正确用法

- **正确1**：详细提取并锁定所有面部核心特征
  - 效果：确保角色在不同场景/情绪下面部一致

- **正确2**：使用精确的解剖学描述
  - 示例："almond eyes"而非"beautiful eyes"

- **正确3**：建立完整的情绪态描述矩阵
  - 效果：每种情绪都有精确的面部描述

- **正确4**：添加完整的负面提示词
  - 效果：减少AI生成中的常见错误

- **正确5**：九宫格首张使用最标准的正面照
  - 效果：后续生成有高质量参考

---

## 限制与注意事项

1. **语言限制**：目前仅支持中文和英文剧本
2. **维度限制**：部分维度可能因剧本描述不足而"未明确"
3. **一致性边界**：AI绘图工具对面部一致性的支持程度不同
4. **版权注意**：生成的角色提示词仅供个人/项目使用
5. **稳定性保证**：本技能经过多次测试验证，稳定可靠
6. **可靠性说明**：具备完善的错误处理和重试机制
7. **一致性保障**：通过核心不可变特征确保跨状态一致性
8. **准确性保证**：基于十四维度专业分析，确保输出质量
9. **可用性**：开箱即用，输出可直接用于AI绘图工具

---

## 相关资源

### 核心文档
- `FAQ.md` - **常见问题解答（独立文档，方便快速查找）**
- `references/character-profile-template.md` - 角色原型档案模板
- `references/prompt-templates.md` - 提示词模板库（面部重点版）
- `references/checklist.md` - 一致性检查清单
- `references/multi-state-analysis.md` - 多态分析详解
- `references/nine-grid-template.md` - 九宫格模板（面部重点版）

### 示例文档
- `examples/示例1-职场女性角色.md` - 现代职场女性角色
- `examples/示例2-古装男性角色.md` - 古装书生角色
- `examples/示例3-科幻角色.md` - 科幻赛博角色
- `examples/示例4-儿童角色.md` - 儿童角色
- `examples/示例5-老年角色.md` - 老年角色
- `examples/示例6-复杂古装女性角色.md` - 复杂宫斗题材
- `examples/示例7-复杂科幻角色.md` - 复杂星际战争题材

---

## 跨平台兼容性

本技能完全跨平台兼容：

| Agent | 支持状态 | 说明 |
|-------|----------|------|
| Claude Code | ✅ 完全兼容 | 原生支持 |
| Codex | ✅ 完全兼容 | 原生支持 |
| Copilot | ✅ 完全兼容 | 原生支持 |
| 其他Agent | ✅ 通用兼容 | 使用标准工作流 |

| 操作系统 | 支持状态 | 说明 |
|-----------|----------|------|
| macOS | ✅ 完全支持 | 跨平台Python |
| Linux | ✅ 完全支持 | 跨平台Python |
| Windows | ✅ 完全支持 | 跨平台Python |

---

## 🎯 最佳实践速查

### 场景推荐对照表

| 你的需求 | 推荐模式 | 推荐格式 | 原因 |
|----------|----------|----------|------|
| 快速预览角色 | quick | markdown | 5维度，30秒完成 |
| 标准分析大多数剧本 | standard | markdown | 14维度，平衡深度和速度 |
| 重要角色深度分析 | detailed | json | 最完整，包含推测补充 |
| 批量生成多角色 | standard分批 | json | 每批≤20个角色 |
| 验证已有分析结果 | quick | markdown | 快速检查一致性 |

### 问题排查速查

| 问题现象 | 第一步 | 第二步 | 第三步 |
|----------|--------|--------|--------|
| 面部不一致 | 检查核心特征是否锁定 | 对比所有提示词描述 | 添加负面提示词 |
| 剧本太短 | 补充角色描述 | 用detailed模式 | 提供更多细节 |
| 风格不对 | 检查白底标准 | 确认灯光描述 | 调整相机参数 |
| 分析失败 | 检查网络 | 减少角色数 | 换个模式重试 |
| 超时 | 分段分析 | 减少角色数 | 等待后重试 |

### 九宫格使用指南

```
┌─────────────────────────────────────────────────────┐
│                   九宫格正确用法                      │
├─────────────────────────────────────────────────────┤
│                                                     │
│  1. 先用1-6锁定面部特征（核心）                      │
│  2. 再用7-9补充全身/背面的参考                       │
│  3. 首张（1号）是后续生成的主参考图                   │
│  4. 保持所有提示词中核心特征一致                      │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 🚀 快速使用模板

> 以下是常用的使用示例，直接复制修改即可使用

### 模板1：标准分析（最常用）

```
请分析以下剧本，生成角色原型深度分析报告：

[粘贴500字以上的剧本内容]
```

### 模板2：指定模式分析

```json
{
  "script": "[粘贴剧本内容]",
  "mode": "detailed",
  "format": "json"
}
```

### 模板3：批量角色分析

```
请分析以下剧本中的所有角色，使用standard模式，输出JSON格式：

[粘贴包含多角色的剧本内容]
```

### 模板4：单角色深度分析

```
请对以下剧本进行detailed模式的深度角色分析，重点关注面部特征：

[粘贴剧本内容]
```

### 模板5：生成九宫格提示词

```
请为以下角色生成九宫格AI绘图提示词（白底标准）：

[角色描述：包括年龄、性别、脸型、五官特征、肤色等]
```

---

## 📊 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 7.0.0 | 2026-05-25 | 版本统一 + 能力边界明确 + 参数校验 + 熔断机制 |
| 6.0.0 | 2026-05-25 | TRACE五维评测 + FAQ + 安全检测 |
| 5.0.0 | 2026-05-23 | 十四维度 + 面部重点九宫格 + 情绪态模板 |
| 1.0.0 | 2026-05-23 | 初始版本（九维度） |

---

**文档版本**：7.0.0
**更新日期**：2026-05-25
**核心升级**：参数校验 + 熔断机制 + 最佳实践速查 + 快速使用模板
