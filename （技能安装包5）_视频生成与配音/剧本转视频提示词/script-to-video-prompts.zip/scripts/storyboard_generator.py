#!/usr/bin/env python3
"""
分镜提示词生成器 (v2) - 基于叙事节拍智能拆解生成逐镜AI视频提示词
核心改进: 从剧本原文中提取叙事节拍 (narrative beats), 每个节拍映射1-3镜
"""

import re
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum


class ShotSize(Enum):
    """景别"""
    ECU = "extreme close-up"
    CU = "close-up"
    MCU = "medium close-up"
    MS = "medium shot"
    MLS = "medium long shot"
    LS = "long shot"
    ELS = "extreme long shot"
    OTS = "over-the-shoulder"
    POV = "point of view"
    TWO_SHOT = "two shot"
    GROUP = "group shot"
    INSERT = "insert shot"


class CameraMovement(Enum):
    """运镜方式"""
    STATIC = "static"
    PAN = "pan"
    TILT = "tilt"
    PUSH = "push in"
    PULL = "pull out"
    DOLLY = "dolly"
    TRACK = "tracking"
    CRANE = "crane"
    HANDHELD = "handheld"
    STEADICAM = "steadicam"
    ZOOM = "zoom"
    WHIP_PAN = "whip pan"
    ORBIT = "orbit"
    SLOW_PUSH = "slow push in"


class Transition(Enum):
    """转场方式"""
    CUT = "cut"
    FADE = "fade"
    DISSOLVE = "dissolve"
    WIPE = "wipe"
    MATCH_CUT = "match cut"
    JUMP_CUT = "jump cut"
    L_CUT = "L-cut"
    J_CUT = "J-cut"
    SMASH_CUT = "smash cut"


@dataclass
class NarrativeBeat:
    """叙事节拍 - 剧本文本中的最小叙事单元"""
    text_segment: str            # 原文片段
    beat_type: str               # action/dialogue/reaction/description/transition
    characters_involved: List[str]
    emotion: str                 # 主导情绪
    intensity: float = 1.0       # 情绪强度 0-1
    suggested_duration: float = 3.0
    is_key_moment: bool = False  # 是否为关键情绪转折点


@dataclass
class Shot:
    """单个镜头"""
    shot_id: str
    scene_number: int
    shot_number: int
    shot_size: str
    camera_movement: str
    subject: str
    action: str
    dialogue: str = ""
    mood: str = ""
    duration: float = 3.0
    transition: str = "cut"
    composition_notes: str = ""
    lighting_notes: str = ""
    audio_notes: str = ""
    visual_prompt: str = ""


@dataclass
class Storyboard:
    """分镜脚本"""
    title: str
    shots: List[Shot] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)


# ──────────────────────────────────────────────
# 叙事节拍拆解器
# ──────────────────────────────────────────────

class NarrativeBeatParser:
    """将自由格式剧本文本拆解为叙事节拍"""

    # 情绪关键词 → 强度
    EMOTION_INTENSITY = {
        "泪": 0.9, "哭": 0.9, "泣": 0.9, "崩溃": 1.0, "嘶喊": 1.0,
        "笑": 0.6, "微笑": 0.4, "莞尔": 0.3, "嘴角上扬": 0.3,
        "怒": 0.8, "吼": 0.9, "摔": 0.9, "砸": 0.9,
        "惊": 0.7, "愕": 0.7, "呆": 0.6, "怔": 0.6,
        "抱": 0.7, "拥抱": 0.7, "相拥": 0.8, "搂": 0.6,
        "触": 0.5, "碰": 0.4, "握": 0.5, "牵": 0.6,
        "转身": 0.5, "离开": 0.6, "远去": 0.7, "走": 0.3,
        "看": 0.3, "凝视": 0.5, "望着": 0.5, "对视": 0.7,
        "退": 0.4, "跑": 0.7, "冲": 0.8, "追": 0.8,
        "等": 0.3, "等待": 0.4, "守候": 0.5,
    }

    # 情绪词匹配 (用于给 beat 打情绪标签)
    EMOTION_TAGS = {
        "温柔": "gentle", "温暖": "warm", "柔和": "soft",
        "悲伤": "sad", "难过": "sad", "忧伤": "melancholic",
        "紧张": "tense", "焦虑": "anxious", "不安": "uneasy",
        "浪漫": "romantic", "甜蜜": "sweet", "心动": "heart-fluttering",
        "孤独": "lonely", "寂寞": "lonely", "独": "lonely",
        "感动": "touching", "触动": "moved",
        "疏离": "distant", "陌生": "strange",
        "期待": "hopeful", "等待": "waiting",
    }

    # 动作关键词 → (景别, 运镜, 建议时长)
    ACTION_CAMERA_MAP = {
        "眼神": (ShotSize.ECU, CameraMovement.SLOW_PUSH, 2.5),
        "对视": (ShotSize.CU, CameraMovement.STATIC, 3.0),
        "指尖": (ShotSize.ECU, CameraMovement.STATIC, 2.0),
        "手": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "微微一笑": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "微笑": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "低头": (ShotSize.MCU, CameraMovement.TILT, 2.0),
        "抬起头": (ShotSize.CU, CameraMovement.TILT, 2.0),
        "抬头": (ShotSize.CU, CameraMovement.TILT, 2.0),
        "转身": (ShotSize.MLS, CameraMovement.PAN, 2.5),
        "离开": (ShotSize.LS, CameraMovement.STATIC, 3.0),
        "抱": (ShotSize.MCU, CameraMovement.PUSH, 3.5),
        "拥抱": (ShotSize.MS, CameraMovement.PUSH, 4.0),
        "擦": (ShotSize.ECU, CameraMovement.STATIC, 1.5),
        "拿出": (ShotSize.CU, CameraMovement.STATIC, 1.5),
        "站在": (ShotSize.MLS, CameraMovement.STATIC, 2.5),
        "走出": (ShotSize.LS, CameraMovement.DOLLY, 3.0),
        "踏上": (ShotSize.MLS, CameraMovement.DOLLY, 2.5),
        "推开": (ShotSize.MS, CameraMovement.STATIC, 2.0),
        "放下": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "递给": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "接过": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "坐下": (ShotSize.MS, CameraMovement.STATIC, 2.5),
        "跑": (ShotSize.LS, CameraMovement.TRACK, 3.0),
        "追": (ShotSize.MLS, CameraMovement.TRACK, 3.0),
        "走进": (ShotSize.MLS, CameraMovement.DOLLY, 3.0),
        "倒下": (ShotSize.LS, CameraMovement.CRANE, 3.0),
        "坠落": (ShotSize.ELS, CameraMovement.TILT, 3.0),
        "睁眼": (ShotSize.ECU, CameraMovement.STATIC, 1.5),
        "闭眼": (ShotSize.CU, CameraMovement.STATIC, 2.0),
        "呼": (ShotSize.CU, CameraMovement.STATIC, 1.5),
        "叹气": (ShotSize.MCU, CameraMovement.STATIC, 2.0),
        "耳语": (ShotSize.MCU, CameraMovement.STATIC, 3.0),
        "说话": (ShotSize.MCU, CameraMovement.STATIC, 3.0),
        "说": (ShotSize.MCU, CameraMovement.STATIC, 3.0),
    }

    # 角色名匹配 (中文2-6字人名)
    NAME_PATTERN = re.compile(r'[\u4e00-\u9fa5]{2,6}')

    def __init__(self, character_names: List[str]):
        self.characters = character_names or []
        self._char_set = set(self.characters)

    def parse(self, text: str) -> List[NarrativeBeat]:
        """
        将叙事文本拆解为节拍序列。
        策略:
        1. 按自然句边界 (。！？…) 分段
        2. 含引号段判断为对话
        3. 含已知角色名且有动作词的判断为角色beat
        4. 纯描述为环境/建立beat
        """
        beats = []
        # 按句号/感叹号/问号分段，但保留短句合并
        raw_segments = re.split(r'[。！？\n](?=\s*[\u4e00-\u9fa5\"\'])', text)
        raw_segments = [s.strip() for s in raw_segments if s.strip()]

        for seg in raw_segments:
            if len(seg) < 2:
                continue

            beat = self._classify_segment(seg)
            if beat:
                beats.append(beat)

        # 情绪强度平滑：相邻节拍之间如果出现突变，平滑过渡
        self._smooth_intensity(beats)

        return beats

    def _classify_segment(self, text: str) -> Optional[NarrativeBeat]:
        """对一个文本片段分类"""
        # 对话检测：包含引号且内容较短
        dialogue_match = re.findall(r'["\u201c]([^"\u201d]+)["\u201d]', text)
        if dialogue_match:
            dlg = dialogue_match[0]
            chars = self._find_characters_in_text(text)
            return NarrativeBeat(
                text_segment=text,
                beat_type="dialogue",
                characters_involved=chars,
                emotion=self._detect_emotion(dlg),
                intensity=0.4,
                suggested_duration=max(2.0, len(dlg) * 0.2),
            )

        # 动作描述：含角色名 + 动作词
        chars_in_text = self._find_characters_in_text(text)
        action_keywords = self._find_action_keywords(text)

        if chars_in_text and action_keywords:
            return NarrativeBeat(
                text_segment=text,
                beat_type="action",
                characters_involved=chars_in_text,
                emotion=self._detect_emotion(text),
                intensity=self._detect_intensity(text),
                suggested_duration=self._estimate_action_duration(text, action_keywords),
                is_key_moment=self._is_key_moment(text),
            )

        # 纯描述/场景建立
        if len(text) > 10:
            return NarrativeBeat(
                text_segment=text,
                beat_type="description",
                characters_involved=[],
                emotion=self._detect_emotion(text),
                intensity=0.2,
                suggested_duration=2.0,
            )

        return None

    def _find_characters_in_text(self, text: str) -> List[str]:
        """在文本中查找已知角色名"""
        found = []
        for ch in self.characters:
            if ch in text:
                found.append(ch)
        return found

    def _find_action_keywords(self, text: str) -> List[str]:
        """查找文本中的动作关键词"""
        return [kw for kw in self.ACTION_CAMERA_MAP if kw in text]

    def _detect_emotion(self, text: str) -> str:
        """检测文本中的主导情绪"""
        scores: Dict[str, float] = {}
        for cn_tag, en_tag in self.EMOTION_TAGS.items():
            if cn_tag in text:
                scores[en_tag] = scores.get(en_tag, 0) + 1

        # 也检查动作词的情绪
        for kw, intensity in self.EMOTION_INTENSITY.items():
            if kw in text and intensity > 0.6:
                # 高强度动作通常暗示强烈情绪
                if intensity >= 0.8:
                    return "intense"

        if scores:
            return max(scores, key=scores.get)  # type: ignore[arg-type]
        return "neutral"

    def _detect_intensity(self, text: str) -> float:
        """检测情绪强度"""
        scores = []
        for kw, intensity in self.EMOTION_INTENSITY.items():
            if kw in text:
                scores.append(intensity)
        if scores:
            return sum(scores) / len(scores)
        return 0.3

    def _is_key_moment(self, text: str) -> bool:
        """判断是否为关键情绪转折点"""
        high_intensity = any(
            self.EMOTION_INTENSITY.get(kw, 0) >= 0.7 for kw in text
        )
        return high_intensity

    def _estimate_action_duration(self, text: str, keywords: List[str]) -> float:
        """估算动作镜头时长"""
        durations = [
            self.ACTION_CAMERA_MAP[kw][2]
            for kw in keywords if kw in self.ACTION_CAMERA_MAP
        ]
        if durations:
            return sum(durations) / len(durations)
        return 2.5

    def _smooth_intensity(self, beats: List[NarrativeBeat]):
        """平滑情绪强度过渡"""
        if len(beats) < 3:
            return
        for i in range(1, len(beats) - 1):
            prev_i = beats[i - 1].intensity
            cur_i = beats[i].intensity
            next_i = beats[i + 1].intensity
            if abs(cur_i - prev_i) > 0.4 and abs(cur_i - next_i) > 0.4:
                beats[i].intensity = (prev_i + next_i) / 2


# ──────────────────────────────────────────────
# 分镜生成器 (重写版)
# ──────────────────────────────────────────────

class StoryboardGenerator:
    """将叙事节拍映射为分镜镜头"""

    def __init__(self):
        self.shots: List[Shot] = []
        self.shot_counter: Dict[int, int] = {}
        self.prev_shot_size: Optional[str] = None  # 用于避免连续同景别

    def generate_from_parsed_script(
        self,
        parsed_script: Dict,
        scene_analyses: List[Dict],
        character_profiles: Dict[str, Dict]
    ) -> Storyboard:
        """主入口：从解析后的剧本生成分镜"""
        title = parsed_script.get("title", "Untitled")
        character_names = parsed_script.get("all_characters", [])
        beat_parser = NarrativeBeatParser(character_names)

        scene_analysis_map = {
            sa["scene_number"]: sa for sa in scene_analyses
        }

        for scene in parsed_script.get("scenes", []):
            scene_num = scene.get("number", 0)
            scene_analysis = scene_analysis_map.get(scene_num, {})

            # 获取剧本原始文本
            raw_text = scene.get("raw_text", "")
            actions = scene.get("actions", [])
            dialogues = scene.get("dialogues", [])

            # 拼接场景全文供节拍解析
            full_text = raw_text or " ".join(actions + dialogues)

            if full_text.strip():
                self._generate_from_beats(
                    scene_num=scene_num,
                    beats=beat_parser.parse(full_text),
                    scene_analysis=scene_analysis,
                    character_profiles=character_profiles,
                    scene=scene,
                )
            else:
                # fallback: 无文本内容时用旧版模板
                self._generate_fallback_shots(
                    scene_num=scene_num,
                    scene=scene,
                    scene_analysis=scene_analysis,
                    character_profiles=character_profiles,
                )

        return Storyboard(
            title=title,
            shots=self.shots,
            metadata={
                "total_shots": len(self.shots),
                "total_scenes": len(parsed_script.get("scenes", [])),
                "estimated_duration": sum(s.duration for s in self.shots),
            }
        )

    def _generate_from_beats(
        self,
        scene_num: int,
        beats: List[NarrativeBeat],
        scene_analysis: Dict,
        character_profiles: Dict[str, Dict],
        scene: Dict,
    ):
        """从叙事节拍生成镜头 (核心方法)"""
        self.shot_counter.setdefault(scene_num, 0)

        env = scene_analysis.get("environment", {})
        visual_base = scene_analysis.get("visual_prompt", "")
        mood_keywords = scene_analysis.get("mood_keywords", [])
        weather = scene.get("weather", "")

        # 1. 建立镜头 (Establishing Shot) — 始终打头
        self._add_establishing_shot(scene_num, env, visual_base, mood_keywords, weather)

        # 2. 逐节拍映射
        for beat in beats:
            if beat.beat_type == "description":
                self._add_description_shot(scene_num, beat, env, visual_base)
            elif beat.beat_type == "action":
                self._add_action_shot(scene_num, beat, env, visual_base, character_profiles)
            elif beat.beat_type == "dialogue":
                self._add_dialogue_shot(scene_num, beat, env, visual_base, character_profiles)

        # 3. 如果有双人以上互动，插入过肩/反应镜头
        characters_in_scene = scene.get("characters", [])
        if len(characters_in_scene) >= 2:
            self._inject_reaction_shots(scene_num, characters_in_scene, env, visual_base, character_profiles)

        # 4. 收尾镜头 (情绪落脚)
        if beats and beats[-1].intensity >= 0.6:
            self._add_closing_shot(scene_num, beats[-1], env, visual_base, mood_keywords)

    def _add_establishing_shot(self, scene_num, env, visual_base, mood_keywords, weather):
        """添加场景建立镜头"""
        is_ext = env.get("int_ext") == "EXT"
        shot_size = ShotSize.LS.value if is_ext else ShotSize.MLS.value
        location = env.get("location_type", "location")
        mood_str = ", ".join(mood_keywords[:2]) if mood_keywords else ""
        weather_str = f", {weather} weather" if weather else ""

        self._add_shot(
            scene_num=scene_num,
            shot_size=shot_size,
            camera_movement=CameraMovement.STATIC.value,
            subject=f"establishing shot of {location}",
            action="场景建立",
            mood=mood_str,
            duration=3.0,
            visual_prompt=f"establishing wide shot of {location}{weather_str}, {visual_base}, cinematic, atmospheric",
        )

    def _add_description_shot(self, scene_num, beat, env, visual_base):
        """描述性段落 → 环境/空镜"""
        text = beat.text_segment[:80]
        self._add_shot(
            scene_num=scene_num,
            shot_size=ShotSize.LS.value,
            camera_movement=CameraMovement.DOLLY.value,
            subject="environment",
            action=text,
            mood=beat.emotion,
            duration=beat.suggested_duration,
            visual_prompt=f"{text}, {visual_base}, {beat.emotion} atmosphere",
        )

    def _add_action_shot(self, scene_num, beat, env, visual_base, character_profiles):
        """动作节拍 → 角色镜头"""
        text = beat.text_segment
        action_kws = NarrativeBeatParser(self._get_all_chars())._find_action_keywords(text)  # type: ignore[arg-type]

        # 确定景别和运镜
        if action_kws:
            shot_size, camera_mv, dur = NarrativeBeatParser.ACTION_CAMERA_MAP[action_kws[0]]
        else:
            shot_size, camera_mv, dur = ShotSize.MS, CameraMovement.STATIC, 2.5

        shot_size = shot_size.value
        camera_mv = camera_mv.value

        # 避免连续同景别 (连续同景别→切更宽或更近)
        if shot_size == self.prev_shot_size:
            shift_map = {
                "medium shot": "medium close-up", "medium close-up": "close-up",
                "close-up": "extreme close-up", "long shot": "medium shot",
                "medium long shot": "long shot", "extreme long shot": "long shot",
            }
            shot_size = shift_map.get(shot_size, shot_size)
        self.prev_shot_size = shot_size

        # 角色视觉描述
        chars = beat.characters_involved
        char_visual = ""
        if chars and chars[0] in character_profiles:
            char_visual = character_profiles[chars[0]].get("prompt_description", chars[0])
        subject = chars[0] if chars else "character"
        char_visual = char_visual or subject

        # 是否为关键情绪时刻 → 加特效
        is_key = beat.is_key_moment
        emphasis = ", slow motion, emotional peak" if is_key and beat.intensity >= 0.7 else ""

        # 构建 visual_prompt
        prompt = f"{shot_size} of {char_visual}, {text[:60]}{emphasis}, {visual_base}"
        if beat.emotion and beat.emotion != "neutral":
            prompt += f", {beat.emotion} mood"

        is_first_action = self.shot_counter.get(scene_num, 0) <= 2

        self._add_shot(
            scene_num=scene_num,
            shot_size=shot_size,
            camera_movement=camera_mv,
            subject=subject,
            action=text[:100],
            mood=beat.emotion,
            duration=dur if not is_key else dur * 1.3,
            visual_prompt=prompt,
            composition_notes="key emotional beat" if is_key else "",
        )

    def _add_dialogue_shot(self, scene_num, beat, env, visual_base, character_profiles):
        """对话节拍 → 中近景/双人镜"""
        chars = beat.characters_involved
        text = beat.text_segment

        if len(chars) >= 2:
            shot_size = ShotSize.TWO_SHOT.value
            subject = f"{chars[0]} and {chars[1]}"
            camera_mv = CameraMovement.STATIC.value
        elif len(chars) == 1:
            shot_size = ShotSize.MCU.value
            subject = chars[0]
            camera_mv = CameraMovement.SLOW_PUSH.value
        else:
            shot_size = ShotSize.MCU.value
            subject = "character speaking"
            camera_mv = CameraMovement.STATIC.value

        # 提取对话内容
        dialogue_text = re.findall(r'["\u201c]([^"\u201d]+)["\u201d]', text)
        dialogue = dialogue_text[0] if dialogue_text else ""

        char_visual = ""
        if chars and chars[0] in character_profiles:
            char_visual = character_profiles[chars[0]].get("prompt_description", "")

        prompt = f"{shot_size}, {char_visual or subject}, speaking{' softly' if beat.emotion in ('gentle','soft','tender') else ''}, {visual_base}"

        self._add_shot(
            scene_num=scene_num,
            shot_size=shot_size,
            camera_movement=camera_mv,
            subject=subject,
            action=text[:100],
            dialogue=dialogue,
            mood=beat.emotion,
            duration=beat.suggested_duration,
            visual_prompt=prompt,
        )

    def _inject_reaction_shots(self, scene_num, characters, env, visual_base, character_profiles):
        """在双人戏中插入反应镜头"""
        existing_subjects = {s.subject for s in self.shots if s.scene_number == scene_num}

        for ch in characters[:2]:
            if ch not in existing_subjects:
                continue
            char_visual = character_profiles.get(ch, {}).get("prompt_description", ch)

            self._add_shot(
                scene_num=scene_num,
                shot_size=ShotSize.CU.value,
                camera_movement=CameraMovement.STATIC.value,
                subject=ch,
                action=f"{ch} reaction shot",
                mood="",
                duration=2.0,
                visual_prompt=f"close-up reaction shot of {char_visual}, subtle expression, {visual_base}",
            )

    def _add_closing_shot(self, scene_num, last_beat, env, visual_base, mood_keywords):
        """添加情绪落脚镜头"""
        mood_str = ", ".join(mood_keywords[:2]) if mood_keywords else ""
        emotion = last_beat.emotion

        self._add_shot(
            scene_num=scene_num,
            shot_size=ShotSize.LS.value,
            camera_movement=CameraMovement.PULL.value,
            subject="environment",
            action=f"场景收尾 - {emotion}",
            mood=emotion,
            duration=3.0,
            visual_prompt=f"wide shot pulling back, {emotion} atmosphere, {visual_base}, {mood_str}, cinematic",
            transition=Transition.DISSOLVE.value if last_beat.intensity >= 0.7 else Transition.CUT.value,
        )

    def _generate_fallback_shots(self, scene_num, scene, scene_analysis, character_profiles):
        """fallback: 没有可解析文本时使用旧版模板"""
        characters = scene.get("characters", [])
        env = scene_analysis.get("environment", {})
        visual_base = scene_analysis.get("visual_prompt", "")
        mood_keywords = scene_analysis.get("mood_keywords", [])

        self.shot_counter.setdefault(scene_num, 0)

        is_ext = env.get("int_ext") == "EXT"
        self._add_shot(scene_num, ShotSize.LS.value if is_ext else ShotSize.MLS.value,
                       CameraMovement.STATIC.value,
                       f"establishing shot of {env.get('location_type', 'location')}",
                       "场景建立", "", 3.0,
                       f"establishing shot, {visual_base}, cinematic")

        for ch in characters[:2]:
            char_visual = character_profiles.get(ch, {}).get("prompt_description", ch)
            self._add_shot(scene_num, ShotSize.MS.value, CameraMovement.STATIC.value,
                           ch, f"{ch} on screen", "",
                           2.0, f"medium shot of {char_visual}, {visual_base}")

        if len(characters) >= 2:
            self._add_shot(scene_num, ShotSize.TWO_SHOT.value, CameraMovement.STATIC.value,
                           f"{characters[0]} and {characters[1]}", "对话", "",
                           4.0, f"two shot conversation, {visual_base}")

    def _get_all_chars(self) -> List[str]:
        """从已有镜头中收集所有角色名 (辅助)"""
        chars = set()
        for s in self.shots:
            if s.subject and s.subject != "environment" and s.subject != "character":
                for ch in s.subject.split(" and "):
                    if ch.strip():
                        chars.add(ch.strip())
        return list(chars)

    def _add_shot(
        self,
        scene_num: int,
        shot_size: str,
        camera_movement: str,
        subject: str,
        action: str,
        mood: str,
        duration: float,
        visual_prompt: str,
        dialogue: str = "",
        transition: str = "cut",
        composition_notes: str = "",
        lighting_notes: str = "",
    ):
        self.shot_counter[scene_num] = self.shot_counter.get(scene_num, 0) + 1
        shot_num = self.shot_counter[scene_num]

        shot = Shot(
            shot_id=f"{scene_num}-{shot_num}",
            scene_number=scene_num,
            shot_number=shot_num,
            shot_size=shot_size,
            camera_movement=camera_movement,
            subject=subject,
            action=action,
            dialogue=dialogue,
            mood=mood,
            duration=duration,
            transition=transition,
            composition_notes=composition_notes,
            lighting_notes=lighting_notes,
            visual_prompt=visual_prompt,
        )
        self.shots.append(shot)

    def to_dict(self, storyboard: Storyboard) -> Dict:
        return {
            "title": storyboard.title,
            "metadata": storyboard.metadata,
            "shots": [
                {
                    "shot_id": s.shot_id,
                    "scene_number": s.scene_number,
                    "shot_number": s.shot_number,
                    "shot_size": s.shot_size,
                    "camera_movement": s.camera_movement,
                    "subject": s.subject,
                    "action": s.action,
                    "dialogue": s.dialogue,
                    "mood": s.mood,
                    "duration": s.duration,
                    "transition": s.transition,
                    "composition_notes": s.composition_notes,
                    "lighting_notes": s.lighting_notes,
                    "audio_notes": s.audio_notes,
                    "visual_prompt": s.visual_prompt,
                }
                for s in storyboard.shots
            ],
        }


def generate_storyboard(
    parsed_script: Dict,
    scene_analyses: List[Dict],
    character_profiles: Dict[str, Dict],
) -> Dict:
    generator = StoryboardGenerator()
    storyboard = generator.generate_from_parsed_script(
        parsed_script, scene_analyses, character_profiles
    )
    return generator.to_dict(storyboard)


if __name__ == "__main__":
    print("StoryboardGenerator v2 loaded.")
    print("Usage: from storyboard_generator import generate_storyboard")
