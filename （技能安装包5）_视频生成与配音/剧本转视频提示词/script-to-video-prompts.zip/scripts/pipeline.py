#!/usr/bin/env python3
"""
pipeline.py - 端到端流水线编排器
串联 6 步: parse → character → scene → storyboard → optimize → consistency → export

Usage:
    python pipeline.py <script.txt> [--output-dir <dir>] [--formats json,csv,md,html,excel]

Examples:
    python pipeline.py 雨天站台.txt -o output/
    python pipeline.py my_script.docx -o output/ --formats json,md,html
"""

import sys
import json
import argparse
import io
from pathlib import Path
from typing import Dict, List, Optional

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# 确保脚本目录在 path 中
SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from parse_script import ScriptParser
from character_extractor import CharacterExtractor
from scene_analyzer import SceneAnalyzer
from storyboard_generator import StoryboardGenerator
from prompt_optimizer import PromptOptimizer
from consistency_checker import ConsistencyChecker
from export_utils import ExportUtils


def run_pipeline(
    script_path: str,
    output_dir: str,
    formats: Optional[List[str]] = None,
) -> Dict:
    """
    端到端流水线

    Args:
        script_path: 剧本文件路径
        output_dir: 输出目录
        formats: 导出格式列表

    Returns:
        完整的流水线输出字典
    """
    if formats is None:
        formats = ["json", "csv", "md", "html"]

    print(f"[PIPELINE] Script: {script_path}")
    print(f"[PIPELINE] Output: {output_dir}")
    print()

    # -- Step 1: Parse --
    print("[1/6] Parse script...")
    parser = ScriptParser()
    parsed = parser.parse_file(script_path)
    parsed_dict = {
        "title": parsed.title,
        "metadata": parsed.metadata,
        "total_duration_seconds": parsed.total_duration,
        "all_characters": parsed.all_characters,
        "all_locations": parsed.all_locations,
        "scenes": [s.to_dict() for s in parsed.scenes],
    }
    print(f"   OK {len(parsed.scenes)} scenes, {len(parsed.all_characters)} chars, "
          f"{parsed.total_duration:.0f}s estimated")

    # -- Step 2: Character extraction --
    print("[2/6] Extract characters...")
    char_extractor = CharacterExtractor()
    characters = char_extractor.extract_from_parsed_script(parsed_dict)
    for name, info in characters.items():
        desc = info.get("prompt_description", "")
        keywords = info.get("visual_keywords", [])
        props = info.get("props", [])
        extras = []
        if keywords:
            extras.append(f"{len(keywords)} keywords")
        if props:
            extras.append(f"props: {', '.join(props)}")
        extra_str = f" ({', '.join(extras)})" if extras else ""
        print(f"   OK {name}: {desc}{extra_str}")

    # -- Step 3: Scene analysis --
    print("[3/6] Analyze scenes...")
    scene_analyzer = SceneAnalyzer()
    scenes = scene_analyzer.analyze_all_scenes(parsed_dict)
    for s in scenes:
        env = s.get("environment", {})
        weather_str = f" [{env.get('weather', '')}]" if env.get("weather") else ""
        print(f"   OK Scene {s['scene_number']}: {env.get('location_type', '?')} "
              f"({env.get('int_ext', '?')}, {env.get('time_of_day', '?')}){weather_str}")

    # -- Step 4: Storyboard generation --
    print("[4/6] Generate storyboard...")
    story_gen = StoryboardGenerator()
    storyboard_obj = story_gen.generate_from_parsed_script(parsed_dict, scenes, characters)
    storyboard = story_gen.to_dict(storyboard_obj)
    print(f"   OK {storyboard['metadata']['total_shots']} shots, "
          f"{storyboard['metadata']['estimated_duration']:.0f}s total")

    # -- Step 5: Prompt optimization --
    print("[5/6] Optimize prompts...")
    optimizer = PromptOptimizer()
    storyboard = optimizer.optimize_storyboard(storyboard)
    avg_score = (
        sum(s.get("prompt_quality_score", 0) for s in storyboard.get("shots", []))
        / max(len(storyboard.get("shots", [])), 1)
    )
    print(f"   OK average quality score: {avg_score:.2f}/1.0")

    # -- Step 6: Consistency check --
    print("[6/6] Consistency check...")
    checker = ConsistencyChecker()
    consistency = checker.check_consistency(storyboard, characters, scenes)
    issues = consistency.get("issues", [])
    errors = [i for i in issues if i.get("severity") == "error"]
    warnings = [i for i in issues if i.get("severity") == "warning"]
    print(f"   OK {len(errors)} errors, {len(warnings)} warnings")
    if warnings:
        for w in warnings[:3]:
            print(f"     WARNING [{w['type']}] {w['description']}")

    # -- Export --
    print()
    print("Exporting...")
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # 构建完整导出数据
    export_data = {
        "storyboard": storyboard,
        "characters": characters,
        "scenes": scenes,
    }

    exported = {}
    title = parsed_dict.get("title", "storyboard")

    for fmt in formats:
        if fmt == "json":
            path = ExportUtils.export_to_json(export_data, str(output_path / f"{title}.json"))
            exported["json"] = path
        elif fmt == "csv":
            path = ExportUtils.export_to_csv(storyboard.get("shots", []), str(output_path / f"{title}.csv"))
            exported["csv"] = path
        elif fmt == "md":
            path = ExportUtils.export_to_markdown(storyboard, characters, scenes, str(output_path / f"{title}.md"))
            exported["md"] = path
        elif fmt == "excel":
            try:
                path = ExportUtils.export_to_excel(storyboard, characters, scenes, str(output_path / f"{title}.xlsx"))
                exported["excel"] = path
            except ImportError:
                print("   SKIP Excel export (openpyxl not installed)")
        elif fmt == "html":
            path = ExportUtils.export_to_html(storyboard, characters, scenes, str(output_path / f"{title}.html"))
            exported["html"] = path

    # 单独导出一致性报告
    consistency_path = ExportUtils.export_to_json(
        consistency, str(output_path / f"{title}_consistency.json")
    )
    exported["consistency"] = consistency_path

    for fmt, path in exported.items():
        print(f"   OK {fmt:>12}: {path}")

    # -- Summary --
    print()
    print("=" * 50)
    print("PIPELINE COMPLETE")
    print(f"   Script: {title}")
    print(f"   Scenes: {len(scenes)} | Characters: {len(characters)} | Shots: {storyboard['metadata']['total_shots']}")
    print(f"   Duration: {storyboard['metadata']['estimated_duration']:.0f}s")
    print(f"   Prompt quality: {avg_score:.2f}/1.0")
    print(f"   Consistency: {len(errors)} errors, {len(warnings)} warnings")
    print("=" * 50)

    return {
        "parsed": parsed_dict,
        "characters": characters,
        "scenes": scenes,
        "storyboard": storyboard,
        "consistency": consistency,
        "exported_files": exported,
    }


def main():
    parser = argparse.ArgumentParser(
        description="剧本→视频提示词 端到端流水线",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python pipeline.py 雨天站台.txt
  python pipeline.py my_script.docx -o output/
  python pipeline.py script.pdf -o output/ --formats json,md,html
        """
    )
    parser.add_argument("script", help="剧本文本文件 (.txt/.md/.docx/.pdf/.fdx)")
    parser.add_argument("-o", "--output-dir", default="output", help="输出目录 (默认: output)")
    parser.add_argument("--formats", default="json,csv,md,html",
                        help="导出格式,逗号分隔 (默认: json,csv,md,html)")

    args = parser.parse_args()
    formats = [f.strip() for f in args.formats.split(",")]

    if not Path(args.script).exists():
        print(f"❌ 文件不存在: {args.script}")
        sys.exit(1)

    run_pipeline(args.script, args.output_dir, formats)


if __name__ == "__main__":
    main()
