#!/usr/bin/env python3
"""
场景分析器 - 分析剧本场景并生成场景设定提示词
包括环境、光线、氛围等视觉要素分析
"""

import re
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum


class TimeOfDay(Enum):
    """时间段"""
    DAWN = "dawn"           # 黎明
    MORNING = "morning"     # 早晨
    DAY = "day"             # 白天
    AFTERNOON = "afternoon" # 下午
    DUSK = "dusk"           # 黄昏
    EVENING = "evening"     # 傍晚
    NIGHT = "night"         # 夜晚
    MIDNIGHT = "midnight"   # 深夜


class LightingType(Enum):
    """光线类型"""
    NATURAL = "natural"           # 自然光
    ARTIFICIAL = "artificial"     # 人造光
    MIXED = "mixed"               # 混合光
    LOW_KEY = "low_key"           # 低调光
    HIGH_KEY = "high_key"         # 高调光
    DRAMATIC = "dramatic"         # 戏剧性光
    SOFT = "soft"                 # 柔光
    HARD = "hard"                 # 硬光


@dataclass
class LightingSetup:
    """光线设置"""
    type: str = "natural"
    direction: str = "front"      # front/side/back/top/bottom
    intensity: str = "medium"     # low/medium/high
    color_temperature: str = "neutral"  # warm/neutral/cool
    quality: str = "soft"         # soft/hard
    sources: List[str] = field(default_factory=list)


@dataclass
class SceneEnvironment:
    """场景环境设定"""
    location_type: str = ""       # 地点类型
    location_name: str = ""       # 具体地点名
    int_ext: str = "INT"          # 室内/室外
    time_of_day: str = "DAY"      # 时间
    weather: str = ""             # 天气
    season: str = ""              # 季节
    spatial_layout: str = ""      # 空间布局描述
    key_props: List[str] = field(default_factory=list)  # 关键道具
    background_elements: List[str] = field(default_factory=list)  # 背景元素
    lighting: LightingSetup = field(default_factory=LightingSetup)
    color_palette: List[str] = field(default_factory=list)  # 色彩基调
    mood: str = ""                # 氛围
    atmosphere_keywords: List[str] = field(default_factory=list)


@dataclass
class SceneAnalysis:
    """场景分析结果"""
    scene_number: int
    scene_heading: str
    environment: SceneEnvironment
    visual_prompt: str = ""
    mood_keywords: List[str] = field(default_factory=list)


class SceneAnalyzer:
    """场景分析器"""

    # 地点类型映射 (扩展至80+常用场景)
    LOCATION_TYPES = {
        # 室内场所
        "办公室": ("office", "INT", ["desk", "computer", "chair", "documents"]),
        "卧室": ("bedroom", "INT", ["bed", "nightstand", "wardrobe", "lamp"]),
        "客厅": ("living room", "INT", ["sofa", "coffee table", "TV", "bookshelf"]),
        "厨房": ("kitchen", "INT", ["stove", "refrigerator", "counter", "cabinets"]),
        "餐厅": ("dining room", "INT", ["dining table", "chairs", "chandelier"]),
        "浴室": ("bathroom", "INT", ["sink", "mirror", "bathtub", "toilet"]),
        "教室": ("classroom", "INT", ["desks", "blackboard", "podium", "chairs"]),
        "医院": ("hospital", "INT", ["hospital bed", "medical equipment", "white walls"]),
        "咖啡厅": ("cafe", "INT", ["coffee machines", "tables", "warm lighting"]),
        "咖啡馆": ("cafe", "INT", ["coffee machines", "tables", "warm lighting"]),
        "咖啡店": ("cafe", "INT", ["coffee machines", "tables", "warm lighting"]),
        "酒吧": ("bar", "INT", ["bar counter", "bottles", "dim lighting", "stools"]),
        "商场": ("mall", "INT", ["shops", "escalators", "bright lights"]),
        "电梯": ("elevator", "INT", ["metal walls", "buttons", "confined space"]),
        "走廊": ("hallway", "INT", ["doors", "fluorescent lights", "long perspective"]),
        "图书馆": ("library", "INT", ["bookshelves", "reading tables", "quiet"]),
        "会议室": ("conference room", "INT", ["table", "screen", "chairs"]),
        "实验室": ("laboratory", "INT", ["equipment", "white coats", "test tubes"]),
        "健身房": ("gym", "INT", ["exercise equipment", "mirrors", "weights"]),
        "便利店": ("convenience store", "INT", ["shelves", "counter", "bright lights"]),
        "超市": ("supermarket", "INT", ["aisles", "shelves", "shopping carts"]),
        "药店": ("pharmacy", "INT", ["medicine shelves", "counter", "white"]),
        "地铁站": ("subway station", "INT", ["platform", "tracks", "tunnel"]),
        "仓库": ("warehouse", "INT", ["shelves", "crates", "dim lighting"]),
        "车库": ("garage", "INT", ["cars", "tools", "concrete floor"]),
        "阁楼": ("attic", "INT", ["wood beams", "dust", "old boxes"]),
        "地下室": ("basement", "INT", ["concrete walls", "dim", "pipes"]),

        # 室外场所
        "街道": ("street", "EXT", ["buildings", "cars", "pedestrians", "streetlights"]),
        "马路": ("street", "EXT", ["buildings", "cars", "pedestrians", "streetlights"]),
        "公园": ("park", "EXT", ["trees", "benches", "grass", "paths"]),
        "海滩": ("beach", "EXT", ["sand", "waves", "ocean", "sky"]),
        "山": ("mountain", "EXT", ["peaks", "rocks", "clouds", "vegetation"]),
        "森林": ("forest", "EXT", ["trees", "leaves", "shadows", "nature"]),
        "停车场": ("parking lot", "EXT", ["cars", "concrete", "lights"]),
        "天台": ("rooftop", "EXT", ["city view", "sky", "railings"]),
        "校园": ("campus", "EXT", ["buildings", "students", "trees", "paths"]),
        "站台": ("train platform", "EXT", ["tracks", "benches", "station sign", "canopy"]),
        "月台": ("train platform", "EXT", ["tracks", "benches", "station sign", "canopy"]),
        "广场": ("public square", "EXT", ["open space", "fountain", "benches"]),
        "桥": ("bridge", "EXT", ["railings", "water below", "sky"]),
        "天桥": ("overpass", "EXT", ["railings", "traffic below", "city view"]),
        "桥洞": ("underpass", "EXT", ["concrete", "echo", "dim"]),
        "河边": ("riverside", "EXT", ["water", "bank", "trees"]),
        "湖边": ("lakeside", "EXT", ["lake", "shore", "reflection"]),
        "田野": ("field", "EXT", ["grass", "sky", "open space"]),
        "花园": ("garden", "EXT", ["flowers", "paths", "greenery"]),
        "阳台": ("balcony", "EXT", ["railings", "city view", "sky"]),
        "码头": ("dock", "EXT", ["water", "boats", "wooden planks"]),
        "庭院": ("courtyard", "EXT", ["walls", "plants", "sky"]),
        "篮球场": ("basketball court", "EXT", ["hoop", "lines", "fence"]),
        "足球场": ("soccer field", "EXT", ["grass", "goalposts", "lines"]),
        "操场": ("playground", "EXT", ["swings", "slides", "sand"]),

        # 建筑物
        "酒店": ("hotel", "INT", ["lobby", "reception desk", "elevators"]),
        "饭店": ("restaurant", "INT", ["tables", "kitchen", "dining area"]),
        "电影院": ("cinema", "INT", ["screen", "seats", "dark"]),
        "剧院": ("theater", "INT", ["stage", "seats", "curtains"]),
        "教堂": ("church", "INT", ["pews", "altar", "stained glass"]),
        "寺庙": ("temple", "INT", ["incense", "statues", "offerings"]),
        "火车站": ("train station", "INT", ["ticket counter", "waiting area", "schedule board"]),
        "机场": ("airport", "INT", ["check-in counters", "departure board", "runway view"]),
    }

    # 时间到光线的映射
    TIME_TO_LIGHTING = {
        "DAWN": {
            "type": "natural",
            "color_temperature": "warm",
            "intensity": "low",
            "quality": "soft",
            "description": "golden hour, soft warm light, long shadows"
        },
        "MORNING": {
            "type": "natural",
            "color_temperature": "neutral",
            "intensity": "medium",
            "quality": "soft",
            "description": "bright morning light, fresh atmosphere"
        },
        "DAY": {
            "type": "natural",
            "color_temperature": "neutral",
            "intensity": "high",
            "quality": "hard",
            "description": "bright daylight, clear visibility"
        },
        "AFTERNOON": {
            "type": "natural",
            "color_temperature": "warm",
            "intensity": "medium",
            "quality": "soft",
            "description": "warm afternoon light, relaxed mood"
        },
        "DUSK": {
            "type": "natural",
            "color_temperature": "warm",
            "intensity": "low",
            "quality": "soft",
            "description": "golden hour, orange and pink hues, dramatic shadows"
        },
        "EVENING": {
            "type": "mixed",
            "color_temperature": "warm",
            "intensity": "low",
            "quality": "soft",
            "description": "twilight, artificial lights starting, blue hour"
        },
        "NIGHT": {
            "type": "artificial",
            "color_temperature": "cool",
            "intensity": "low",
            "quality": "hard",
            "description": "night scene, artificial lighting, dark atmosphere"
        },
    }

    # 天气关键词
    WEATHER_KEYWORDS = {
        "晴": ("sunny", ["bright", "clear sky", "sunshine"]),
        "阴": ("overcast", ["cloudy", "gray sky", "diffused light"]),
        "雨": ("rainy", ["rain", "wet surfaces", "reflections", "umbrellas"]),
        "雪": ("snowy", ["snow", "white", "cold", "winter"]),
        "雾": ("foggy", ["fog", "mist", "low visibility", "mysterious"]),
        "风": ("windy", ["wind", "movement", "flowing"]),
        "暴风雨": ("stormy", ["storm", "dark clouds", "lightning", "dramatic"]),
    }

    # 氛围关键词
    MOOD_MAPPINGS = {
        "紧张": ["tense", "suspenseful", "dark shadows", "high contrast"],
        "温馨": ["warm", "cozy", "soft lighting", "comfortable"],
        "浪漫": ["romantic", "soft focus", "warm colors", "intimate"],
        "恐怖": ["horror", "dark", "shadows", "eerie", "unsettling"],
        "悲伤": ["melancholic", "muted colors", "overcast", "somber"],
        "欢乐": ["joyful", "bright", "vibrant colors", "lively"],
        "神秘": ["mysterious", "fog", "shadows", "enigmatic"],
        "压抑": ["oppressive", "claustrophobic", "dark", "heavy"],
    }

    def __init__(self):
        self.scenes: List[SceneAnalysis] = []

    def analyze_scene(self, scene_data: Dict) -> SceneAnalysis:
        """分析单个场景"""
        scene_num = scene_data.get("number", 0)
        heading = scene_data.get("heading", "")
        location = scene_data.get("location", "")
        time_of_day = scene_data.get("time_of_day", "DAY").upper()
        int_ext = scene_data.get("int_ext", "INT.")

        # 创建环境设定
        environment = SceneEnvironment()
        environment.location_name = location
        environment.int_ext = "INT" if "INT" in int_ext.upper() else "EXT"
        environment.time_of_day = time_of_day

        # 分析地点类型
        for cn_name, (en_name, default_int_ext, props) in self.LOCATION_TYPES.items():
            if cn_name in location:
                environment.location_type = en_name
                environment.key_props = props.copy()
                break

        if not environment.location_type:
            environment.location_type = location

        # 如果 location 是 UNKNOWN，从剧本原文推断
        if not environment.location_type or environment.location_type == location:
            raw_text = scene_data.get("raw_text", "")
            if raw_text:
                inferred = self._infer_location_from_text(raw_text)
                if inferred:
                    environment.location_type = inferred[0]
                    environment.key_props = list(inferred[1])
                    environment.int_ext = inferred[2]

        # 天气/季节 (从 parse_script 传入的 scene 数据中读取)
        environment.weather = scene_data.get("weather", "")
        environment.season = scene_data.get("season", "")

        # 设置光线 (如果天气是雨天则用阴天光线)
        lighting_info = dict(self.TIME_TO_LIGHTING.get(time_of_day, self.TIME_TO_LIGHTING["DAY"]))
        if environment.weather in ("rainy", "stormy", "overcast"):
            lighting_info["quality"] = "soft"
            lighting_info["intensity"] = "low"
            lighting_info["description"] += ", overcast rainy atmosphere"
        elif environment.weather == "foggy":
            lighting_info["quality"] = "soft"
            lighting_info["description"] += ", misty atmosphere"
        environment.lighting = LightingSetup(
            type=lighting_info["type"],
            color_temperature=lighting_info["color_temperature"],
            intensity=lighting_info["intensity"],
            quality=lighting_info["quality"]
        )

        # 生成视觉提示词
        visual_prompt = self._generate_visual_prompt(environment, lighting_info)

        # 生成氛围关键词
        mood_keywords = self._infer_mood_keywords(environment)

        return SceneAnalysis(
            scene_number=scene_num,
            scene_heading=heading,
            environment=environment,
            visual_prompt=visual_prompt,
            mood_keywords=mood_keywords
        )

    def analyze_all_scenes(self, parsed_script: Dict) -> List[Dict]:
        """分析所有场景"""
        results = []

        for scene_data in parsed_script.get("scenes", []):
            analysis = self.analyze_scene(scene_data)
            results.append(self._to_dict(analysis))

        return results

    def _generate_visual_prompt(self, env: SceneEnvironment, lighting_info: Dict) -> str:
        """生成场景视觉提示词"""
        parts = []

        # 基础场景
        if env.int_ext == "INT":
            parts.append(f"interior of {env.location_type}")
        else:
            parts.append(f"exterior {env.location_type}")

        # 光线描述
        parts.append(lighting_info.get("description", ""))

        # 关键道具
        if env.key_props:
            parts.append(f"with {', '.join(env.key_props[:3])}")

        # 天气(不仅室外)
        if env.weather:
            parts.append(env.weather)

        return ", ".join(filter(None, parts))

    def _infer_location_from_text(self, text: str) -> Optional[Tuple[str, List[str], str]]:
        """从剧本文本推断地点"""
        # Check against location dictionary
        for cn_name, (en_name, int_ext, props) in self.LOCATION_TYPES.items():
            if cn_name in text:
                return (en_name, list(props), int_ext)

        # Heuristic: check for outdoor indicators
        outdoor_keywords = ["街道", "路边", "站台", "月台", "站", "马路边", "广场"]
        for kw in outdoor_keywords:
            if kw in text:
                return ("street scene", ["buildings", "sky"], "EXT")

        return None

    def _infer_mood_keywords(self, env: SceneEnvironment) -> List[str]:
        """推断氛围关键词"""
        keywords = []

        # 根据时间推断
        time_moods = {
            "NIGHT": ["mysterious", "quiet", "dark"],
            "DAWN": ["hopeful", "fresh", "new beginning"],
            "DUSK": ["romantic", "nostalgic", "transitional"],
        }
        keywords.extend(time_moods.get(env.time_of_day, []))

        # 根据地点推断
        location_moods = {
            "hospital": ["clinical", "sterile", "tense"],
            "bar": ["relaxed", "social", "dim"],
            "beach": ["peaceful", "open", "free"],
            "forest": ["natural", "serene", "mysterious"],
        }
        keywords.extend(location_moods.get(env.location_type, []))

        return keywords[:5]  # 限制数量

    def _to_dict(self, analysis: SceneAnalysis) -> Dict:
        """转换为字典"""
        env = analysis.environment
        return {
            "scene_number": analysis.scene_number,
            "scene_heading": analysis.scene_heading,
            "environment": {
                "location_type": env.location_type,
                "location_name": env.location_name,
                "int_ext": env.int_ext,
                "time_of_day": env.time_of_day,
                "weather": env.weather,
                "season": env.season,
                "key_props": env.key_props,
                "lighting": {
                    "type": env.lighting.type,
                    "color_temperature": env.lighting.color_temperature,
                    "intensity": env.lighting.intensity,
                    "quality": env.lighting.quality,
                },
                "color_palette": env.color_palette,
                "mood": env.mood,
            },
            "visual_prompt": analysis.visual_prompt,
            "mood_keywords": analysis.mood_keywords,
        }


def analyze_scenes(parsed_script: Dict) -> List[Dict]:
    """
    分析剧本场景的便捷函数

    Args:
        parsed_script: parse_script.py 的输出结果

    Returns:
        场景分析结果列表
    """
    analyzer = SceneAnalyzer()
    return analyzer.analyze_all_scenes(parsed_script)


if __name__ == "__main__":
    # 示例用法
    sample_script = {
        "scenes": [
            {
                "number": 1,
                "heading": "INT. 办公室 - DAY",
                "location": "办公室",
                "time_of_day": "DAY",
                "int_ext": "INT."
            },
            {
                "number": 2,
                "heading": "EXT. 公园 - DUSK",
                "location": "公园",
                "time_of_day": "DUSK",
                "int_ext": "EXT."
            },
            {
                "number": 3,
                "heading": "INT. 咖啡厅 - NIGHT",
                "location": "咖啡厅",
                "time_of_day": "NIGHT",
                "int_ext": "INT."
            }
        ]
    }

    results = analyze_scenes(sample_script)
    print(json.dumps(results, ensure_ascii=False, indent=2))
