# 阿拉丁·AI短剧视频生成工坊 — 平台参数对照（provider-params）

> 渐进式披露：决定"投哪个平台 / 调什么参数"时加载本文件。
> 本技能**仅生成参数配置文本，不调用任何 API、不联网、不花钱**。以下参数为各平台公开网页端/API 的常用取值，供 prompt 与参数对齐参考。

## 一、五平台参数速查表

| 平台 | slug | 默认模型 | 默认比例 | 默认时长(s) | 引导值(guidance) | 提示词语种 | 擅长 |
|------|------|----------|----------|-------------|------------------|------------|------|
| 即梦 | jimeng | 即梦 v2.0 / Dreamina | 9:16 | 5 | 6.5 | 中文 | 国风/写实、中文语义强 |
| 可灵 | kling | 可灵 v1.6 / Kling | 9:16 | 5 | 0.7 | 中文 | 物理运动自然、长镜头 |
| Runway | runway | Gen-3 Alpha | 16:9 | 4 | 7.0 | 英文 | 电影质感、镜头语言 |
| Seedance | seedance | Seedance 1.0 | 9:16 | 5 | 6.0 | 中文 | 多镜头一致性、运镜 |
| Pika | pika | Pika 1.5 | 9:16 | 4 | 7.5 | 英文 | 特效/风格化、创意 |

> 引导值语义：即梦/Runway/Pika/Seedance 多为"越高越贴近提示词"；可灵 `guidance` 为 0~1 区间（越接近 1 越贴词）。本技能按平台给默认值，可在平台端自行微调。

## 二、比例（ratio）建议

| 用途 | 推荐 ratio | 适用平台 |
|------|-----------|----------|
| 抖音 / 视频号 / 快手 竖屏 | 9:16 | 全部 |
| B站 / YouTube 横版 | 16:9 | runway（默认）、其余可覆盖 |
| 方形信息流 | 1:1 | 任意（平台端改） |

- 脚本可在 `shot.ratio` 字段覆盖默认；不写则取平台默认。

## 三、时长（duration）映射

- `shot.duration` 直接映射为视频 prompt 的"时长约 N 秒"与平台 `duration` 字段。
- 未写 `shot.duration` 时取平台默认（见上表）。
- 提示：即梦/可灵/Seedance 支持 5~10s，Runway/Pika 常见 4~10s，超长建议拆 shot。

## 四、seed 说明

- `reproducible`（默认）：`seed = int(sha256(shot.id)[:8], 16) % 1_000_000`，同一脚本可复算、可返工对齐。
- `random`：每次运行重新随机（可加 `--seed-base` 固定随机源）。
- 把 seed 填进平台"种子/Seed"框即可复现本技能的构图设想。

## 五、负向提示词（neg_prompt）

各平台通用负向词（中文平台中文、英文平台英文，本技能自动匹配）：
- 中文：模糊，低分辨率，变形，多余肢体，水印，文字乱码，过曝，拼接痕迹，低质 3D
- 英文：blurry, low resolution, deformed, extra limbs, watermark, gibberish text, overexposed, artifacts, low quality 3D

## 六、投递流程（手动）

1. 打开目标平台网页端 → 文生视频 / 图生视频。
2. 从 `prompts.csv` 或 `gen_panel.html` 复制 `image_prompt`（先生图）与 `video_prompt`（再生视频）。
3. 填入 `ratio` / `duration` / `seed` / `guidance`（来自本技能输出）。
4. 粘贴 `neg_prompt` 到负向框。
5. 成片交给 `aladin-drama-edit` 按 `shot.id` 对齐剪辑。
