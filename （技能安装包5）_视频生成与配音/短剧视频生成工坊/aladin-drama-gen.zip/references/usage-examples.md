# 阿拉丁·AI短剧视频生成工坊 — 用法示例（usage-examples）

> 渐进式披露：仅当你需要"完整落地参考 / 最佳实践 / 排错"时加载本文件。

## 场景 1：单平台快速出片（默认即梦）

把 `aladin-drama-script` 产出的 `script.json` 直接转成即梦可用的 prompt：

```bash
PY="C:/Users/adam/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SKILL="<本技能目录>"
"$PY" "$SKILL/scripts/gen_prompts.py" --script ./script.json --provider jimeng --out ./build
"$PY" "$SKILL/scripts/gen_plan.py"   --prompts ./build/<title>_prompts_raw.json --out ./build
"$PY" "$SKILL/scripts/gen_report.py" --prompts ./build/<title>_prompts_raw.json \
       --plan ./build/<title>_plan.json --out ./build
```

产物：`_<title>_prompts.json`（丢给 `aladin-drama-edit`）、`prompts.csv`（批量复制）、`gen_panel.html`（可视化面板）。

## 场景 2：多平台一次性批量生成

一次产出即梦 / 可灵 / Seedance 三套参数，直接横向对比：

```bash
"$PY" "$SKILL/scripts/gen_prompts.py" --script ./script.json \
       --providers jimeng,kling,seedance --out ./build
```

CSV 里每个 shot 会展开成 3 行（每平台一行），可直接分别粘贴到三家网页端。

## 场景 3：指定统一风格（如"水墨国风"）

覆盖脚本内所有 shot 的 style，做整片统一调性：

```bash
"$PY" "$SKILL/scripts/gen_prompts.py" --script ./script.json \
       --providers jimeng,runway --style "水墨国风，留白意境" --out ./build
```

## 场景 4：可复现 vs 随机 seed

- 默认 `reproducible`：seed 由 `shot.id` 派生（SHA256 取模），同一脚本重复跑结果一致，便于返工对齐。
- 想要每次不一样的构图：`--seed-mode random`（可加 `--seed-base 42` 固定随机源）。

```bash
"$PY" "$SKILL/scripts/gen_prompts.py" --script ./script.json \
       --seed-mode random --seed-base 7 --out ./build
```

## 最佳实践

1. **先定脚本，再定平台**：`script.json` 的质量决定 prompt 质量，分镜越细，prompt 越准。
2. **9:16 竖屏优先**：短视频平台（抖音/视频号）默认 9:16；做 PC 横版再切 `--provider runway`（默认 16:9）。
3. **用 CSV 批量投递**：把 `prompts.csv` 按列复制到各平台批量任务框，省去逐条手敲。
4. **用面板复核**：`gen_panel.html` 可离线打开，按 shot/平台切换，确认 `image_prompt` 与 `video_prompt` 后再投递。
5. **缺失资源先补**：`gen_plan.py` 会列出"无 image/video prompt"的 shot，先回脚本工坊补分镜再生成。

## FAQ

- **Q：`_prompts.json` 和 `_prompts_raw.json` 区别？**
  A：`_raw` 是中间产物（含全部平台 gen 字典）；`<title>_prompts.json` 是最终交付（aladin-drama-edit 的输入），结构更扁平、含 plan 摘要。
- **Q：Runway/Pika 中文 prompt 能用吗？**
  A：本技能对 runway/pika 默认输出英文 `image_prompt`/`video_prompt`（中文平台仍输出中文），并始终附带 `*_zh` / `*_en` 双版本，按需取用。
- **Q：会调用付费 API 吗？**
  A：不会。脚本只生成"参数配置 + 提示词文本"，不联网、不调任何 API、不花钱。投递到各平台由你手动完成。
- **Q：shot 没有 character 怎么办？**
  A：自动置为"无人"，prompt 中不含人物描述，适合空镜/环境镜头。
