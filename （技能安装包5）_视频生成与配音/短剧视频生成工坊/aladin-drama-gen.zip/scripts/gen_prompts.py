#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""aladin-drama-gen · gen_prompts
把 script.json 的每个 shot 变成可丢给即梦/可灵/Runway/Seedance/Pika 的
生图 prompt + 生视频 prompt + 负向 prompt + 平台参数。
零依赖（仅 Python 标准库），离线可用，不调任何付费 API。
"""
import argparse
import hashlib
import json
import os
import random
import re
import sys

# ---------------------------------------------------------------------------
# 平台默认参数（仅生成"参数配置"，不调用任何 API / 不联网 / 不花钱）
# ---------------------------------------------------------------------------
PROVIDERS = {
    "jimeng":  {"label": "即梦(jimeng)",  "model": "即梦 v2.0 / Dreamina", "ratio": "9:16", "duration": 5, "guidance": 6.5, "lang": "zh"},
    "kling":   {"label": "可灵(kling)",   "model": "可灵 v1.6 / Kling",    "ratio": "9:16", "duration": 5, "guidance": 0.7, "lang": "zh"},
    "runway":  {"label": "Runway",        "model": "Runway Gen-3 Alpha",   "ratio": "16:9", "duration": 4, "guidance": 7.0, "lang": "en"},
    "seedance":{"label": "Seedance",      "model": "Seedance 1.0",         "ratio": "9:16", "duration": 5, "guidance": 6.0, "lang": "zh"},
    "pika":    {"label": "Pika",          "model": "Pika 1.5",             "ratio": "9:16", "duration": 4, "guidance": 7.5, "lang": "en"},
}
DEFAULT_PROVIDER = "jimeng"

# 镜头运动映射：中文名 -> (英文运镜, 中文说明)
CAMERA_MAP = {
    "推镜头": ("push in / dolly in", "镜头缓慢向前推进，主体逐渐放大"),
    "拉镜头": ("pull out / dolly out", "镜头向后拉远，主体逐渐缩小"),
    "摇镜头": ("pan", "镜头水平摇移，展示横向空间"),
    "移镜头": ("lateral tracking", "镜头横向平移，跟随主体移动"),
    "跟镜头": ("follow / tracking shot", "镜头跟随主体同步运动"),
    "升降镜头": ("crane / jib up-down", "镜头升降运动，俯仰视角变化"),
    "固定": ("static / locked-off", "固定机位，画面稳定不运动"),
    "环绕": ("orbit / 360", "镜头环绕主体做圆周运动"),
    "俯拍": ("top-down / overhead", "俯视角度，居高临下"),
    "仰拍": ("low angle / tilt up", "仰视角度，主体显得高大"),
    "手持": ("handheld", "手持微晃，增强真实临场感"),
}
DEFAULT_CAMERA = ("static / locked-off", "固定机位，画面稳定不运动")

# 时间段 -> 光线描述（中/英）
TIME_LIGHT = {
    "day":     ("明亮自然光，柔和日光，通透干净", "bright soft daylight, clean and clear"),
    "night":   ("低照度夜景，霓虹与台灯补光，强明暗对比", "low-key night, neon and lamp practicals, high contrast"),
    "dusk":    ("黄昏暖光，长投影，氛围暧昧", "golden dusk, long shadows, warm mood"),
    "dawn":    ("清晨冷调薄雾光线，清新空灵", "cold dawn mist, fresh ethereal light"),
    "indoor":  ("室内暖色灯光，层次柔和", "warm interior lighting, soft layers"),
    "rain":    ("雨天冷调，水面反光与雨丝质感", "rainy cold tone, wet reflections and rain streaks"),
}
DEFAULT_TIME = ("自然光，层次分明", "natural light, clear layers")

QUALITY_ZH = "8k 分辨率，电影级画质，细腻质感，高动态范围，锐利对焦，胶片颗粒"
QUALITY_EN = "8k resolution, cinematic quality, fine texture, HDR, sharp focus, film grain"

NEG_ZH = "模糊，低分辨率，变形，多余肢体，水印，文字乱码，过曝，拼接痕迹，低质 3D"
NEG_EN = "blurry, low resolution, deformed, extra limbs, watermark, gibberish text, overexposed, artifacts, low quality 3D"

# 英文技术词表（用于 best-effort 英译，free text 保留原文）
EN_DICT = {
    "推镜头": "push in", "拉镜头": "pull out", "摇镜头": "pan", "移镜头": "tracking",
    "跟镜头": "follow", "固定": "static", "环绕": "orbit", "俯拍": "top-down", "仰拍": "low angle",
    "电影感": "cinematic", "写实": "realistic", "动画": "animated", "动漫": "anime",
    "悬疑": "suspenseful", "紧张": "tense", "温馨": "warm", "欢乐": "cheerful",
    "悲伤": "sad", "恐怖": "horror", "科幻": "sci-fi", "古风": "ancient style",
}


def slugify(text):
    text = (text or "").strip().lower()
    text = re.sub(r"[^a-z0-9\u4e00-\u9fa5]+", "_", text)
    return text.strip("_") or "drama"


def resolve_providers(args):
    if args.providers:
        return [p.strip() for p in args.providers.split(",") if p.strip()]
    if args.provider:
        return [p.strip() for p in args.provider.split(",") if p.strip()]
    return [DEFAULT_PROVIDER]


def make_seed(shot_id, seed_mode, seed_base):
    if seed_mode == "random":
        rnd = random.Random()
        if seed_base is not None:
            rnd.seed(seed_base)
        return rnd.randint(0, 999999)
    h = hashlib.sha256((shot_id or "shot").encode("utf-8")).hexdigest()
    return int(h[:8], 16) % 1000000


def en_tech(zh_tokens):
    """把结构化中文技术词 best-effort 译成英文，自由文本原样保留。"""
    out = []
    for tok in zh_tokens:
        out.append(EN_DICT.get(tok, tok))
    return ", ".join(out)


def iter_shots(doc):
    for ep in doc.get("episodes", []):
        for sc in ep.get("scenes", []):
            for sh in sc.get("shots", []):
                yield ep, sc, sh


def build_gen(shot, scene, ep, project, provider, args):
    p = PROVIDERS[provider]
    # 风格解析：参数 > shot > scene > episode > project > 默认
    style = (args.style or shot.get("style") or scene.get("style")
             or ep.get("style") or project.get("style") or "电影感写实")
    time = scene.get("time") or ep.get("time") or "day"
    mood = shot.get("mood") or scene.get("mood") or ep.get("mood") or "neutral"
    cam_zh = shot.get("camera", "固定")
    cam_en, cam_desc = CAMERA_MAP.get(cam_zh, DEFAULT_CAMERA)

    characters = shot.get("character") or []
    subject = "、".join(characters) if characters else "无人"
    action = shot.get("action", "")
    scene_desc = shot.get("scene_desc") or scene.get("location", "未知道景")
    light_zh, light_en = TIME_LIGHT.get(time, DEFAULT_TIME)
    duration = shot.get("duration") or p["duration"]
    ratio = shot.get("ratio") or p["ratio"]
    seed = make_seed(shot.get("id", scene_desc), args.seed_mode, args.seed_base)
    guidance = p["guidance"]

    # ---- 中文 prompt ----
    img_zh = (f"{scene_desc}，{subject}"
              f"{('，' + action) if action else ''}，"
              f"{light_zh}，{style}，{QUALITY_ZH}")
    vid_zh = (f"{cam_desc}，{subject}{('，' + action) if action else ''}，"
              f"时长约 {duration} 秒，{mood}氛围，{style}")

    # ---- 英文 prompt（技术词翻译，自由文本保留）----
    style_en = en_tech([style])
    img_en = (f"{scene_desc}, {subject}"
              f"{(', ' + action) if action else ''}, "
              f"{light_en}, {style_en}, {QUALITY_EN}")
    vid_en = (f"{cam_en}, {subject}{(', ' + action) if action else ''}, "
              f"about {duration}s, {mood} mood, {style_en}")

    neg = NEG_EN if p["lang"] == "en" else NEG_ZH

    primary_img = img_en if p["lang"] == "en" else img_zh
    primary_vid = vid_en if p["lang"] == "en" else vid_zh

    return {
        "provider": provider,
        "provider_label": p["label"],
        "model": p["model"],
        "ratio": ratio,
        "duration": duration,
        "seed": seed,
        "guidance": guidance,
        "camera_movement": cam_zh,
        "camera_movement_en": cam_en,
        "style": style,
        "mood": mood,
        "image_prompt": primary_img,
        "video_prompt": primary_vid,
        "neg_prompt": neg,
        "image_prompt_zh": img_zh,
        "video_prompt_zh": vid_zh,
        "image_prompt_en": img_en,
        "video_prompt_en": vid_en,
    }


def run(args):
    with open(args.script, "r", encoding="utf-8") as f:
        doc = json.load(f)
    project = doc.get("project", {}) or {}
    providers = resolve_providers(args)
    for p in providers:
        if p not in PROVIDERS:
            sys.stderr.write(f"[warn] 未知平台 {p}，已忽略；支持：{','.join(PROVIDERS)}\n")
    providers = [p for p in providers if p in PROVIDERS]
    if not providers:
        providers = [DEFAULT_PROVIDER]

    shots_out = []
    for ep, sc, sh in iter_shots(doc):
        gens = {}
        for p in providers:
            gens[p] = build_gen(sh, sc, ep, project, p, args)
        shots_out.append({
            "episode_id": ep.get("id"),
            "episode_title": ep.get("title"),
            "scene_id": sc.get("id"),
            "scene_location": sc.get("location"),
            "shot_id": sh.get("id"),
            "shot_type": sh.get("shot_type"),
            "character": sh.get("character", []),
            "duration": sh.get("duration"),
            "sound": sh.get("sound"),
            "dialogue": sh.get("dialogue"),
            "gens": gens,
        })

    stem = args.name or slugify(project.get("title")) or "drama"
    out_path = os.path.join(args.out, f"{stem}_prompts_raw.json")
    meta = {
        "skill": "aladin-drama-gen",
        "version": "1.0.0",
        "source_script": os.path.basename(args.script),
        "project_title": project.get("title"),
        "providers": providers,
        "provider_labels": [PROVIDERS[p]["label"] for p in providers],
        "seed_mode": args.seed_mode,
        "shot_count": len(shots_out),
    }
    payload = {"meta": meta, "shots": shots_out}
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    sys.stderr.write(f"[ok] 已生成 {len(shots_out)} 个 shot 的 prompt -> {out_path}\n")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="aladin-drama-gen: 把 script.json 的 shot 转为多平台生图/生视频 prompt")
    ap.add_argument("--script", required=True, help="输入 script.json（来自 aladin-drama-script）")
    ap.add_argument("--provider", default=DEFAULT_PROVIDER, help="默认平台（可逗号分隔），默认 jimeng")
    ap.add_argument("--providers", default=None, help="多平台逗号列表，覆盖 --provider")
    ap.add_argument("--style", default=None, help="全局风格词（可选，覆盖脚本内风格）")
    ap.add_argument("--name", default=None, help="输出文件 stem（默认取项目标题 slug）")
    ap.add_argument("--seed-mode", choices=["reproducible", "random"], default="reproducible",
                    help="seed 模式：reproducible(按 shot id 派生,可复算) / random")
    ap.add_argument("--seed-base", type=int, default=None, help="random 模式下的随机种子基数")
    ap.add_argument("--out", required=True, help="产物输出目录")
    args = ap.parse_args(argv)
    os.makedirs(args.out, exist_ok=True)
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
