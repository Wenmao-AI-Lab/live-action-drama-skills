#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""aladin-drama-gen · gen_report
整合 gen_prompts 与 gen_plan 的产物，输出最终交付三件套：
  <name>_prompts.json  —— 视频素材需求清单（aladin-drama-edit 的 --prompts 输入）
  prompts.csv          —— 批量表，可直接复制粘贴到各平台
  gen_panel.html       —— 自包含生成面板（内联 CSS/JS，可离线打开）
零依赖（仅 Python 标准库）。
"""
import argparse
import csv
import html
import json
import os
import sys


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_final_prompts(raw, plan, name):
    meta = dict(raw.get("meta", {}))
    if plan:
        meta["plan_summary"] = plan.get("summary", {})
    meta["deliverable"] = f"{name}_prompts.json"
    meta["next"] = "aladin-drama-edit --prompts <this file>"
    shots = []
    for s in raw.get("shots", []):
        shots.append({
            "episode_id": s.get("episode_id"),
            "episode_title": s.get("episode_title"),
            "scene_id": s.get("scene_id"),
            "scene_location": s.get("scene_location"),
            "shot_id": s.get("shot_id"),
            "shot_type": s.get("shot_type"),
            "character": s.get("character", []),
            "duration": s.get("duration"),
            "sound": s.get("sound"),
            "dialogue": s.get("dialogue"),
            "gen": s.get("gens", {}),
        })
    return {"meta": meta, "shots": shots}


def write_csv(raw, name, out_dir):
    path = os.path.join(out_dir, "prompts.csv")
    providers = raw.get("meta", {}).get("providers", ["jimeng"])
    fields = ["shot_id", "episode_id", "scene_id", "provider", "model", "ratio",
              "duration", "seed", "guidance", "camera_movement", "style", "mood",
              "image_prompt", "video_prompt", "neg_prompt"]
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for s in raw.get("shots", []):
            for p in providers:
                g = s.get("gens", {}).get(p, {})
                w.writerow({
                    "shot_id": s.get("shot_id"), "episode_id": s.get("episode_id"),
                    "scene_id": s.get("scene_id"),
                    "provider": p, "model": g.get("model"), "ratio": g.get("ratio"),
                    "duration": g.get("duration"), "seed": g.get("seed"),
                    "guidance": g.get("guidance"),
                    "camera_movement": g.get("camera_movement"),
                    "style": g.get("style"), "mood": g.get("mood"),
                    "image_prompt": g.get("image_prompt"),
                    "video_prompt": g.get("video_prompt"),
                    "neg_prompt": g.get("neg_prompt"),
                })
    return path


def esc(t):
    return html.escape(str(t or ""))


def build_html(raw, plan, name):
    meta = raw.get("meta", {})
    providers = meta.get("providers", ["jimeng"])
    summary = (plan or {}).get("summary", {})
    rows = []
    for s in raw.get("shots", []):
        tabs = []
        panels = []
        for i, p in enumerate(providers):
            g = s.get("gens", {}).get(p, {})
            active = " active" if i == 0 else ""
            tabs.append(
                f'<button class="tab{active}" onclick="sel(this,{i})">{esc(g.get("provider_label", p))}</button>')
            panels.append(f'''<div class="pbody{active}" data-i="{i}">
  <div class="kv"><span>model</span><b>{esc(g.get("model"))}</b></div>
  <div class="kv"><span>ratio / duration / seed</span><b>{esc(g.get("ratio"))} · {esc(g.get("duration"))}s · seed {esc(g.get("seed"))} · cfg {esc(g.get("guidance"))}</b></div>
  <div class="kv"><span>camera</span><b>{esc(g.get("camera_movement"))} / {esc(g.get("camera_movement_en"))}</b></div>
  <label>image_prompt <button class="cp" onclick="copy(this)">复制</button></label>
  <textarea readonly>{esc(g.get("image_prompt"))}</textarea>
  <label>video_prompt <button class="cp" onclick="copy(this)">复制</button></label>
  <textarea readonly>{esc(g.get("video_prompt"))}</textarea>
  <label>neg_prompt <button class="cp" onclick="copy(this)">复制</button></label>
  <textarea readonly class="neg">{esc(g.get("neg_prompt"))}</textarea>
</div>''')
        rows.append(f'''<div class="shot">
  <div class="head"><span class="sid">{esc(s.get("shot_id"))}</span>
    <span class="meta">{esc(s.get("episode_id"))} / {esc(s.get("scene_id"))} / {esc(s.get("scene_location"))}</span>
    <span class="char">👤 {esc("、".join(s.get("character") or []))}</span>
    <span class="dur">🔊 {esc(s.get("sound") or "-")}</span></div>
  <div class="tabs">{"".join(tabs)}</div>
  <div class="pbodies">{"".join(panels)}</div>
</div>''')

    missing = summary.get("missing_resource_count", 0)
    stat = (f'总 shot <b>{summary.get("shot_count","-")}</b> · '
            f'场 <b>{summary.get("scene_count","-")}</b> · '
            f'时长 <b>{summary.get("total_duration_sec","-")}s</b> · '
            f'tokens≈<b>{summary.get("total_tokens_est","-")}</b> · '
            f'缺失 <b>{missing}</b>')

    return f'''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>阿拉丁·AI短剧生成面板 · {esc(name)}</title>
<style>
*{{box-sizing:border-box}} body{{margin:0;font-family:-apple-system,"PingFang SC",Segoe UI,sans-serif;background:#0f1116;color:#e6e6e6}}
header{{padding:18px 22px;background:linear-gradient(90deg,#7b2ff7,#f72f8e);color:#fff}}
header h1{{margin:0;font-size:18px}} .stat{{margin-top:6px;font-size:13px;opacity:.95}}
main{{padding:16px 22px;display:grid;gap:14px}}
.shot{{background:#1a1d27;border:1px solid #2a2e3a;border-radius:10px;overflow:hidden}}
.head{{display:flex;gap:12px;align-items:center;padding:10px 14px;border-bottom:1px solid #2a2e3a;flex-wrap:wrap}}
.sid{{font-weight:700;color:#f72f8e}} .meta{{font-size:12px;color:#9aa}} .char,.dur{{font-size:12px;color:#cdd}}
.tabs{{display:flex;gap:4px;padding:8px 14px 0}}
.tab{{background:#232733;color:#cdd;border:1px solid #2a2e3a;border-radius:6px 6px 0 0;padding:6px 12px;cursor:pointer;font-size:12px}}
.tab.active{{background:#7b2ff7;color:#fff;border-color:#7b2ff7}}
.pbodies{{padding:12px 14px 16px}}
.pbody{{display:none}} .pbody.active{{display:block}}
.kv{{display:flex;gap:8px;font-size:12px;margin-bottom:6px}} .kv span{{color:#9aa;min-width:120px}}
label{{display:block;font-size:12px;color:#9aa;margin:10px 0 4px}} textarea{{width:100%;height:64px;background:#0f1116;color:#e6e6e6;border:1px solid #2a2e3a;border-radius:6px;padding:8px;font-size:12px;resize:vertical}} textarea.neg{{color:#ff9aa2}}
.cp{{float:right;background:#2a2e3a;color:#cdd;border:none;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:11px}}
</style></head><body>
<header><h1>阿拉丁·AI短剧生成面板 · {esc(name)}</h1>
<div class="stat">{stat}　|　平台：{esc(" / ".join(meta.get("provider_labels", providers)))}</div></header>
<main>{"".join(rows)}</main>
<script>
function sel(btn,i){{var t=btn.parentElement.parentElement;var tabs=t.querySelectorAll('.tab');var bod=t.querySelectorAll('.pbody');tabs.forEach((x,k)=>x.classList.toggle('active',k===i));bod.forEach((x,k)=>x.classList.toggle('active',k===i));}}
function copy(b){{var ta=b.parentElement.nextElementSibling;ta.select();document.execCommand('copy');b.textContent='已复制';setTimeout(()=>b.textContent='复制',1200);}}
</script></body></html>'''


def run(args):
    raw = load_json(args.prompts)
    plan = None
    if args.plan and os.path.exists(args.plan):
        plan = load_json(args.plan)
    name = args.name or os.path.splitext(os.path.basename(args.prompts))[0].replace("_prompts_raw", "")
    stem = name

    final = build_final_prompts(raw, plan, stem)
    fp = os.path.join(args.out, f"{stem}_prompts.json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(final, f, ensure_ascii=False, indent=2)

    csv_path = write_csv(raw, stem, args.out)

    html_path = os.path.join(args.out, "gen_panel.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(build_html(raw, plan, stem))

    sys.stderr.write(f"[ok] 交付三件套：\n  {fp}\n  {csv_path}\n  {html_path}\n")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="aladin-drama-gen: 产出最终 prompt 交付物")
    ap.add_argument("--prompts", required=True, help="gen_prompts 产出的 *_prompts_raw.json")
    ap.add_argument("--plan", default=None, help="gen_plan 产出的 *_plan.json（可选）")
    ap.add_argument("--name", default=None, help="输出 stem（默认派生）")
    ap.add_argument("--out", required=True, help="产物输出目录")
    args = ap.parse_args(argv)
    os.makedirs(args.out, exist_ok=True)
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
