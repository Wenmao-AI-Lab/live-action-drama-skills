#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""aladin-drama-gen · gen_plan
基于 gen_prompts 产出的 raw 文件，批量生成镜头生成清单：按场景分组、
估算生成顺序与预算（条数/时长/tokens 粗估）、列出缺失资源。
零依赖（仅 Python 标准库）。
"""
import argparse
import json
import os
import sys

# tokens 粗估：每字符约 0.6 token（中英文混排经验值）
TOKEN_PER_CHAR = 0.6


def est_tokens(text):
    if not text:
        return 0
    return int(len(text) * TOKEN_PER_CHAR) + 8  # +8 平台指令固定开销


def run(args):
    with open(args.prompts, "r", encoding="utf-8") as f:
        data = json.load(f)
    meta = data.get("meta", {})
    shots = data.get("shots", [])
    providers = meta.get("providers", ["jimeng"])

    # ---- 按 场景 分组 ----
    groups = {}
    for s in shots:
        key = (s.get("episode_id"), s.get("scene_id"), s.get("scene_location"))
        groups.setdefault(key, []).append(s)

    scenes_plan = []
    total_shots = 0
    total_duration = 0.0
    total_tokens = 0
    missing = []  # 缺失资源的 shot

    for (ep_id, sc_id, loc), items in groups.items():
        sc_shots = len(items)
        sc_dur = 0.0
        sc_tokens = 0
        sc_missing = []
        order = []
        for idx, s in enumerate(items, 1):
            # 取第一个平台的 prompt 做估算/Missing 判定
            first_p = providers[0]
            gen = s.get("gens", {}).get(first_p, {})
            img = gen.get("image_prompt")
            vid = gen.get("video_prompt")
            dur = gen.get("duration") or 0
            sc_dur += float(dur)
            sc_tokens += est_tokens(img) + est_tokens(vid) + est_tokens(gen.get("neg_prompt"))
            order.append({
                "seq": idx,
                "shot_id": s.get("shot_id"),
                "shot_type": s.get("shot_type"),
                "image_prompt": bool(img),
                "video_prompt": bool(vid),
            })
            if not img or not vid:
                sc_missing.append(s.get("shot_id"))
                missing.append({
                    "episode_id": ep_id, "scene_id": sc_id,
                    "shot_id": s.get("shot_id"),
                    "missing": [k for k in ("image_prompt", "video_prompt") if not gen.get(k)],
                })
        total_shots += sc_shots
        total_duration += sc_dur
        total_tokens += sc_tokens
        scenes_plan.append({
            "episode_id": ep_id,
            "scene_id": sc_id,
            "location": loc,
            "shot_count": sc_shots,
            "duration": round(sc_dur, 1),
            "tokens_est": int(sc_tokens),
            "missing": sc_missing,
            "order": order,
        })

    # 生成顺序（扁平）：按 集 -> 场 -> shot 顺序
    flat_order = [{
        "episode_id": s.get("episode_id"),
        "scene_id": s.get("scene_id"),
        "shot_id": s.get("shot_id"),
        "providers": providers,
    } for s in shots]

    plan = {
        "meta": {
            "skill": "aladin-drama-gen",
            "version": "1.0.0",
            "source_prompts": os.path.basename(args.prompts),
            "providers": providers,
            "provider_labels": meta.get("provider_labels", providers),
        },
        "summary": {
            "shot_count": total_shots,
            "scene_count": len(scenes_plan),
            "total_duration_sec": round(total_duration, 1),
            "total_tokens_est": int(total_tokens),
            "per_provider_shot_count": {p: total_shots for p in providers},
            "missing_resource_count": len(missing),
        },
        "scenes": scenes_plan,
        "flat_order": flat_order,
        "missing_resources": missing,
    }

    stem = args.name or os.path.splitext(os.path.basename(args.prompts))[0].replace("_prompts_raw", "")
    out_path = os.path.join(args.out, f"{stem}_plan.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)

    # 控制台摘要
    sys.stderr.write(
        f"[ok] 计划已生成：{total_shots} shots / {len(scenes_plan)} 场 / "
        f"≈{round(total_duration,1)}s / ≈{int(total_tokens)} tokens\n")
    if missing:
        sys.stderr.write(f"[warn] 缺失资源 shot 数：{len(missing)}\n")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="aladin-drama-gen: 生成批量镜头清单与预算")
    ap.add_argument("--prompts", required=True, help="gen_prompts 产出的 *_prompts_raw.json")
    ap.add_argument("--name", default=None, help="输出 stem（默认派生）")
    ap.add_argument("--out", required=True, help="产物输出目录")
    args = ap.parse_args(argv)
    os.makedirs(args.out, exist_ok=True)
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
