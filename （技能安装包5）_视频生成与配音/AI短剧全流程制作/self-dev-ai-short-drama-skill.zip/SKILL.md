---

name: self-dev-ai-short-drama-skill
slug: "self-dev-ai-short-drama-skill"
version: 1.0.0
displayName: "Self Dev Ai Short Drama Skill"
description: |
  AI短剧全流程制作 Skill：从选题策划到成片发布的一站式工作流。
  基于 z-ai video (cogvideox-3) AI视频生成 + z-ai-generate 图片生成 + ffmpeg 后期处理，支持霸总甜宠/虐恋/逆袭等热门题材。
  当用户说"做AI短剧""短剧制作""AI视频短剧""短剧工作流"时触发。
requires:
  bins: [ffmpeg, ffprobe, python3]
  env: [CNB_TOKEN]
allowed-tools: Bash(ffmpeg:*), Bash(ffprobe:*), Bash(python3:*), Bash(curl:*), Bash(git:*), Bash(node:*), Bash(npm:*), Bash(pip:*), Bash(edge-tts:*), Bash(z-ai-generate:*), Bash(z-ai-web-dev-sdk:*)
references:
  - references/workflow-recap.md
  - references/prompt-templates.md
  - references/post-production-pipeline.md
  - references/pitfalls-and-fixes.md
  - references/distribution-guide.md
assets:
  - assets/scripts/process_episode.sh
  - assets/scripts/generate_tts.py
  - assets/scripts/srt_to_ass.py
  - assets/templates/bible_template.md
  - assets/templates/episode_prompt_template.json
  - assets/templates/tts_data_template.json
  - assets/templates/subtitle_template.srt
---




# AI短剧全流程制作 Skill

**用 z-ai video + z-ai-generate + edge-tts + ffmpeg 批量制作竖屏短剧，从选题到成片一站式搞定**

---

## 架构总览

```
┌─────────────────────────────────────────────────────────┐
│                    AI短剧制作工作流                        │
├──────────┬──────────┬──────────┬──────────┬─────────────┤
│  Phase 1  │  Phase 2  │  Phase 3  │  Phase 4  │   Phase 5   │
│  前期策划  │  视频生成  │  后期处理  │  审核交付  │   分发运营   │
├──────────┼──────────┼──────────┼──────────┼─────────────┤
│ 选题分析   │ Prompt    │ TTS配音   │ VLM画面   │ 多平台分发    │
│ 故事圣经   │ 拆分编写   │ 音量标准化  │ 逐帧审核   │ 标题/文案库   │
│ 分集大纲   │ API调用    │ 字幕制作   │ 音频分析   │ 投流策略     │
│ 分镜剧本   │ 视频下载   │ 字幕烧录   │ 问题标记   │ ROI追踪      │
│ z-ai video │ CNB提交    │ 拼接输出   │ CNB审核   │ 数据复盘      │
│ z-ai图片   │           │ Release   │ Issue跟踪  │             │
│ Ken Burns  │           │           │           │             │
└──────────┴──────────┴──────────┴──────────┴─────────────┘
         ↓             ↓            ↓           ↓
    OpenClaw #1    OpenClaw #2    OpenClaw #1    用户/运营
    (前期+后期)     (视频生成)     (后期+审核)
```

---

## 关键参数

| 参数 | 值 | 说明 |
|------|-----|------|
| 视频API | z-ai video (cogvideox-3) | 5秒/条，免费（内测） |
| 图片API | z-ai-generate | 免费，768x1344竖屏 |
| 分辨率 | 768×1344 | 竖屏9:16 |
| 每集镜头数 | 18条 | 每条10秒=180秒=3分钟 |
| 单集成本 | ~0元 | z-ai免费内测 |
| TTS引擎 | edge-tts | 免费，质量高 |
| 字幕格式 | ASS高级 | 半透明背景+淡入淡出 |
| 后期工具 | ffmpeg | 全自动pipeline |

---

## 分工模型

| 角色 | 职责 | 使用的工具 |
|------|------|-----------|
| **OpenClaw #1** | 前期策划 + 后期处理 + 审核交付 | AI写作、ffmpeg、CNB API |
| **OpenClaw #2** | z-ai视频/图片生成 | z-ai video / z-ai-generate |
| **用户** | 最终审片 + 分发运营 + 投流 | 剪映/抖音/各平台 |

---

## Phase 1: 前期策划（OpenClaw #1）

### Step 1.1: 选题分析

**提示词模板**：
```
分析当前AI短剧市场数据，为"AI生成视频短剧"项目选择最优题材方向。
要求：
1. 搜索2024-2025年短剧市场ROI数据、热门题材排行、单集成本回收率
2. 对比分析：霸总甜宠 vs 虐恋 vs 逆袭 vs 悬疑 vs 玄幻仙侠
3. 综合考虑：z-ai video (cogvideox-3) 5秒片段限制（可慢放延伸到10秒）、
   z-ai-generate图片+Ken Burns运镜管线、
   AI生成视频的优劣势、目标受众付费意愿
4. 给出推荐题材及理由，包含对标爆款作品

输出格式：对比表格 + 推荐结论 + 理由分析
```

**实际结果**：推荐"霸总甜宠"，ROI最高（1.5-3x），场景现代写实适合AI生成。

### Step 1.2: 故事圣经

**提示词模板**：
```
为一部{集数}集×3分钟的竖屏短剧编写完整故事圣经。
题材：{题材}
核心设定：{一句话概括}
要求：
1. 核心定位（题材、集数、时长、镜头数、风格、目标受众、画面比例）
2. 故事梗概（一句话概括 + 三年前序幕 + 现在时间线 + 真相揭示）
3. 核心人物设定（4-6个角色，每个含外貌/性格/关键道具/人设反差）
4. 每集结构模板（180秒标准格式：hook→推进→情感→矛盾→高潮→沉淀→悬念）
5. 场景清单（标注管线A/B适用度）
6. z-ai Prompt角色外貌速查（中英文双语）

每个角色必须包含：
- 姓名/年龄/身份
- 详细外貌描述（供Prompt使用）
- 性格特征（3-5个关键词）
- 关键道具/标记（如伤疤、首饰）
- 英文Prompt外貌描述（直接用于z-ai video / z-ai-generate）

输出为Markdown格式，保存为 scripts/bible.md
```

### Step 1.3: 分集大纲 + 分镜剧本

**提示词模板（大纲）**：
```
基于故事圣经，编写{集数}集分集大纲。
要求：
1. 每集包含：核心任务、3-5个剧情节点、爽点/钩子、结尾悬念
2. 情绪曲线表（主情绪、钩子类型、爽点）
3. 节奏策略：每3集一个小高潮，每5集一个大反转
4. 每集标题要自带传播力（适合做视频标题）
5. 标注每集的关键冲突和情感转折点

输出格式：每集独立section，含剧情+钩子+悬念
保存为 scripts/outline.md
```

**提示词模板（分镜）**：
```
基于故事圣经和分集大纲，为第{N}集编写详细分镜剧本。
要求：
1. 将{N}集拆分为18个10秒镜头（共180秒）
2. 每个镜头包含：
   - 镜头编号和时间范围（如 SC01: 0-10s）
   - 画面描述（详细到可翻译为英文Prompt）
   - 镜头语言（景别、运动方式、构图）
   - 台词/旁白（如有）
   - 音效描述
   - 情绪标注
3. 确保镜头之间有叙事连贯性
4. 钩子镜头（每集最后2-3个）要有强烈悬念感
5. 标注角色出场情况

保存为 scripts/ep{N}.md
```

### Step 1.4: AI Prompt 生成

**提示词模板**：
```
基于第{N}集分镜剧本，为每个镜头生成z-ai所需的英文Prompt。
Prompt格式要求：
1. 以画面主体开头（人物/场景）
2. 包含构图和镜头运动（如 close-up, slow push in, tracking shot）
3. 包含光影描述（如 warm lamplight, cool moonlight）
4. 包含情绪氛围（如 melancholic, suspenseful, romantic）
5. 以技术参数结尾：vertical 9:16 ratio, cinematic, 10 seconds
6. 每个Prompt控制在80-150个英文单词
7. 如果有角色出场，从故事圣经的角色外貌速查中提取英文描述嵌入

同时输出：
- scene_description_cn：对应中文场景描述
- dialogue：该镜头的台词文本
- audio：音效描述
- output_path：视频保存路径（videos/ep{N}/sc{XX}.mp4）

输出为JSON格式，每个镜头一个JSON文件 + 一个episode_summary.json总览
保存到 prompts/ep{N}/ 目录
```

### Step 1.5: 角色参考图生成

使用 z-ai-generate 为每个主要角色生成参考图：
```bash
z-ai-generate -p "{英文角色外貌Prompt}, character reference sheet, multiple angles, white background, vertical 9:16" -o "references/{角色名}.png"
```

### Step 1.6: CNB仓库初始化

```bash
# 目录结构
drama-workflow/
├── scripts/           # 剧本（bible.md, outline.md, ep{N}.md）
├── prompts/           # Seedance Prompt（ep{N}/sc{XX}.json + episode_summary.json）
├── references/        # 角色参考图（{角色名}.png）
├── config.json        # 角色和场景配置
├── videos/            # 生成视频（ep{N}/sc{XX}.mp4）
├── post-production/   # 后期素材
│   ├── audio/         # TTS配音
│   ├── subtitles/     # 字幕文件
│   ├── scripts/       # ffmpeg脚本
│   └── *.json         # TTS数据
├── output/            # 最终输出
├── reports/           # 审核报告
└── distribution/      # 分发方案
```

---

## Phase 2: 视频生成（OpenClaw #2）

### Step 2.1: 接收任务

从CNB仓库读取 prompt JSON文件，逐条调用 Seedance 2.0 API。

### Step 2.2: API调用

每条Prompt调用格式：
```
POST Seedance 2.0 API
{
  "prompt": "<英文Prompt>",
  "duration": 10,
  "resolution": "720x1280",
  "aspect_ratio": "9:16"
}
```

### Step 2.3: 结果提交

生成视频提交到CNB仓库 `videos/ep{N}/sc{XX}.mp4`

---

## Phase 3: 后期处理（OpenClaw #1）

### Step 3.1: TTS配音生成

从分镜剧本中提取所有台词，生成TTS数据JSON：

**提示词模板**：
```
基于第{N}集分镜剧本，提取所有含台词的镜头，生成TTS配音数据JSON。
要求：
1. 每条台词包含：scene、character、character_type、voice（edge-tts语音ID）、
   emotion、text、speed、pitch、output_file
2. 语音映射：
   - 女主→zh-CN-XiaoxiaoNeural（温柔坚韧）
   - 男主→zh-CN-YunjianNeural（低沉磁性）
   - 继母/反派女→zh-CN-XiaoyiNeural
   - 反派男→zh-CN-YunyangNeural
   - 旁白→zh-CN-YunxiNeural（低沉叙事感）
   - 老年女性→zh-CN-shaanxi-XiaoniNeural
3. 情感参数：
   - speed: 0.75-1.0（慢=情感戏，正常=对话，快=紧张）
   - pitch: -4Hz~+2Hz（低=悬疑/反派，正常=旁白，高=年轻女性）
4. 内心独白需标注is_inner_monologue: true

输出为 ep{N}_tts_data.json
```

生成TTS语音：
```bash
python3 generate_tts.py  # 使用edge-tts免费生成
```

### Step 3.2: 字幕制作

**SRT字幕生成**：

**提示词模板**：
```
基于第{N}集TTS数据和视频拼接顺序，生成SRT字幕文件。
要求：
1. 时间轴与视频严格对齐（sc01: 0-10s, sc02: 10-20s, ...）
2. 内心独白用【】包裹
3. 台词按角色分行显示
4. 旁白不标注角色名
5. 时间轴考虑0.5s转场间隔

输出为 ep{N}_subtitles.srt
```

**ASS专业字幕**（推荐，竖屏短剧审美标准）：
```bash
python3 srt_to_ass.py ep{N}_subtitles.srt ep{N}_pro.ass
```

ASS字幕特点：
- 半透明背景条（BorderStyle 3）
- 柔和描边 + 淡入淡出动画
- 双样式区分（Dialogue对白 / Narration旁白）
- Sarasa Mono SC 等距更纱黑体

### Step 3.3: ffmpeg后期Pipeline

一键执行：
```bash
bash process_episode.sh              # 仅配音+标准化+拼接
bash process_episode.sh /path/bgm.mp3  # 含BGM
```

Pipeline流程：
```
Step 0: TTS配音合并（原音15% + TTS 85% amix）
    ↓
Step 1: 音量标准化（loudnorm -23 LUFS）
    ↓
Step 2: BGM混合（可选，默认不启用）
    ↓
Step 3: 拼接（18条→完整视频，含0.5s黑场过渡）
    ↓
输出: output/ep{N}_final.mp4
```

### Step 3.4: 字幕烧录

```bash
ffmpeg -nostdin -y \
  -i output/ep{N}_final.mp4 \
  -vf "ass=ep{N}_pro.ass" \
  -c:v libx264 -preset fast -crf 22 \
  -c:a copy -movflags +faststart \
  output/ep{N}_final_subtitled.mp4
```

---

## Phase 4: 审核交付（OpenClaw #1）

### Step 4.1: 视频审核

**提示词模板**：
```
对第{N}集的全部{N}条视频进行完整审核。
要求：
1. 技术参数检查（分辨率/时长/编码/帧率）
2. 逐镜头画面审核（VLM分析首帧+尾帧，对比原定Prompt）
3. 音频分析（检测人声/音量一致性/背景音）
4. 角色一致性评估
5. 输出审核报告，包含：
   - 技术参数矩阵
   - 画面匹配度评分（⭐1-5）
   - 音频RMS数据
   - 问题镜头标记
   - 对话清单（供TTS使用）

保存为 reports/EP{N}_视频审核报告.md
```

### Step 4.2: CNB Issue管理

通过CNB API创建Issue跟踪问题：
```bash
curl -X POST "${CNB_API_ENDPOINT}/{repo}/-/issues" \
  -H "Authorization: Bearer $CNB_TOKEN" \
  -d '{"title":"EP01 后期任务","body":"...任务清单..."}'
```

### Step 4.3: Release发布（制品库）

将最终视频上传到CNB Release：
```bash
# 1. 创建/更新Release
curl -X POST "${CNB_API_ENDPOINT}/{repo}/-/releases" \
  -d '{"tag_name":"ep{N}-v1","name":"EP{N} {标题}"}'

# 2. 上传视频到Release
curl -X POST "${CNB_API_ENDPOINT}/{repo}/-/releases/{id}/asset-upload-url" \
  -d "{\"asset_name\":\"ep{N}_final_subtitled.mp4\",\"size\":${FILE_SIZE}}"

# 3. PUT上传到预签名URL
curl -X PUT --upload-file ep{N}_final_subtitled.mp4 "${upload_url}"

# 4. 确认上传
curl -X POST "${verify_url}" -H "Authorization: Bearer $CNB_TOKEN"
```

---

## Phase 5: 分发运营（用户/运营）

### Step 5.1: 分发方案

**提示词模板**：
```
为短剧《{剧名}》编写完整分发运营方案。
要求：
1. 平台选择与优先级矩阵（抖音/红果/快手/视频号/小红书/TikTok）
2. 发布节奏（预热期→冷启动→增长→爆发→长尾，共6周）
3. 爆款标题库（每集5个备选标题，用情绪触发词+场景痛点+价值承诺公式）
4. 正文文案库（每集发布配文+CTA文案）
5. 话题/标签策略
6. 投流策略（预算分配+ROI目标+止损线）
7. 变现路径（付费解锁/广告分成/直播带货/IP授权）
8. 矩阵号策略
9. 数据监控指标体系

保存为 distribution/分发运营方案.md
```

### Step 5.2: 多平台发布

| 平台 | 内容格式 | 标注 |
|------|---------|------|
| 抖音 | 完整版+切片 | 主战场，60%收入 |
| 红果 | 全集连续上传 | 免费流量池 |
| 快手 | EP1-3免费+付费 | 下沉市场 |
| 视频号 | 完整版+裂变设计 | 私域传播 |
| 小红书 | 1分钟名场面+图文 | 种草引流 |
| TikTok | 15-60秒片段+双语字幕 | 东南亚优先 |

---

## 踩坑速查表

| # | 问题 | 原因 | 解决方案 |
|---|------|------|---------|
| 1 | 字幕字体乱码 | ffmpeg默认字体不含中文 | 使用 Sarasa Mono SC 或 WenQuanYi Zen Hei |
| 2 | ffmpeg stdin冲突 | 终端stdin干扰ffmpeg | 加 `-nostdin` 参数 |
| 3 | concat filter语法错误 | bash变量含特殊字符 | 改用Python subprocess或concat demuxer |
| 4 | 字幕烧录超时 | 复杂滤镜处理慢 | 使用 `-preset fast` + `-crf 22` |
| 5 | 大文件放git | mp4文件超git限制 | 用CNB Release制品库上传 |
| 6 | CNB_TOKEN无效 | 权限不足 | 确认token有 repo-code:rw 权限 |
| 7 | 角色跨镜头不一致 | AI生成无角色记忆 | 人工审核，偏差大则重生成 |
| 8 | 音量不均 | z-ai video环境音差异大 | loudnorm标准化到-23 LUFS |
| 9 | TTS语速与视频不匹配 | 长台词塞不进10秒 | 调整speed参数至0.75-0.9 |
| 10 | 字幕审美粗糙 | 白字黑边太复古 | 用ASS专业字幕+半透明背景条 |

---

## 性能基准（EP01实测）

| 阶段 | 耗时 | 成本 | 备注 |
|------|------|------|------|
| 前期策划（选题+圣经+大纲+分镜+Prompt） | ~60min | 0元 | AI生成 |
| 视频生成（18条z-ai video/图片） | ~30min | ~0元 | z-ai免费内测 |
| TTS配音（18条edge-tts） | ~5min | 0元 | 免费TTS |
| 后期Pipeline（配音合并+标准化+拼接） | ~10min | 0元 | ffmpeg自动 |
| 字幕烧录 | ~3min | 0元 | ffmpeg自动 |
| 视频审核 | ~15min | 0元 | VLM分析 |
| **总计** | **~2小时** | **~0元/集** | **10集总计~0元（免费内测）** |

---

## 参考资料

- [完整工作流复盘](references/workflow-recap.md) — EP01全流程详细记录
- [提示词模板库](references/prompt-templates.md) — 每个环节的完整提示词
- [后期Pipeline文档](references/post-production-pipeline.md) — ffmpeg命令详解
- [踩坑与修复记录](references/pitfalls-and-fixes.md) — 12个关键问题及解决方案
- [分发运营指南](references/distribution-guide.md) — 多平台分发完整方案

---

## ⚠️ 运行说明（AI灵匣整理）

本技能为「提示词驱动」型技能：SKILL.md 中引用的部分辅助脚本（scripts/ 下未随包提供的文件）为可选增强，**并非运行必需**。

- 请直接按本技能的流程与规则执行任务，不要因为缺少脚本而中断。
- 若某一步骤需要执行脚本，请由 AI 现场生成等价实现（内联 Python/Node 代码或命令行），或按文档描述直接完成对应功能。
- 如技能涉及外部 API，按其文档指引配置即可；涉及本地软件的部分，按需引导用户安装。

一切以完成用户的真实需求为准。
