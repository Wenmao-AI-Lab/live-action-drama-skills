#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dub_report.py - 生成自包含配音看板 dub_board.html 与导演备注 dub_notes.md。

输入: --dub _dub.json  --cast cast.json  --lines lines.json
输出: --out/dub_board.html  --out/dub_notes.md
仅依赖 Python 标准库。
"""
import argparse
import html
import json
import os
import sys

# 情感 -> 导演建议（规则化，不调模型）
EMOTION_NOTE = {
    "neutral": "平稳叙述，语速适中，尾音自然落下。",
    "平静": "气声偏多，留白充足，营造安静氛围。",
    "happy": "嘴角上扬感，语速略快，重音在喜悦词。",
    "兴奋": "音调上扬，节奏明快，关键处加重。",
    "excited": "音调上扬，节奏明快，关键处加重。",
    "sad": "语速放慢，音调下沉，句末微微气声。",
    "悲伤": "语速放慢，音调下沉，句末微微气声。",
    "angry": "咬字有力，音量提升，重音砸在冲突词。",
    "愤怒": "咬字有力，音量提升，重音砸在冲突词。",
    "fear": "气声颤抖，语速不稳，尾音收回。",
    "恐惧": "气声颤抖，语速不稳，尾音收回。",
    "serious": "低沉克制，字字清晰，少修饰。",
    "严肃": "低沉克制，字字清晰，少修饰。",
    "soft": "温柔轻缓，贴近耳语，留呼吸感。",
    "温柔": "温柔轻缓，贴近耳语，留呼吸感。",
    "question": "尾音上挑，留疑惑停顿。",
    "疑问": "尾音上挑，留疑惑停顿。",
    "anxious": "语速偏快，换气频繁，带不确定感。",
    "焦虑": "语速偏快，换气频繁，带不确定感。",
    "tender": "慈爱包容，节奏舒缓。",
    "慈祥": "慈爱包容，节奏舒缓。",
}

PUNCT_PAUSE = [
    ("。", "句号后停顿 0.4s，彻底换气。"),
    ("！", "感叹号处加重语气、音量 +，尾音干脆。"),
    ("？", "问号处尾音上扬，留 0.3s 悬停。"),
    ("，", "逗号处短顿 0.15s，不断气。"),
    ("……", "省略号处拉长 0.5s，留余韵。"),
    ("、", "顿号处微顿 0.08s。"),
]


def director_note(line):
    emo = line.get("emotion", "neutral")
    text = line.get("text", "")
    notes = [EMOTION_NOTE.get(emo, EMOTION_NOTE["neutral"])]
    for ch, hint in PUNCT_PAUSE:
        if ch in text:
            notes.append(hint)
            break
    return " ".join(notes)


def main(argv=None):
    ap = argparse.ArgumentParser(description="生成配音看板与导演备注")
    ap.add_argument("--dub", required=True, help="_dub.json 路径")
    ap.add_argument("--cast", required=True, help="cast.json 路径")
    ap.add_argument("--lines", required=True, help="lines.json 路径")
    ap.add_argument("--out", required=True, help="输出目录")
    args = ap.parse_args(argv)

    with open(args.dub, "r", encoding="utf-8") as f:
        dub = json.load(f)
    with open(args.cast, "r", encoding="utf-8") as f:
        cast_doc = json.load(f)
    with open(args.lines, "r", encoding="utf-8") as f:
        lines_doc = json.load(f)

    meta = dub.get("meta", {})
    tracks = dub.get("tracks", [])
    lines = lines_doc.get("lines", [])

    # 从 dub 的 segments 建 (shot_no,character,text) -> 参数 查找表
    param_lookup = {}
    for t in tracks:
        for seg in t.get("segments", []):
            key = (seg.get("shot_no"), t.get("character"), seg.get("text"))
            param_lookup[key] = seg

    # ---- 看板 HTML ----
    cards = []
    for t in tracks:
        seg_n = len(t.get("segments", []))
        role_cn = "旁白" if t.get("role") == "narrator" else "角色"
        cards.append(
            '<div class="card"><div class="cname">%s</div>'
            '<div class="cmeta">类型：%s</div>'
            '<div class="cmeta">音色：<code>%s</code></div>'
            '<div class="cmeta">厂商：%s</div>'
            '<div class="cmeta">句数：%d</div></div>'
            % (html.escape(str(t.get("character"))), role_cn,
               html.escape(str(t.get("voice"))), html.escape(str(t.get("provider"))),
               seg_n)
        )
    cards_html = "\n".join(cards)

    rows = []
    for ln in lines:
        seg = param_lookup.get(
            (ln.get("shot_no"), ln.get("character"), ln.get("text")), {})
        rate = seg.get("rate", "+0%")
        pitch = seg.get("pitch", "+0Hz")
        volume = seg.get("volume", "+0%")
        style = seg.get("style", "general")
        rows.append(
            '<tr><td>%s</td><td>%s</td><td class="role-%s">%s</td>'
            '<td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>'
            % (html.escape(str(ln.get("shot_no"))),
               html.escape(str(ln.get("start"))) + "–" + html.escape(str(ln.get("end"))),
               "narr" if ln.get("role") == "narrator" else "char",
               html.escape(str(ln.get("character"))),
               html.escape(str(ln.get("voice"))),
               html.escape(str(ln.get("text"))),
               html.escape(str(ln.get("emotion"))),
               ("rate=%s pitch=%s vol=%s style=%s"
                % (rate, pitch, volume, style)))
        )
    rows_html = "\n".join(rows)

    # 旁白段
    narr = dub.get("narration", [])
    narr_html = "".join(
        '<li>[%s] %s</li>' % (html.escape(str(n.get("start"))), html.escape(str(n.get("text"))))
        for n in narr
    ) if narr else '<li class="muted">无旁白</li>'

    trans = dub.get("translations", [])
    trans_html = ""
    for tg in trans:
        trans_html += "<h3>目标语言：%s（占位，待翻译）</h3>" % html.escape(str(tg.get("lang")))
        items = "".join(
            "<li>%s</li>" % html.escape(str(it.get("source")))
            for it in tg.get("items", [])
        )
        trans_html += "<ul>%s</ul>" % items

    html_doc = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>配音看板 - %s</title>
<style>
:root{--bg:#0f1220;--card:#1a1f35;--ink:#e7ecff;--mut:#8b93b8;--acc:#6c8cff;--nar:#ffcf6c}
*{box-sizing:border-box}body{margin:0;font:14px/1.6 system-ui,'Segoe UI',sans-serif;background:var(--bg);color:var(--ink)}
header{padding:20px 24px;background:linear-gradient(90deg,#222a4d,#0f1220);border-bottom:1px solid #2a325a}
h1{margin:0;font-size:20px}h2{margin:24px 0 10px;font-size:16px;color:var(--acc)}
.meta{color:var(--mut);font-size:12px;margin-top:6px}
.grid{display:flex;flex-wrap:wrap;gap:12px;padding:0 24px}
.card{background:var(--card);border:1px solid #2a325a;border-radius:10px;padding:12px 14px;min-width:180px}
.cname{font-weight:700;font-size:15px}.cmeta{color:var(--mut);font-size:12px;margin-top:4px}
code{background:#0c1020;padding:1px 5px;border-radius:4px;color:#9fe0ff}
.wrap{padding:0 24px 40px}
table{width:100%%;border-collapse:collapse;margin-top:8px;font-size:13px}
th,td{border-bottom:1px solid #232a4a;padding:7px 8px;text-align:left;vertical-align:top}
th{color:var(--mut);font-weight:600}
.role-narr{color:var(--nar);font-weight:600}.role-char{color:var(--ink)}
.muted{color:var(--mut)}input{margin:0 24px 12px;padding:6px 10px;border-radius:6px;border:1px solid #2a325a;background:#0c1020;color:var(--ink)}
</style></head>
<body>
<header><h1>🎙️ 配音看板 · %s</h1>
<div class="meta">语言 %s · 厂商 %s · 生成 %s · 时间轴对齐 subtitle: %s</div></header>
<h2>角色音色卡</h2><div class="grid">%s</div>
<h2>旁白段</h2><div class="wrap"><ul>%s</ul></div>
<h2>逐句时间轴</h2>
<input id="q" placeholder="过滤角色 / 文本…">
<div class="wrap"><table id="tbl"><thead><tr>
<th>镜号</th><th>时间</th><th>角色</th><th>音色</th><th>文本</th><th>情感</th><th>TTS参数</th>
</tr></thead><tbody>%s</tbody></table></div>
%s
<script>
var q=document.getElementById('q'),tbl=document.getElementById('tbl');
q.addEventListener('input',function(){var v=this.value.toLowerCase(),r=tbl.tBodies[0].rows;
for(var i=0;i<r.length;i++){var t=r[i].textContent.toLowerCase();r[i].style.display=t.indexOf(v)<0?'none':'';}});
</script>
</body></html>
""" % (
        html.escape(str(meta.get("title", "未命名"))),
        html.escape(str(meta.get("title", "未命名"))),
        html.escape(str(meta.get("lang", ""))),
        html.escape(str(meta.get("provider", ""))),
        html.escape(str(meta.get("generated_at", ""))),
        "是" if dub.get("timeline_aligned") else "否",
        cards_html, narr_html, rows_html, trans_html,
    )

    os.makedirs(args.out, exist_ok=True)
    board_path = os.path.join(args.out, "dub_board.html")
    with open(board_path, "w", encoding="utf-8") as f:
        f.write(html_doc)

    # ---- 导演备注 MD ----
    md = ["# 配音导演备注", "",
          "> 由 aladin-drama-dub 自动生成（规则化，非模型润色）。情绪/重音/停顿为可执行建议。",
          ""]
    md.append("**作品**：%s　**语言**：%s　**厂商**：%s" % (
        meta.get("title", ""), meta.get("lang", ""), meta.get("provider", "")))
    md.append("")
    cur_shot = None
    for ln in lines:
        if ln.get("shot_no") != cur_shot:
            cur_shot = ln.get("shot_no")
            md.append("## 镜号 %s" % cur_shot)
            md.append("")
        who = "【旁白】" if ln.get("role") == "narrator" else "【%s】" % ln.get("character")
        md.append("- %s %s" % (who, ln.get("text", "")))
        md.append("  - 情感：`%s`　音色：%s" % (ln.get("emotion"), ln.get("voice")))
        md.append("  - 导演建议：%s" % director_note(ln))
    notes_path = os.path.join(args.out, "dub_notes.md")
    with open(notes_path, "w", encoding="utf-8") as f:
        f.write("\n".join(md) + "\n")

    print("[dub_report] -> %s" % board_path)
    print("[dub_report] -> %s" % notes_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
