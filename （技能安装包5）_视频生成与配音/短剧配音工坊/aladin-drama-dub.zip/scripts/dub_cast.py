#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dub_cast.py - 扫描剧本角色，分配稳定音色，识别旁白，逐句标注。

输入: --script  _script.json
输出: --out/cast.json  (角色->音色映射)
      --out/lines.json (逐句配音条目)
仅依赖 Python 标准库。
"""
import argparse
import csv
import hashlib
import json
import os
import sys
from datetime import datetime, timezone

NARRATOR_ALIASES = {
    "旁白", "narrator", "narration", "解说", "画外音", "vo", "voiceover",
    "叙述者", "报幕", "独白",
}

# 各厂商音色池（稳定、可复现；narrator 用专属音色）
VOICE_POOLS = {
    "edge": {
        "narrator": "zh-CN-XiaoxiaoNeural",
        "pool": [
            "zh-CN-YunxiNeural", "zh-CN-YunyangNeural", "zh-CN-YunjianNeural",
            "zh-CN-XiaoyiNeural", "zh-CN-YunxiaNeural", "zh-CN-YunfengNeural",
            "zh-CN-XiaohanNeural", "zh-CN-XiaomengNeural", "zh-CN-YunzeNeural",
            "zh-CN-XiaochenNeural",
        ],
    },
    "azure": {
        "narrator": "zh-CN-XiaoxiaoNeural",
        "pool": [
            "zh-CN-YunxiNeural", "zh-CN-YunyangNeural", "zh-CN-YunjianNeural",
            "zh-CN-XiaoyiNeural", "zh-CN-YunxiaNeural", "zh-CN-YunfengNeural",
            "zh-CN-XiaohanNeural", "zh-CN-XiaomengNeural", "zh-CN-YunzeNeural",
            "zh-CN-XiaochenNeural",
        ],
    },
    "volcano": {
        "narrator": "volcano_zh_female_narrator",
        "pool": [
            "volcano_zh_male_1", "volcano_zh_female_1", "volcano_zh_male_2",
            "volcano_zh_female_2", "volcano_zh_male_3", "volcano_zh_female_3",
            "volcano_zh_male_child", "volcano_zh_female_child",
            "volcano_zh_male_old", "volcano_zh_female_old",
        ],
    },
    "cosyvoice": {
        "narrator": "cosyvoice_cn_narrator",
        "pool": [
            "cosyvoice_cn_male_1", "cosyvoice_cn_female_1", "cosyvoice_cn_male_2",
            "cosyvoice_cn_female_2", "cosyvoice_cn_male_3", "cosyvoice_cn_female_3",
            "cosyvoice_cn_male_funny", "cosyvoice_cn_female_sweet",
            "cosyvoice_cn_male_calm", "cosyvoice_cn_female_loli",
        ],
    },
}

DEFAULT_EMOTION = "neutral"


def is_narrator(name):
    if not name:
        return False
    return name.strip().lower() in NARRATOR_ALIASES


def stable_voice(character, provider, pool, narrator_voice, voice_map=None):
    """角色名 -> 稳定音色（sha256 哈希到音色池）。可复现。"""
    if voice_map and character in voice_map:
        return voice_map[character]
    if is_narrator(character):
        return narrator_voice
    h = hashlib.sha256(character.encode("utf-8")).hexdigest()
    idx = int(h, 16) % len(pool)
    return pool[idx]


def estimate_duration(text):
    """缺时间轴时按字数估算：中文 ~0.28s/字，字母 ~0.08s/字符，基础 0.6s。"""
    cjk = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
    other = len(text) - cjk
    return round(0.6 + cjk * 0.28 + other * 0.08, 2)


def build_cast(script, provider, voice_map):
    pool_cfg = VOICE_POOLS.get(provider, VOICE_POOLS["edge"])
    narrator_voice = pool_cfg["narrator"]
    pool = pool_cfg["pool"]

    characters = {}
    # 先收集所有出现过的角色
    for scene in script.get("scenes", []):
        for d in scene.get("dialogues", []):
            name = d.get("character")
            if name is None:
                continue
            characters[name] = True

    cast = {}
    for name in characters:
        role = "narrator" if is_narrator(name) else "character"
        voice = stable_voice(name, provider, pool, narrator_voice, voice_map)
        cast[name] = {
            "role": role,
            "voice": voice,
            "provider": provider,
            "assigned_by": "voice_map" if (voice_map and name in voice_map) else "hash",
        }
    return cast


def build_lines(script, cast):
    """逐句标注：shot_no/角色/音色/文本/时长/情感/起止时间。"""
    lines = []
    cursor = 0.0  # 全局时间游标（缺时间轴时顺序排）
    for scene in script.get("scenes", []):
        shot_no = scene.get("shot_no", scene.get("scene_no", 0))
        start_hint = scene.get("start")
        base = float(start_hint) if isinstance(start_hint, (int, float)) else None
        local_cursor = base if base is not None else cursor
        for d in scene.get("dialogues", []):
            name = d.get("character")
            text = d.get("text", "")
            emotion = d.get("emotion", DEFAULT_EMOTION)
            s = d.get("start")
            e = d.get("end")
            if isinstance(s, (int, float)) and isinstance(e, (int, float)):
                start, end = float(s), float(e)
                estimated = False
            else:
                dur = estimate_duration(text)
                start, end = local_cursor, local_cursor + dur
                local_cursor = end
                estimated = True
            lines.append({
                "shot_no": shot_no,
                "character": name,
                "role": cast.get(name, {}).get("role", "character"),
                "voice": cast.get(name, {}).get("voice", ""),
                "text": text,
                "emotion": emotion,
                "start": round(start, 2),
                "end": round(end, 2),
                "duration": round(end - start, 2),
                "estimated": estimated,
            })
        if base is None:
            cursor = local_cursor
    return lines


def _apply_playbook(cast, provider, playbook):
    """复盘反哺：对历史验证留存明显高于基准、且样本足够的角色，直接套用验证音色。

    仅当 playbook 中该角色 best_provider 与本次 provider 一致、且 best_voice 与默认分配不同，
    且 assigned_by 非 voice_map（用户显式指定优先）时，才覆盖；保持确定性、可复算。
    """
    if not playbook:
        return cast
    chars = playbook.get("characters", {})
    g = playbook.get("global", {})
    base = (g.get("retention_sum", 0.0) / g["n"]) if g.get("n") else 0.5
    for name, info in cast.items():
        csub = chars.get(name)
        if not csub:
            continue
        if info.get("assigned_by") == "voice_map":
            continue
        if csub.get("best_provider") != provider:
            continue
        if csub.get("n", 0) < 2:
            continue
        avg_ret = csub.get("avg_retention", base)
        if avg_ret <= base + 0.02:  # 无明显正向验证，保持默认哈希分配
            continue
        best = csub.get("best_voice")
        if best and best != info.get("voice"):
            info["voice"] = best
            info["assigned_by"] = "playbook"
    return cast


def main(argv=None):
    ap = argparse.ArgumentParser(description="剧本角色音色分配与逐句标注")
    ap.add_argument("--script", required=True, help="_script.json 路径")
    ap.add_argument("--provider", default="edge",
                    choices=list(VOICE_POOLS.keys()), help="TTS 厂商")
    ap.add_argument("--voice-map", default=None, help="可选 角色->音色 JSON")
    ap.add_argument("--lang", default=None, help="源语言(默认读 script.lang)")
    ap.add_argument("--playbook", default=None,
                    help="可选 验证库 dub_playbook.json：对历史验证的正向音色直接套用")
    ap.add_argument("--out", required=True, help="输出目录")
    args = ap.parse_args(argv)

    with open(args.script, "r", encoding="utf-8") as f:
        script = json.load(f)

    voice_map = None
    if args.voice_map:
        with open(args.voice_map, "r", encoding="utf-8") as f:
            voice_map = json.load(f)

    playbook = None
    if args.playbook and os.path.exists(args.playbook):
        with open(args.playbook, "r", encoding="utf-8") as f:
            playbook = json.load(f)

    lang = args.lang or script.get("lang", "zh-CN")
    cast = build_cast(script, args.provider, voice_map)
    if playbook:
        cast = _apply_playbook(cast, args.provider, playbook)
    lines = build_lines(script, cast)

    os.makedirs(args.out, exist_ok=True)
    cast_doc = {
        "title": script.get("title", ""),
        "lang": lang,
        "provider": args.provider,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "characters": cast,
    }
    lines_doc = {
        "title": script.get("title", ""),
        "lang": lang,
        "provider": args.provider,
        "lines": lines,
    }
    cast_path = os.path.join(args.out, "cast.json")
    lines_path = os.path.join(args.out, "lines.json")
    with open(cast_path, "w", encoding="utf-8") as f:
        json.dump(cast_doc, f, ensure_ascii=False, indent=2)
    with open(lines_path, "w", encoding="utf-8") as f:
        json.dump(lines_doc, f, ensure_ascii=False, indent=2)

    print("[dub_cast] 角色数=%d 台词数=%d" % (len(cast), len(lines)))
    print("[dub_cast] -> %s" % cast_path)
    print("[dub_cast] -> %s" % lines_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
