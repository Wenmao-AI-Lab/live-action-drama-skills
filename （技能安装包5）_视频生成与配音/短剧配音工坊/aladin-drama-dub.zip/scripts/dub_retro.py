#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""aladin-drama-dub · 第4步：配音复盘反哺闭环（dub_retro.py）

纯标准库。把「已发布短剧的真实配音表现」回收为验证库 dub_playbook.json，
让下次 dub_cast/dub_plan --playbook 越配越准：

  add       把一份已发布配音方案（_dub.json）+ 真实表现（dub_perf.json）沉淀进验证库
  summary   跨剧聚合最有效「音色 / 角色→最佳音色 / 情感基调」
  benchmark 对一份 _dub.json 对标历史库，给每条音轨的「预测留存」提示
  seed      写入示例验证库，上手即见效果

闭环：dub_plan(配音方案) → edit(混音) → publish(发布) → traffic/insight(真实表现)
      → dub_retro add(沉淀) → 下次 dub_cast --playbook(套用验证音色)
      / dub_plan --playbook(按验证情感放大演绎、给验证提示，越配越准)
"""
import sys
import os
import json
import argparse
from datetime import datetime, timezone


def _load(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def _safe(v, lo=0.0, hi=1.0, default=0.0):
    try:
        x = float(v)
    except Exception:
        return default
    return max(lo, min(hi, x))


def _default_playbook():
    return {
        "updated_at": "",
        "samples": 0,
        "global": {"n": 0, "retention_sum": 0.0, "engagement_sum": 0.0},
        "voices": {},       # provider|voice -> {n, retention_sum, engagement_sum}
        "characters": {},   # character -> {n, retention_sum, engagement_sum, best_voice, best_provider}
        "emotions": {},     # emotion -> {n, retention_sum, engagement_sum}
        "styles": {},       # provider|style -> {n, retention_sum}
    }


def _acc(d, key, retention, engagement=None):
    sub = d.setdefault(key, {"n": 0, "retention_sum": 0.0, "engagement_sum": 0.0})
    sub["n"] += 1
    sub["retention_sum"] += retention
    if engagement is not None:
        sub["engagement_sum"] += engagement
    return sub


def _avg_ret(sub, base):
    return (sub["retention_sum"] / sub["n"]) if sub.get("n") else base


def _base(pb):
    g = pb["global"]
    return (g["retention_sum"] / g["n"]) if g["n"] else 0.5


def cmd_add(args):
    dub = _load(args.dub)
    perf = _load(args.perf) if args.perf and os.path.exists(args.perf) else {}
    if not isinstance(perf, dict):
        perf = {}

    pb_path = args.playbook
    pb = _default_playbook()
    if os.path.exists(pb_path):
        try:
            pb = _load(pb_path)
            for k in ("global", "voices", "characters", "emotions", "styles"):
                pb.setdefault(k, {} if k != "global" else {"n": 0, "retention_sum": 0.0, "engagement_sum": 0.0})
            pb.setdefault("samples", 0)
        except Exception:
            pb = _default_playbook()

    platform = args.platform or dub.get("meta", {}).get("provider", "未知")
    tracks = dub.get("tracks", [])
    base = _base(pb)
    perf_tracks = perf.get("tracks", {}) or {}
    perf_emotions = perf.get("emotions", {}) or {}

    added = 0
    # 按音轨（角色→音色）沉淀
    for t in tracks:
        name = t.get("character")
        voice = t.get("voice")
        provider = t.get("provider")
        fb = perf_tracks.get(name) or {}
        if not fb:
            continue
        retention = _safe(fb.get("retention"), 0.0, 1.0, 0.0)
        engagement = _safe(fb.get("engagement"), 0.0, 1.0, 0.0)
        pb["global"]["n"] += 1
        pb["global"]["retention_sum"] += retention
        pb["global"]["engagement_sum"] += engagement
        _acc(pb["voices"], "%s|%s" % (provider, voice), retention, engagement)
        csub = pb["characters"].setdefault(name, {
            "n": 0, "retention_sum": 0.0, "engagement_sum": 0.0,
            "best_voice": voice, "best_provider": provider})
        csub["n"] += 1
        csub["retention_sum"] += retention
        csub["engagement_sum"] += engagement
        # 记录留存最高的音色（同角色跨剧）
        if retention > _avg_ret(csub, base):
            csub["best_voice"] = voice
            csub["best_provider"] = provider
        # 情感维度
        for seg in t.get("segments", []):
            emo = seg.get("emotion")
            if not emo:
                continue
            er = _safe(perf_emotions.get(emo), 0.0, 1.0, 0.0)
            if er <= 0.0:
                continue
            _acc(pb["emotions"], emo, er)
            st = seg.get("style")
            if st:
                _acc(pb["styles"], "%s|%s" % (provider, st), er)
        added += 1

    pb["samples"] += 1
    pb["updated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # 派生均值
    for bucket in ("voices", "characters", "emotions", "styles"):
        for k, sub in pb[bucket].items():
            sub["avg_retention"] = round(_avg_ret(sub, base), 4)
    pb["global"]["avg_retention"] = round(_avg_ret(pb["global"], base), 4)

    with open(pb_path, "w", encoding="utf-8") as f:
        json.dump(pb, f, ensure_ascii=False, indent=2)

    print("✅ 已沉淀配音复盘：%s" % pb_path)
    print("   本次新增 %d 条音轨表现 ｜ 累计样本 %d ｜ 平台/厂商 %s" % (
        added, pb["samples"], platform))
    if added:
        print("   全局基准留存分 %.2f（满分 1.0）" % pb["global"]["avg_retention"])


def cmd_summary(args):
    pb_path = args.playbook
    if not os.path.exists(pb_path):
        print("⚠️ 尚无验证库 %s，先跑 dub_retro add（或 dub_retro seed）。" % pb_path)
        return
    pb = _load(pb_path)
    base = _base(pb)
    print("📊 配音验证库（样本 %d，全局基准留存分 %.2f）" % (pb.get("samples", 0), base))

    def _rank(bucket, title, fmt=lambda k, v: k):
        rows = sorted(pb.get(bucket, {}).items(),
                      key=lambda kv: kv[1].get("avg_retention", 0), reverse=True)
        if not rows:
            print("\n【%s】暂无数据" % title)
            return
        print("\n【%s】（按留存分降序）" % title)
        for k, v in rows:
            lift = (v.get("avg_retention", base) - base) * 100
            print("   · %s：留存 %.2f（%s%.1f%%，%d 样本）" % (
                fmt(k, v), v.get("avg_retention", base),
                "+" if lift >= 0 else "", lift, v.get("n", 0)))

    _rank("voices", "音色 → 留存", fmt=lambda k, v: k.split("|", 1)[-1])
    _rank("characters", "角色 → 最佳音色",
          fmt=lambda k, v: "%s → %s" % (k, v.get("best_voice", "—")))
    _rank("emotions", "情感基调 → 留存")
    _rank("styles", "情感风格 → 留存", fmt=lambda k, v: k.split("|", 1)[-1])


def cmd_benchmark(args):
    pb_path = args.playbook
    if not os.path.exists(pb_path):
        print("⚠️ 尚无验证库 %s，先跑 dub_retro add（或 dub_retro seed）。" % pb_path)
        return
    pb = _load(pb_path)
    dub = _load(args.dub)
    base = _base(pb)
    tracks = dub.get("tracks", [])

    print("🎯 配音预测（对标历史库）· 基准留存分 %.2f" % base)
    validated = 0
    for t in tracks:
        voice = t.get("voice")
        provider = t.get("provider")
        vsub = pb["voices"].get("%s|%s" % (provider, voice))
        emos = [s.get("emotion") for s in t.get("segments", []) if s.get("emotion")]
        vals = []
        parts = []
        if vsub:
            parts.append("音色=%s" % voice); vals.append(vsub["avg_retention"]); validated += 1
        emo_hits = 0
        for em in set(emos):
            esub = pb["emotions"].get(em)
            if esub:
                parts.append("情感=%s" % em); vals.append(esub["avg_retention"])
                emo_hits += 1
        pred = sum(vals) / len(vals) if vals else base
        lift = (pred - base) * 100
        flag = "✅验证结构" if vals else "⚠️无历史"
        print("   %s（%s）：预测留存 %.2f（%s%.1f%%）[%s]" % (
            t.get("character"), t.get("role", "character"), pred,
            "+" if lift >= 0 else "", lift, flag))
    total = len(tracks)
    print("   结构覆盖验证率：%.0f%%（%d/%d 音轨命中历史库）" % (
        (validated / total * 100) if total else 0, validated, total))


def cmd_seed(args):
    """写入一份示例验证库，开箱即用。"""
    pb_path = args.playbook
    base = 0.5
    pb = _default_playbook()
    # 示例：女主「林夕」用 XiaoyiNeural 留存最高；愤怒/紧张类情感留存更高
    demo = [
        # (provider, voice, character, emotion_list, retention, engagement)
        ("edge", "zh-CN-XiaoyiNeural", "林夕", ["疲惫", "温柔", "坚定"], 0.62, 0.48),
        ("edge", "zh-CN-YunyangNeural", "顾辰", ["严肃", "愤怒"], 0.58, 0.40),
        ("edge", "zh-CN-XiaoxiaoNeural", "旁白", ["平静", "悬念"], 0.66, 0.52),
        ("edge", "zh-CN-YunxiaNeural", "苏暖", ["开心", "温柔"], 0.60, 0.45),
    ]
    for provider, voice, character, emos, ret, eng in demo:
        pb["global"]["n"] += 1
        pb["global"]["retention_sum"] += ret
        pb["global"]["engagement_sum"] += eng
        _acc(pb["voices"], "%s|%s" % (provider, voice), ret, eng)
        csub = pb["characters"].setdefault(character, {
            "n": 0, "retention_sum": 0.0, "engagement_sum": 0.0,
            "best_voice": voice, "best_provider": provider})
        csub["n"] += 1
        csub["retention_sum"] += ret
        csub["engagement_sum"] += eng
        csub["best_voice"] = voice
        csub["best_provider"] = provider
        for em in emos:
            _acc(pb["emotions"], em, ret)
    pb["samples"] = 1
    pb["updated_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    for bucket in ("voices", "characters", "emotions", "styles"):
        for k, sub in pb[bucket].items():
            sub["avg_retention"] = round(_avg_ret(sub, base), 4)
    pb["global"]["avg_retention"] = round(_avg_ret(pb["global"], base), 4)
    with open(pb_path, "w", encoding="utf-8") as f:
        json.dump(pb, f, ensure_ascii=False, indent=2)
    print("📝 已生成示例验证库：%s" % pb_path)
    print("   运行 `dub_retro.py summary --playbook %s` 查看；或 `dub_retro.py benchmark --dub <你的_dub.json> --playbook %s` 对标。" % (pb_path, pb_path))


def main():
    ap = argparse.ArgumentParser(description="配音复盘反哺闭环")
    sub = ap.add_subparsers(dest="cmd")

    a = sub.add_parser("add", help="沉淀一份已发布配音方案的真实表现")
    a.add_argument("--dub", required=True, help="已发布的 _dub.json")
    a.add_argument("--perf", default=None, help="表现反馈 dub_perf.json：{tracks:{角色:{retention,engagement}}, emotions:{情感:retention}}")
    a.add_argument("--platform", default=None, help="覆盖平台/厂商标记")
    a.add_argument("--playbook", default="dub_playbook.json")

    s = sub.add_parser("summary", help="跨剧聚合最佳音色/角色音色/情感")
    s.add_argument("--playbook", default="dub_playbook.json")

    b = sub.add_parser("benchmark", help="对 _dub.json 做预测留存对标")
    b.add_argument("--dub", required=True)
    b.add_argument("--playbook", default="dub_playbook.json")

    d = sub.add_parser("seed", help="写入示例验证库，上手即见效果")
    d.add_argument("--playbook", default="dub_playbook.json")

    args = ap.parse_args()
    if args.cmd == "add":
        cmd_add(args)
    elif args.cmd == "summary":
        cmd_summary(args)
    elif args.cmd == "benchmark":
        cmd_benchmark(args)
    elif args.cmd == "seed":
        cmd_seed(args)
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
