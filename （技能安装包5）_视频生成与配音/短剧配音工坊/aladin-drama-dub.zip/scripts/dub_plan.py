#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dub_plan.py - 由逐句标注生成配音方案 _dub.json 与音轨清单 dub_manifest.csv。

输入: --lines lines.json  --cast cast.json
输出: --out/_dub.json  --out/dub_manifest.csv
仅依赖 Python 标准库。不调用任何付费 TTS/翻译 API。
"""
import argparse
import csv
import json
import os
import sys
from datetime import datetime, timezone

PROVIDER_MODEL = {
    "edge": "edge-tts",
    "azure": "azure-cognitive-services",
    "volcano": "volcano-tts",
    "cosyvoice": "cosyvoice",
}

# 情感 -> TTS style（edge/azure 风格名；volcano/cosyvoice 取 default 亦可）
EMOTION_TO_STYLE = {
    "neutral": "general", "平静": "general", "普通": "general",
    "happy": "cheerful", "兴奋": "cheerful", "开心": "cheerful", "喜悦": "cheerful",
    "sad": "sad", "悲伤": "sad", "难过": "sad",
    "angry": "angry", "愤怒": "angry", "生气": "angry",
    "fear": "fearful", "恐惧": "fearful", "害怕": "fearful",
    "serious": "serious", "严肃": "serious", "冷酷": "serious",
    "soft": "soft", "温柔": "soft", "轻柔": "soft",
    "question": "polite", "疑问": "polite", "疑惑": "polite",
    "tender": "tender", "慈祥": "tender",
    "anxious": "serious", "焦虑": "serious",
    "excited": "cheerful", "激动": "cheerful",
}

# 情感 -> 细微 TTS 微调（确定性，便于复算）
EMOTION_TO_RATE = {
    "neutral": "+0%", "平静": "+0%", "普通": "+0%",
    "happy": "+6%", "兴奋": "+8%", "开心": "+6%", "喜悦": "+6%",
    "excited": "+8%", "激动": "+8%",
    "sad": "-6%", "悲伤": "-6%", "难过": "-6%",
    "angry": "+10%", "愤怒": "+10%", "生气": "+10%",
    "fear": "-4%", "恐惧": "-4%", "害怕": "-4%",
    "serious": "-2%", "严肃": "-2%", "冷酷": "-2%", "焦虑": "+2%", "anxious": "+2%",
    "soft": "-4%", "温柔": "-4%", "轻柔": "-4%", "tender": "-4%", "慈祥": "-4%",
    "question": "+2%", "疑问": "+2%", "疑惑": "+2%",
}
EMOTION_TO_PITCH = {
    "neutral": "+0Hz", "平静": "+0Hz", "普通": "+0Hz",
    "happy": "+4Hz", "兴奋": "+6Hz", "开心": "+4Hz", "喜悦": "+4Hz", "excited": "+6Hz", "激动": "+6Hz",
    "sad": "-4Hz", "悲伤": "-4Hz", "难过": "-4Hz",
    "angry": "+6Hz", "愤怒": "+6Hz", "生气": "+6Hz",
    "fear": "-2Hz", "恐惧": "-2Hz", "害怕": "-2Hz",
    "serious": "-2Hz", "严肃": "-2Hz", "冷酷": "-2Hz", "焦虑": "+2Hz", "anxious": "+2Hz",
    "soft": "-2Hz", "温柔": "-2Hz", "轻柔": "-2Hz", "tender": "-2Hz", "慈祥": "-2Hz",
    "question": "+2Hz", "疑问": "+2Hz", "疑惑": "+2Hz",
}
EMOTION_TO_VOLUME = {
    "angry": "+4%", "愤怒": "+4%", "生气": "+4%",
    "fear": "-4%", "恐惧": "-4%", "害怕": "-4%", "sad": "-2%", "悲伤": "-2%", "难过": "-2%",
}
DEFAULT_RATE = "+0%"
DEFAULT_PITCH = "+0Hz"
DEFAULT_VOLUME = "+0%"

# 复盘反哺：对历史验证留存明显高于基准的情感，放大其演绎参数（确定性、可复算）
PLAYBOOK_BOOST = 1.25
import re as _re

_RATE_RE = _re.compile(r"^([+-]?\d+(?:\.\d+)?)%$")
_HZ_RE = _re.compile(r"^([+-]?\d+(?:\.\d+)?)Hz$")


def _scale_delta(s, factor, lo, hi):
    """放大一个 delta 字符串的幅度并夹紧到合法范围。"""
    m = _RATE_RE.match(s.strip()) or _HZ_RE.match(s.strip())
    if not m:
        return s
    num = float(m.group(1))
    unit = "%" if s.strip().endswith("%") else "Hz"
    new = max(lo, min(hi, num * factor))
    return "%+g%s" % (new, unit)


def _playbook_base(pb):
    g = pb.get("global", {})
    return (g.get("retention_sum", 0.0) / g["n"]) if g.get("n") else 0.5


def boosted_params(emotion, provider, pb):
    """返回 (rate, pitch, volume, style, hint)。

    若情感在历史验证库中存在且留存明显高于基准(n>=2)，则放大 rate/pitch/volume 的
    情感幅度并给出"验证情感·高留存"提示；否则保持默认情感参数、提示"无历史"。
    """
    rate = EMOTION_TO_RATE.get(emotion, DEFAULT_RATE)
    pitch = EMOTION_TO_PITCH.get(emotion, DEFAULT_PITCH)
    volume = EMOTION_TO_VOLUME.get(emotion, DEFAULT_VOLUME)
    style = style_for(emotion, provider)
    hint = "无历史"
    if pb:
        esub = pb.get("emotions", {}).get(emotion)
        if esub and esub.get("n", 0) >= 2:
            base = _playbook_base(pb)
            avg = esub.get("avg_retention", base)
            if avg > base + 0.02:
                rate = _scale_delta(rate, PLAYBOOK_BOOST, -50, 50)
                pitch = _scale_delta(pitch, PLAYBOOK_BOOST, -100, 100)
                volume = _scale_delta(volume, PLAYBOOK_BOOST, -50, 50)
                hint = "验证情感·高留存(%.2f)" % avg
            elif avg < base - 0.02:
                hint = "验证情感·偏低(%.2f)⚠" % avg
            else:
                hint = "验证情感·持平(%.2f)" % avg
    return rate, pitch, volume, style, hint


def style_for(emotion, provider):
    st = EMOTION_TO_STYLE.get(emotion, "general")
    # volcano/cosyvoice 风格支持有限，统一给 default 兜底
    if provider in ("volcano", "cosyvoice"):
        return "default"
    return st


def params_for(emotion, provider):
    rate = EMOTION_TO_RATE.get(emotion, DEFAULT_RATE)
    pitch = EMOTION_TO_PITCH.get(emotion, DEFAULT_PITCH)
    volume = EMOTION_TO_VOLUME.get(emotion, DEFAULT_VOLUME)
    return {
        "model": PROVIDER_MODEL.get(provider, provider),
        "voice": None,  # 由调用方按角色填
        "rate": rate,
        "pitch": pitch,
        "volume": volume,
        "style": style_for(emotion, provider),
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description="生成配音方案与音轨清单")
    ap.add_argument("--lines", required=True, help="lines.json 路径")
    ap.add_argument("--cast", required=True, help="cast.json 路径")
    ap.add_argument("--provider", default=None, help="厂商(默认读 cast)")
    ap.add_argument("--lang", default=None, help="源语言")
    ap.add_argument("--translate", default=None, help="可选目标语言,逗号分隔 如 en,ja")
    ap.add_argument("--playbook", default=None,
                    help="可选 验证库 dub_playbook.json：按验证情感放大演绎、附验证提示")
    ap.add_argument("--out", required=True, help="输出目录")
    args = ap.parse_args(argv)

    with open(args.lines, "r", encoding="utf-8") as f:
        lines_doc = json.load(f)
    with open(args.cast, "r", encoding="utf-8") as f:
        cast_doc = json.load(f)

    playbook = None
    if args.playbook and os.path.exists(args.playbook):
        with open(args.playbook, "r", encoding="utf-8") as f:
            playbook = json.load(f)

    provider = args.provider or cast_doc.get("provider", "edge")
    lang = args.lang or cast_doc.get("lang", "zh-CN")
    lines = lines_doc.get("lines", [])
    cast = cast_doc.get("characters", {})

    # 按角色聚合音轨（逐行计算参数，支持 playbook 放大情感演绎）
    tracks = {}
    narration = []
    line_params = {}   # (shot_no, character, text) -> (rate,pitch,volume,style,hint)
    for ln in lines:
        name = ln.get("character")
        voice = ln.get("voice") or cast.get(name, {}).get("voice", "")
        emotion = ln.get("emotion", "neutral")
        rate, pitch, volume, style, hint = boosted_params(emotion, provider, playbook)
        line_params[(ln.get("shot_no"), name, ln.get("text"))] = (rate, pitch, volume, style, hint)
        seg = {
            "shot_no": ln.get("shot_no"),
            "start": ln.get("start"),
            "end": ln.get("end"),
            "text": ln.get("text"),
            "emotion": emotion,
            "playbook_hint": hint,
            "rate": rate, "pitch": pitch,
            "volume": volume, "style": style,
        }
        t = tracks.setdefault(name, {
            "character": name,
            "role": ln.get("role", "character"),
            "voice": voice,
            "provider": provider,
            "model": PROVIDER_MODEL.get(provider, provider),
            "segments": [],
            "suggested_voice": None,
        })
        t["segments"].append(seg)
        if ln.get("role") == "narrator":
            narration.append({
                "shot_no": ln.get("shot_no"),
                "start": ln.get("start"), "end": ln.get("end"),
                "text": ln.get("text"), "voice": voice,
                "playbook_hint": hint,
                "rate": rate, "pitch": pitch,
                "volume": volume, "style": style,
            })

    # playbook 建议音色：历史验证留存明显更高、同厂商、且与当前分配不同的角色
    if playbook:
        base = _playbook_base(playbook)
        for name, t in tracks.items():
            csub = playbook.get("characters", {}).get(name)
            if not csub or csub.get("n", 0) < 2:
                continue
            if csub.get("best_provider") != provider:
                continue
            best = csub.get("best_voice")
            if best and best != t.get("voice") and csub.get("avg_retention", base) > base + 0.02:
                t["suggested_voice"] = best

    track_list = list(tracks.values())

    # 多语种占位（不调 API）
    translations = []
    if args.translate:
        for tlang in [x.strip() for x in args.translate.split(",") if x.strip()]:
            items = []
            for ln in lines:
                items.append({
                    "shot_no": ln.get("shot_no"),
                    "character": ln.get("character"),
                    "source": ln.get("text"),
                    "target": None,
                    "note": "规则占位：请用翻译API或人工翻译原文（不调付费API）",
                })
            translations.append({"lang": tlang, "items": items})

    dub = {
        "meta": {
            "title": lines_doc.get("title", ""),
            "lang": lang,
            "provider": provider,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "tool": "aladin-drama-dub",
            "version": "1.1.0",
            "playbook_boosted": bool(playbook),
        },
        "timeline_aligned": True,
        "subtitle_ref": "aladin-drama-subtitle:_subtitle.json",
        "edit_audio_input": "_dub.json",
        "tracks": track_list,
        "narration": narration,
        "translations": translations,
    }

    os.makedirs(args.out, exist_ok=True)
    dub_path = os.path.join(args.out, "_dub.json")
    with open(dub_path, "w", encoding="utf-8") as f:
        json.dump(dub, f, ensure_ascii=False, indent=2)

    # 音轨清单 CSV（逐句，参数与 _dub.json 一致）
    csv_path = os.path.join(args.out, "dub_manifest.csv")
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["shot_no", "character", "role", "voice", "provider",
                    "start", "end", "duration", "text", "emotion",
                    "rate", "pitch", "volume", "style", "estimated", "playbook_hint"])
        for ln in lines:
            rate, pitch, volume, style, hint = line_params.get(
                (ln.get("shot_no"), ln.get("character"), ln.get("text")),
                (EMOTION_TO_RATE.get(ln.get("emotion", "neutral"), DEFAULT_RATE),
                 EMOTION_TO_PITCH.get(ln.get("emotion", "neutral"), DEFAULT_PITCH),
                 EMOTION_TO_VOLUME.get(ln.get("emotion", "neutral"), DEFAULT_VOLUME),
                 style_for(ln.get("emotion", "neutral"), provider), "无历史"))
            w.writerow([
                ln.get("shot_no"), ln.get("character"), ln.get("role"),
                ln.get("voice"), provider, ln.get("start"), ln.get("end"),
                ln.get("duration"), ln.get("text"), ln.get("emotion"),
                rate, pitch, volume, style, ln.get("estimated", False), hint,
            ])

    print("[dub_plan] tracks=%d narration=%d lines=%d translate=%s"
          % (len(track_list), len(narration), len(lines), args.translate or "-"))
    print("[dub_plan] -> %s" % dub_path)
    print("[dub_plan] -> %s" % csv_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
