---

name: aladin-drama-dub
slug: "aladin-drama-dub"
version: 1.0.0
displayName: 阿拉丁·AI短剧配音工坊｜角色音色分配·旁白生成·TTS参数·音轨清单·多语种
summary: 阿拉丁出品的 AI 短剧配音工坊：把剧本台词变成可执行的配音方案——角色音色稳定分配、旁白自动识别、逐句情感标注、多语种占位翻译、TTS 参数清单、音轨时间轴对齐，纯本地零依赖生成参数、不调付费 API。比  飙升的各类"配音提示词/数字人"单点技能多出 结构化角色音色映射 + 旁白自动生成 + 多语种 + 与字幕/剪辑时间轴对齐 + 音轨清单，且全程不需要 pip 安装或第三方服务。
description: 阿拉丁·AI短剧配音工坊把「拿到剧本台词却不知道每个角色用什么音色、旁白怎么处理、TTS 怎么调参、音轨怎么排期」升级成一条纯本地零依赖工具链：角色名哈希到稳定音色池(可复现)、旁白自动识别、逐句情感基调标注、多语种占位翻译提示(不调API)、各厂商 TTS 参数清单(model/voice/rate/pitch/volume/style)、与 subtitle 时间轴对齐的音轨清单。比  飙升的配音提示词/数字人单点技能多出 结构化角色音色映射 + 旁白生成 + 多语种 + 与字幕剪辑时间轴对齐 + 音轨清单，全程不需要 pip 安装 / 付费 TTS API / 第三方服务，离线可用。触发词：AI短剧配音、短剧配音、角色音色分配、旁白生成、TTS参数、语音合成、配音方案、音轨清单、多语种配音、剧本配音、aladin dub、AI drama dub、voiceover、TTS、Azure TTS、Edge TTS、火山引擎、CosyVoice、阿拉丁配音。
category: audio
platforms:
  - AI助手
  - QClaw
  - ima
company: 阿拉丁
tags:
  - 阿拉丁
  - aladin
  - AI短剧
  - 配音
  - 旁白
  - TTS
  - 语音合成
  - dub
  - voiceover
  - 音轨
  - 多语种
  - 角色音色
  - EdgeTTS
  - AzureTTS
  - 火山引擎
  - CosyVoice
  - 剧本配音
  - 配音方案
  - 时间轴对齐
  - 短剧创作闭环
  - AI配音工坊
---




# 阿拉丁·AI短剧配音工坊（aladin-drama-dub）

> 阿拉丁出品。你用 `aladin-drama-script` 把选题变成结构化剧本 `_script.json`（台词+角色）、`aladin-drama-subtitle` 产出字幕、最后 `aladin-drama-edit` 混剪出成片——但剧本里的每一句台词"该用谁的音色、什么情绪、TTS 怎么调参、音轨怎么排"一直是人工拍脑袋。 飙升的各类"配音提示词 / 数字人"技能都是**单点**：要么只给一段提示词，要么只做某家 TTS 的封装，没有一款把"角色→音色→逐句参数→音轨清单→与字幕/剪辑时间轴对齐"收口成结构化方案。这个技能把配音收口成一套**纯本地、零依赖、离线可用**的工具：你给剧本（`_script.json`），它产出角色音色卡 + 旁白 + 逐句 TTS 参数 + 多语种占位 + 音轨清单（`_dub.json`），直接喂给 `aladin-drama-edit` 混音。

## 它解决什么痛点

用户在  上能找到的"配音向"工具都是单点：

| 现有飙升/常见技能 | 只做 | 不做 |
|------------------|------|------|
| 配音提示词类（各类"AI配音提示词"） | 给一段**通用提示词** | 不映射角色、不出参数清单、不对齐时间轴 |
| 数字人/克隆音色类 | 单一**某家 TTS 封装** | 不支持多厂商、不出音轨清单、不处理旁白 |
| Edge/Azure TTS 调用脚本 | **单句合成语音** | 不做角色分配、不做结构化方案、不对接剪辑 |
| 字幕/剪辑类 | 字幕或视频 | 不生成配音方案、不分配音色 |

**本技能 = 配音方案全链路**，脚本零依赖（仅 Python 标准库）、纯本地、离线可用，且比上述单点技能多出 **结构化角色音色映射 + 旁白自动生成 + 多语种占位 + 与字幕/剪辑时间轴对齐 + 音轨清单**。

## 与  现有技能 + 自家 aladin 系列的差异化

| 能力 | 单点配音技能 | **阿拉丁·AI短剧配音工坊(本款)** |
|------|----------------|-------------------------------|
| 角色→音色稳定分配(可复现) | ✗(人工) | ✓ 角色名哈希到音色池 |
| 旁白自动识别与单独处理 | ✗ | ✓ narrator 别名识别 |
| 逐句情感基调标注 | ✗ | ✓ 情绪→TTS style 映射 |
| 多语种占位翻译(不调API) | ✗ | ✓ 规则化翻译提示 |
| 各厂商 TTS 参数清单 | 部分 | ✓ edge/azure/volcano/cosyvoice |
| 与字幕/剪辑时间轴对齐 | ✗ | ✓ 共用 shot 时间轴 |
| 音轨清单(_dub.json 给 edit) | ✗ | ✓ tracks[] 结构化 |
| 零依赖 / 离线 | 部分需付费API | ✓ 纯标准库 |

## 何时触发

- "把这个剧本做成配音方案" / "短剧配音、角色音色怎么分配"
- "生成旁白、给每句台词标情绪和 TTS 参数"
- "出一份音轨清单 / 配音时间轴给剪辑用"
- "多语种配音、把中文剧本拆成英文/日文音轨"
- "用 Edge / Azure / 火山 / CosyVoice 的 TTS 参数排一下"
- 用户给出 `_script.json`（或台词+角色清单），想落地成可执行的配音方案（联动 `aladin-drama-edit` 混音、`aladin-drama-subtitle` 字幕）

## 何时不触发

- 用户要**真正调用付费 TTS 把语音合成出来**——本款只生成参数/方案，不调任何付费 API（如需合成，把 `_dub.json` 交给支持 TTS 的下游）
- 用户要**克隆/训练特定真人音色**——本款用厂商预设音色池，不做声纹克隆
- 用户要**写剧本/改台词**——那属于 `aladin-drama-script` 的职责
- 用户要**做字幕**——用 `aladin-drama-subtitle`（与本品共用时间轴）
- 用户要**混剪出成片**——用 `aladin-drama-edit`（本品的 `_dub.json` 是它的 `--audio` 输入）
- 用户要**搜索/安装**别人的技能——用 find skill /  install

## 能力边界

**能做：**
- 角色音色分配：角色名经 sha256 哈希映射到稳定音色池（同角色跨次运行结果一致，可复算）
- 旁白识别：角色名命中 旁白/narrator/解说/画外音 等别名即归为 narrator 并分配专属旁白音色
- 逐句标注：每行台词标注 角色/音色/情感基调/起止时间/时长
- 多语种占位：对 `--translate` 指定的目标语言，按规则生成「待译提示 + 原文」占位（**不调翻译/语音 API**）
- TTS 参数：按厂商产出 model/voice/rate/pitch/volume/style 字段
- 音轨清单：按角色聚合 tracks[]，含与 subtitle 时间轴对齐字段
- 可视化：自包含 `dub_board.html`（内联 CSS/JS，离线可看）+ `dub_notes.md` 导演备注

**不能做：**
- 不能**真正合成语音**（不调付费 TTS API，只产出参数方案）
- 不能**真实机器翻译**（多语种仅给占位提示，翻译需人工或下游 API）
- 不能**克隆真人声纹**（只用厂商预设音色）
- 不能保证**时长 100% 精确**（若剧本缺时间轴，按字数估算，需下游以实际语音为准）
- 不能绕过  安全审核

## 输入输出规范

**输入（命令行）：**
- `--script`：上游 `aladin-drama-script` 产出的 `_script.json`（含 scenes[].dialogues[].character/text/emotion 与时间轴）
- `--provider`：默认 `edge`，支持 `edge` / `azure` / `volcano` / `cosyvoice`
- `--voice-map`：可选，角色→音色 JSON（覆盖默认哈希分配）
- `--lang`：源语言，如 `zh-CN`（默认读取 script 内 lang，缺省 `zh-CN`）
- `--translate`：可选，逗号分隔目标语言，如 `en,ja`（仅占位）
- `--out`：产物输出目录

**输出（位于 `--out`）：**
- `cast.json`：角色→音色映射（含角色类型 narrator/character、provider）
- `lines.json`：逐句配音条目（shot_no/角色/音色/文本/时长/情感/起止时间）
- `_dub.json`：配音方案主产物（meta + tracks[] + narration[] + translations[] + 对齐字段）
- `dub_manifest.csv`：音轨清单明细（逐句可导入表格/剪辑）
- `dub_board.html`：自包含配音看板（角色音色卡 + 逐句时间轴 + 音轨清单）
- `dub_notes.md`：配音导演备注（情绪/重音/停顿建议）

## 工作流

### Step 1：角色音色分配 + 逐句标注（dub_cast.py）

```bash
PY="技能目录/.AI助手/binaries/python/versions/3.13.12/python.exe"
SKILL="<本技能目录>"
"$PY" "$SKILL/scripts/dub_cast.py" \
  --script "$SKILL/assets/sample_script.json" \
  --provider edge --lang zh-CN \
  --out ./build
```

产出 `cast.json`（角色→音色映射）+ `lines.json`（逐句配音条目）。

### Step 2：生成配音方案 + 音轨清单（dub_plan.py）

```bash
"$PY" "$SKILL/scripts/dub_plan.py" \
  --lines ./build/lines.json --cast ./build/cast.json \
  --provider edge --lang zh-CN --translate en,ja \
  --out ./build
```

产出 `_dub.json`（音轨清单/旁白/多语种占位/对齐字段）+ `dub_manifest.csv`。

### Step 3：生成看板 + 导演备注（dub_report.py）

```bash
"$PY" "$SKILL/scripts/dub_report.py" \
  --dub ./build/_dub.json --cast ./build/cast.json --lines ./build/lines.json \
  --out ./build
```

产出 `dub_board.html`（离线配音看板）+ `dub_notes.md`（导演备注）。

## 复用资源

| 文件 | 用途 | 加载时机 |
|------|------|----------|
| `references/usage-examples.md` | 4 个完整场景（单人旁白/多角色/多语种/自定义音色）+ 最佳实践 + FAQ | 用户要具体样例、或落地参考时加载 |
| `references/tts-providers.md` | edge/azure/volcano/cosyvoice 各厂商参数对照（voice 命名/rate/pitch/volume/style 范围） | Step 2 选厂商、或用户问"某家 TTS 怎么填参"时加载 |
| `references/ir-schema.md` | `_script.json` 与 `_dub.json` 完整结构定义（字段表 + 示例） | 用户对接上游 script 或下游 edit 时加载 |

## 重要约束

- **TRACE·只生成配音方案**：三脚本只产出参数/清单/方案，绝不调用付费 TTS/翻译 API（→ Traceability）
- **零依赖**：仅用 Python 标准库，离线可跑，不要求 pip 安装（→ Reliability）
- **可复算**：角色音色由角色名哈希决定，同输入同输出，跨次一致（→ Traceability）
- **台词不外传**：剧本仅在本地处理，不上传任何服务（→ Trust）
- **不编造翻译**：多语种仅给"待译提示 + 原文"占位，不伪造译文（→ Trust）
- **时长估算透明**：缺时间轴时按字数估算并标注 `estimated:true`，下游以实际语音为准（→ Convention）
- **description 单行**：禁用 YAML 多行语法，保持可发布（→ Convention）

## 与 aladin 短剧系列的关系

本技能是 `aladin`「AI短剧创作闭环」的**第 6 环（配音）**：

- **吃**：`aladin-drama-script` 产出的 `_script.json`（台词 + 角色 + 时间轴）
- **出**：`_dub.json`（配音方案/音轨清单/旁白文本），作为 `aladin-drama-edit` 的 `--audio` 输入用于混音
- **同时间轴**：与 `aladin-drama-subtitle` 共用同一 shot 时间轴，保证口型/字幕/配音三对齐
- **下游**：`aladin-drama-edit` 出成片 → `aladin-drama-publish` 发布 → `aladin-drama-traffic` 数据反哺 `aladin-drama-topic` 选题

闭环顺序：topic → 素材(material) → script(第5环·剧本) → **dub(第6环·本款·配音)** → subtitle(字幕) → edit(混剪) → publish(发布) → traffic(反哺)。
