# TTS 厂商参数对照（aladin-drama-dub）

> 本技能**只生成参数方案、不调用任何付费 API**。下表供 `dub_plan.py` 产出的
> `tracks[].segments` 字段（`model/voice/rate/pitch/volume/style`）填写参考。

## 通用参数语义

| 参数 | 含义 | 取值范围（edge/azure 语法） |
|------|------|------------------------------|
| `model` | 合成引擎标识 | 见下表 |
| `voice` | 音色 ID | 各厂商命名不同 |
| `rate` | 语速 | `-50%` ~ `+50%`（默认 `+0%`） |
| `pitch` | 音高 | `-100Hz` ~ `+100Hz`（默认 `+0Hz`） |
| `volume` | 音量 | `-50%` ~ `+50%`（默认 `+0%`） |
| `style` | 情感风格 | 见各厂商风格名 |

## 厂商对照

### Edge TTS（`edge`，默认）
- `model`: `edge-tts`
- 中文音色：`zh-CN-XiaoxiaoNeural`(女/旁白首选)、`zh-CN-YunxiNeural`(男/活力)、
  `zh-CN-YunyangNeural`(男/新闻)、`zh-CN-YunjianNeural`(男/温柔)、
  `zh-CN-XiaoyiNeural`(女/客服)、`zh-CN-YunxiaNeural`(女/甜美) 等
- 风格：`general/cheerful/sad/angry/fearful/soft/serious/polite/tender/...`

### Azure Cognitive Services（`azure`）
- `model`: `azure-cognitive-services`
- 音色命名与 Edge 一致（同 MS 语音栈），`zh-CN-*` Neural 音色可直接复用
- 风格支持最全，含 `narration-relaxed` 等旁白专用风格

### 火山引擎 TTS（`volcano`）
- `model`: `volcano-tts`
- 音色：`volcano_zh_*` 系列（如 `volcano_zh_male_1` / `volcano_zh_female_1`）
- 风格支持有限，`style` 字段本技能统一填 `default`，以 `rate/pitch/volume` 微调为主

### CosyVoice（`cosyvoice`）
- `model`: `cosyvoice`
- 音色：`cosyvoice_cn_*` 系列（如 `cosyvoice_cn_male_1` / `cosyvoice_cn_female_sweet`）
- 擅长情感/方言，`style` 同样填 `default`，靠参数微调

## 情感 → 参数映射（本技能内置）

| 情感 | style(edge/azure) | rate | pitch | volume |
|------|------|------|-------|--------|
| neutral/平静 | general | +0% | +0Hz | +0% |
| 兴奋/excited | cheerful | +8% | +6Hz | +0% |
| 悲伤/sad | sad | -6% | -4Hz | -2% |
| 愤怒/angry | angry | +10% | +6Hz | +4% |
| 恐惧/fear | fearful | -4% | -2Hz | -4% |
| 温柔/soft | soft | -4% | -2Hz | +0% |
| 疑问/question | polite | +2% | +2Hz | +0% |
| 严肃/serious | serious | -2% | -2Hz | +0% |

> `volcano` / `cosyvoice` 的 `style` 固定为 `default`，上述 rate/pitch/volume 仍生效。
