# 数据结构定义（aladin-drama-dub）

> 输入 `_script.json`（来自 `aladin-drama-script`），输出 `cast.json` / `lines.json` / `_dub.json`。
> 与 `aladin-drama-subtitle` 共用同一 shot 时间轴。

## 一、输入 `_script.json`

```json
{
  "title": "深夜便利店",
  "lang": "zh-CN",
  "scenes": [
    {
      "shot_no": 1,
      "location": "便利店门口/雨夜",
      "start": 0.0,
      "dialogues": [
        {"character": "旁白", "text": "…", "emotion": "平静", "start": 0.0, "end": 4.2},
        {"character": "林夕", "text": "…", "emotion": "疲惫", "start": 4.2, "end": 7.5}
      ]
    }
  ]
}
```

| 字段 | 必填 | 说明 |
|------|------|------|
| `title` | 否 | 作品名，默认空串 |
| `lang` | 否 | 源语言，默认 `zh-CN` |
| `scenes[].shot_no` | 是 | 镜号（与 subtitle 对齐） |
| `scenes[].location` | 否 | 场景地点（仅备注） |
| `scenes[].start` | 否 | 本镜起始秒；缺省则顺序累加 |
| `scenes[].dialogues[].character` | 是 | 角色名；命中 `旁白/narrator/解说/画外音` 即旁白 |
| `scenes[].dialogues[].text` | 是 | 台词文本 |
| `scenes[].dialogues[].emotion` | 否 | 情感基调，默认 `neutral` |
| `scenes[].dialogues[].start/end` | 否 | 时间轴；缺省按字数估算并标 `estimated` |

## 二、输出 `cast.json`

```json
{
  "title": "深夜便利店", "lang": "zh-CN", "provider": "edge",
  "generated_at": "2026-07-24T00:00:00+00:00",
  "characters": {
    "林夕": {"role": "character", "voice": "zh-CN-XiaoyiNeural", "provider": "edge", "assigned_by": "hash"},
    "旁白": {"role": "narrator", "voice": "zh-CN-XiaoxiaoNeural", "provider": "edge", "assigned_by": "hash"}
  }
}
```

## 三、输出 `lines.json`

```json
{
  "title": "...", "lang": "zh-CN", "provider": "edge",
  "lines": [
    {"shot_no":1,"character":"旁白","role":"narrator","voice":"zh-CN-XiaoxiaoNeural",
     "text":"…","emotion":"平静","start":0.0,"end":4.2,"duration":4.2,"estimated":false}
  ]
}
```

## 四、主产物 `_dub.json`

```json
{
  "meta": {"title":"…","lang":"zh-CN","provider":"edge","generated_at":"…","tool":"aladin-drama-dub","version":"1.1.0","playbook_boosted":false},
  "timeline_aligned": true,
  "subtitle_ref": "aladin-drama-subtitle:_subtitle.json",
  "edit_audio_input": "_dub.json",
  "tracks": [
    {"character":"林夕","role":"character","voice":"zh-CN-XiaoyiNeural","provider":"edge",
     "model":"edge-tts","suggested_voice":null,
     "segments":[
       {"shot_no":1,"start":4.2,"end":7.5,"text":"…","emotion":"疲惫",
        "rate":"+0%","pitch":"+0Hz","volume":"+0%","style":"general","playbook_hint":"无历史"}
     ]}
  ],
  "narration": [ {"shot_no":1,"start":0.0,"end":4.2,"text":"…","voice":"zh-CN-XiaoxiaoNeural",
                  "rate":"+0%","pitch":"+0Hz","volume":"+0%","style":"general","playbook_hint":"无历史"} ],
  "translations": [
    {"lang":"en","items":[{"shot_no":1,"character":"旁白","source":"…","target":null,
                          "note":"规则占位：请用翻译API或人工翻译原文（不调付费API）"}]}
  ]
}
```

| 关键字段 | 说明 |
|----------|------|
| `meta.playbook_boosted` | 本次是否叠加 `--playbook` 验证库（true/false） |
| `timeline_aligned` | 恒 `true`，声明与 subtitle 时间轴一致 |
| `subtitle_ref` | 对齐的字幕产物引用 |
| `edit_audio_input` | 下游 `aladin-drama-edit` 的 `--audio` 输入即本文件 |
| `tracks[].suggested_voice` | 验证库建议的更优音色（与当前 `voice` 不同且历史留存更高时给出） |
| `tracks[].segments[].playbook_hint` | 该句情感在验证库中的留存提示（`无历史`/`验证情感·高留存(0.xx)` 等） |
| `tracks[].segments[]` | 逐句配音条目 + TTS 参数 |
| `narration[]` | 旁白段单独列出，便于单独合成 |
| `translations[]` | 多语种占位（仅 `--translate` 时生成） |

## 五、下游衔接

- `_dub.json` → `aladin-drama-edit --audio _dub.json` 混音
- `dub_manifest.csv` → 剪映/PR 音轨表导入
- `dub_board.html` → 离线评审看板
- `dub_notes.md` → 配音导演现场备注
