# 配音复盘反哺闭环 · 操作手册（aladin-drama-dub）

> 配套 `scripts/dub_retro.py`。把「已发布短剧的真实配音表现」回收为本地验证库
> `dub_playbook.json`，让下次 `dub_cast/dub_plan --playbook` **越配越准**。
> 与 aladin 家族 topic/roi/bgm/shoot/script/clip 共用同一套「验证库反哺」范式。

## 为什么需要闭环

单次配音方案只能靠"角色哈希 + 情感规则"给出**通用**参数。但同一类角色（如女主、反派）
在不同剧里、用不同音色，真实留存/互动差别很大。靠人工反复调太累，也容易忘。

闭环把"哪类角色用哪个音色更留人、哪种情感演绎更打动人"沉淀成数据，
下次自动套用——这是把第 6 环（配音）从"一次性工具"升级为"会成长的资产"的关键。

## 一、反馈数据口径（dub_perf.json）

发布并拿到真实数据后，换算成 0–1 的留存/互动分，写入 `dub_perf.json`：

```json
{
  "tracks": {
    "林夕":  {"retention": 0.60, "engagement": 0.45},
    "顾辰":  {"retention": 0.55, "engagement": 0.40},
    "旁白":  {"retention": 0.66, "engagement": 0.52}
  },
  "emotions": {
    "愤怒": 0.70,
    "平静": 0.50,
    "温柔": 0.62
  }
}
```

| 字段 | 含义 | 取值 |
|------|------|------|
| `tracks.<角色>.retention` | 该角色音轨的平均完播/留存 | 0–1 |
| `tracks.<角色>.engagement` | 该角色音轨的互动（点赞/评论/转发） | 0–1 |
| `emotions.<情感>` | 该情感基调的平均留存 | 0–1 |

> 换算参考：留存分 ≈ 完播率；互动分 ≈ (点赞+评论+转发)/播放量。
> 没有精确数据时，凭体感给 0.3–0.8 的估计值也行，验证库会随样本增多越来越准。

## 二、沉淀（add）

```bash
python dub_retro.py add \
  --dub ./build/_dub.json \
  --perf ./build/dub_perf.json \
  --playbook ./build/dub_playbook.json
```

- 自动按 `_dub.json` 的 `tracks[].voice/provider`、`segments[].emotion` 对齐
  `dub_perf.json` 的 `tracks`/`emotions`，累加到验证库。
- 每个角色记录「历史最佳音色 `best_voice`」（同角色跨剧留存最高者）。
- 验证库结构：`global`（全局基准）、`voices`（音色→留存）、`characters`（角色→最佳音色）、
  `emotions`（情感→留存）、`styles`（风格→留存）。

## 三、查看（summary）

```bash
python dub_retro.py summary --playbook ./build/dub_playbook.json
```

输出三类排行（按留存分降序，并给出相对全局基准的 **提升/下降百分点**）：

- **音色 → 留存**：哪些音色最留人（可据此调整默认 voice_map）。
- **角色 → 最佳音色**：每个角色历史上最稳的配音选择。
- **情感基调 → 留存**：哪种情绪演绎更打动人（驱动 `dub_plan` 的情感放大）。

## 四、预测（benchmark）

```bash
python dub_retro.py benchmark \
  --dub ./build/_dub.json \
  --playbook ./build/dub_playbook.json
```

对一份新 `_dub.json` 的每条音轨，用历史库预测留存分，并标
`✅验证结构`（命中历史）或 `⚠️无历史`（建议人工重点看）。

## 五、反哺（下次配音）

```bash
# 角色音色直接命中验证项（assigned_by=playbook）
python dub_cast.py --script script.json --provider edge \
  --playbook ./build/dub_playbook.json --out ./build

# 按验证情感放大演绎 + 给 playbook_hint + 角色 suggested_voice
python dub_plan.py --lines ./build/lines.json --cast ./build/cast.json \
  --provider edge --playbook ./build/dub_playbook.json --out ./build
```

> 未传 `--playbook` 时，行为与旧版完全一致（哈希分配 + 通用情感规则），闭环完全可选、零侵入。

## 六、上手即用的示例库（seed）

```bash
python dub_retro.py seed --playbook ./build/dub_playbook.json
```

写入一份示例验证库（女主/反派/旁白/女二 的历史最佳音色与情感留存），
无需真实数据即可体验 `summary` / `benchmark` / `--playbook` 反哺效果。
