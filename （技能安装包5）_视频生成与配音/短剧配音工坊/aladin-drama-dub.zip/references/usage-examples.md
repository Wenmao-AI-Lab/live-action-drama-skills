# 阿拉丁·AI短剧配音工坊 — 用法示例

> 配套 `aladin-drama-dub` 技能。所有命令均为纯本地、零依赖，不调用任何付费 API。

## 约定

- `PY`：WorkBuddy 内置 Python 解释器路径
- `SKILL`：本技能目录（即 `SKILL.md` 所在目录）
- 产物统一写到 `--out`（示例用 `./build`）

```bash
PY="C:/Users/adam/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SKILL="<本技能目录>"
```

---

## 场景 1：单人旁白 + 角色（默认 edge）

```bash
"$PY" "$SKILL/scripts/dub_cast.py" --script "$SKILL/assets/sample_script.json" \
  --provider edge --lang zh-CN --out ./build
"$PY" "$SKILL/scripts/dub_plan.py" --lines ./build/lines.json --cast ./build/cast.json \
  --provider edge --lang zh-CN --out ./build
"$PY" "$SKILL/scripts/dub_report.py" --dub ./build/_dub.json \
  --cast ./build/cast.json --lines ./build/lines.json --out ./build
```

产出：`cast.json` `lines.json` `_dub.json` `dub_manifest.csv` `dub_board.html` `dub_notes.md`。

---

## 场景 2：多角色 + 自定义音色映射

新建 `voice_map.json`：

```json
{
  "林夕": "zh-CN-XiaoyiNeural",
  "顾辰": "zh-CN-YunyangNeural"
}
```

```bash
"$PY" "$SKILL/scripts/dub_cast.py" --script script.json \
  --provider azure --voice-map voice_map.json --out ./build
```

`--voice-map` 中的角色名会**覆盖**默认哈希分配（`assigned_by` 记为 `voice_map`）。

---

## 场景 3：多语种占位（不调 API）

```bash
"$PY" "$SKILL/scripts/dub_plan.py" --lines ./build/lines.json --cast ./build/cast.json \
  --provider edge --translate en,ja --out ./build
```

`_dub.json` 的 `translations[]` 会生成 `en` / `ja` 占位条目（原文 + 待译提示），**不会伪造译文**。

---

## 场景 4：缺时间轴的剧本（自动估算）

若 `_script.json` 的 dialogue 没有 `start/end`，脚本按字数估算时长（`estimated:true`），
下游 `aladin-drama-edit` 应以实际合成语音长度为准重排。

```bash
"$PY" "$SKILL/scripts/dub_cast.py" --script no_timeline_script.json \
  --provider cosyvoice --out ./build
```

---

## 场景 5：复盘反哺闭环（让配音越配越准）

先生成示例验证库（或发布后用真实数据沉淀）：

```bash
"$PY" "$SKILL/scripts/dub_retro.py" seed --playbook ./build/dub_playbook.json
"$PY" "$SKILL/scripts/dub_retro.py" summary --playbook ./build/dub_playbook.json
```

假设某部剧发布后拿到真实表现，写入 `./build/dub_perf.json`：

```json
{
  "tracks": {"林夕": {"retention": 0.62, "engagement": 0.48}, "旁白": {"retention": 0.66}},
  "emotions": {"愤怒": 0.71, "平静": 0.52, "温柔": 0.63}
}
```

沉淀进验证库，并对新剧本反哺：

```bash
"$PY" "$SKILL/scripts/dub_retro.py" add \
  --dub ./build/_dub.json --perf ./build/dub_perf.json \
  --playbook ./build/dub_playbook.json

"$PY" "$SKILL/scripts/dub_cast.py" --script script.json --provider edge \
  --playbook ./build/dub_playbook.json --out ./build
"$PY" "$SKILL/scripts/dub_plan.py" --lines ./build/lines.json --cast ./build/cast.json \
  --provider edge --playbook ./build/dub_playbook.json --out ./build
```

效果：`cast.json` 中历史验证正向的角色会被自动套用验证音色（`assigned_by=playbook`）；
`_dub.json` 的 `meta.playbook_boosted=true`，验证过的情感（如"愤怒"）会被放大演绎并标 `playbook_hint`，
`tracks[].suggested_voice` 给出更优音色建议——下次配音比上次更贴合真实观众。

## 最佳实践

1. **角色名稳定**：同一剧本角色名前后要一致，否则哈希分配会变化。
2. **旁白命名**：旁白角色建议直接用 `旁白` / `narrator`，可被自动识别。
3. **时间轴优先**：尽量在 `script` 阶段给每句标 `start/end`，配音与字幕/剪辑三对齐。
4. **先 cast 后 plan**：改音色只需重跑 `dub_cast` + `dub_plan`，不必重跑 report。

## FAQ

**Q：支持哪些 TTS 厂商？**
`edge` / `azure` / `volcano` / `cosyvoice`，通过 `--provider` 切换。仅生成参数，不合成语音。

**Q：会联网或花钱吗？**
不会。三脚本仅用 Python 标准库，离线运行，绝不调用付费 TTS/翻译 API。

**Q：多语种是真的翻译吗？**
不是。`--translate` 只生成"原文 + 待译提示"占位，翻译需下游或人工完成。

**Q：和字幕怎么对齐？**
`_dub.json` 含 `timeline_aligned:true` 与 `subtitle_ref`，与 `aladin-drama-subtitle` 共用同一 shot 时间轴。

**Q：复盘反哺闭环怎么用？**
发布拿到真实留存/互动后，写入 `dub_perf.json`（0–1 分），跑 `dub_retro.py add` 沉淀进 `dub_playbook.json`；下次 `dub_cast/dub_plan --playbook` 自动套用验证音色、按验证情感放大演绎。不传 `--playbook` 时行为与旧版完全一致。

**Q：验证库会泄露剧本吗？**
不会。`dub_playbook.json` 只记录「角色→音色→留存」这类聚合统计，不含任何台词正文，纯本地文件、不外传。

**Q：`dub_perf.json` 里的分数怎么来？**
留存分 ≈ 完播率；互动分 ≈ (点赞+评论+转发)/播放量。无精确数据时凭体感给 0.3–0.8 估计值即可，样本越多越准。
